
.. _plugin-list:

Plugin List
===========

PyPI projects that match "pytest-\*" are considered plugins and are listed
automatically together with a manually-maintained list in `the source
code <https://github.com/pytest-dev/pytest/blob/main/scripts/update-plugin-list.py>`_.
Packages classified as inactive are excluded.

.. The following conditional uses a different format for this list when
   creating a PDF, because otherwise the table gets far too wide for the
   page.

This list contains 1278 plugins.

.. only:: not latex

   ===============================================  ========================================================================================================================================================================================================  ==============  =====================  ================================================
   name                                             summary                                                                                                                                                                                                   last release    status                 requires
   ===============================================  ========================================================================================================================================================================================================  ==============  =====================  ================================================
   :pypi:`logassert`                                Simple but powerful assertion and verification of logged lines.                                                                                                                                           May 20, 2022    5 - Production/Stable  N/A
   :pypi:`pytest-abq`                               Pytest integration for the ABQ universal test runner.                                                                                                                                                     Apr 07, 2023    N/A                    N/A
   :pypi:`pytest-abstracts`                         A contextmanager pytest fixture for handling multiple mock abstracts                                                                                                                                      May 25, 2022    N/A                    N/A
   :pypi:`pytest-accept`                            A pytest-plugin for updating doctest outputs                                                                                                                                                              Dec 21, 2022    N/A                    pytest (>=6,<8)
   :pypi:`pytest-adaptavist`                        pytest plugin for generating test execution results within Jira Test Management (tm4j)                                                                                                                    Oct 13, 2022    N/A                    pytest (>=5.4.0)
   :pypi:`pytest-addons-test`                       用于测试pytest的插件                                                                                                                                                                                      Aug 02, 2021    N/A                    pytest (>=6.2.4,<7.0.0)
   :pypi:`pytest-adf`                               Pytest plugin for writing Azure Data Factory integration tests                                                                                                                                            May 10, 2021    4 - Beta               pytest (>=3.5.0)
   :pypi:`pytest-adf-azure-identity`                Pytest plugin for writing Azure Data Factory integration tests                                                                                                                                            Mar 06, 2021    4 - Beta               pytest (>=3.5.0)
   :pypi:`pytest-ads-testplan`                      Azure DevOps Test Case reporting for pytest tests                                                                                                                                                         Sep 15, 2022    N/A                    N/A
   :pypi:`pytest-agent`                             Service that exposes a REST API that can be used to interract remotely with Pytest. It is shipped with a dashboard that enables running tests in a more convenient way.                                   Nov 25, 2021    N/A                    N/A
   :pypi:`pytest-aggreport`                         pytest plugin for pytest-repeat that generate aggregate report of the same test cases with additional statistics details.                                                                                 Mar 07, 2021    4 - Beta               pytest (>=6.2.2)
   :pypi:`pytest-aio`                               Pytest plugin for testing async python code                                                                                                                                                               Feb 03, 2023    4 - Beta               pytest
   :pypi:`pytest-aiofiles`                          pytest fixtures for writing aiofiles tests with pyfakefs                                                                                                                                                  May 14, 2017    5 - Production/Stable  N/A
   :pypi:`pytest-aiogram`                                                                                                                                                                                                                                     May 06, 2023    N/A                    N/A
   :pypi:`pytest-aiohttp`                           Pytest plugin for aiohttp support                                                                                                                                                                         Feb 12, 2022    4 - Beta               pytest (>=6.1.0)
   :pypi:`pytest-aiohttp-client`                    Pytest \`client\` fixture for the Aiohttp                                                                                                                                                                 Jan 10, 2023    N/A                    pytest (>=7.2.0,<8.0.0)
   :pypi:`pytest-aiomoto`                           pytest-aiomoto                                                                                                                                                                                            Jun 24, 2023    N/A                    pytest (>=7.0,<8.0)
   :pypi:`pytest-aioresponses`                      py.test integration for aioresponses                                                                                                                                                                      Jul 29, 2021    4 - Beta               pytest (>=3.5.0)
   :pypi:`pytest-aioworkers`                        A plugin to test aioworkers project with pytest                                                                                                                                                           May 01, 2023    5 - Production/Stable  pytest>=6.1.0
   :pypi:`pytest-airflow`                           pytest support for airflow.                                                                                                                                                                               Apr 03, 2019    3 - Alpha              pytest (>=4.4.0)
   :pypi:`pytest-airflow-utils`                                                                                                                                                                                                                               Nov 15, 2021    N/A                    N/A
   :pypi:`pytest-alembic`                           A pytest plugin for verifying alembic migrations.                                                                                                                                                         Jun 27, 2023    N/A                    pytest (>=6.0)
   :pypi:`pytest-allclose`                          Pytest fixture extending Numpy's allclose function                                                                                                                                                        Jul 30, 2019    5 - Production/Stable  pytest
   :pypi:`pytest-allure-adaptor`                    Plugin for py.test to generate allure xml reports                                                                                                                                                         Jan 10, 2018    N/A                    pytest (>=2.7.3)
   :pypi:`pytest-allure-adaptor2`                   Plugin for py.test to generate allure xml reports                                                                                                                                                         Oct 14, 2020    N/A                    pytest (>=2.7.3)
   :pypi:`pytest-allure-collection`                 pytest plugin to collect allure markers without running any tests                                                                                                                                         Apr 13, 2023    N/A                    pytest
   :pypi:`pytest-allure-dsl`                        pytest plugin to test case doc string dls instructions                                                                                                                                                    Oct 25, 2020    4 - Beta               pytest
   :pypi:`pytest-allure-intersection`                                                                                                                                                                                                                         Oct 27, 2022    N/A                    pytest (<5)
   :pypi:`pytest-allure-spec-coverage`              The pytest plugin aimed to display test coverage of the specs(requirements) in Allure                                                                                                                     Oct 26, 2021    N/A                    pytest
   :pypi:`pytest-alphamoon`                         Static code checks used at Alphamoon                                                                                                                                                                      Dec 30, 2021    5 - Production/Stable  pytest (>=3.5.0)
   :pypi:`pytest-android`                           This fixture provides a configured "driver" for Android Automated Testing, using uiautomator2.                                                                                                            Feb 21, 2019    3 - Alpha              pytest
   :pypi:`pytest-anki`                              A pytest plugin for testing Anki add-ons                                                                                                                                                                  Jul 31, 2022    4 - Beta               pytest (>=3.5.0)
   :pypi:`pytest-annotate`                          pytest-annotate: Generate PyAnnotate annotations from your pytest tests.                                                                                                                                  Jun 07, 2022    3 - Alpha              pytest (<8.0.0,>=3.2.0)
   :pypi:`pytest-ansible`                           Plugin for pytest to simplify calling ansible modules from tests or fixtures                                                                                                                              May 15, 2023    5 - Production/Stable  pytest (<8.0.0,>=6)
   :pypi:`pytest-ansible-playbook`                  Pytest fixture which runs given ansible playbook file.                                                                                                                                                    Mar 08, 2019    4 - Beta               N/A
   :pypi:`pytest-ansible-playbook-runner`           Pytest fixture which runs given ansible playbook file.                                                                                                                                                    Dec 02, 2020    4 - Beta               pytest (>=3.1.0)
   :pypi:`pytest-ansible-units`                     A pytest plugin for running unit tests within an ansible collection                                                                                                                                       Apr 14, 2022    N/A                    N/A
   :pypi:`pytest-antilru`                           Bust functools.lru_cache when running pytest to avoid test pollution                                                                                                                                      Jul 05, 2022    5 - Production/Stable  pytest
   :pypi:`pytest-anyio`                             The pytest anyio plugin is built into anyio. You don't need this package.                                                                                                                                 Jun 29, 2021    N/A                    pytest
   :pypi:`pytest-anything`                          Pytest fixtures to assert anything and something                                                                                                                                                          Oct 13, 2022    N/A                    pytest
   :pypi:`pytest-aoc`                               Downloads puzzle inputs for Advent of Code and synthesizes PyTest fixtures                                                                                                                                Dec 08, 2022    N/A                    pytest ; extra == 'test'
   :pypi:`pytest-aoreporter`                        pytest report                                                                                                                                                                                             Jun 27, 2022    N/A                    N/A
   :pypi:`pytest-api`                               An ASGI middleware to populate OpenAPI Specification examples from pytest functions                                                                                                                       May 12, 2022    N/A                    pytest (>=7.1.1,<8.0.0)
   :pypi:`pytest-api-soup`                          Validate multiple endpoints with unit testing using a single source of truth.                                                                                                                             Aug 27, 2022    N/A                    N/A
   :pypi:`pytest-apistellar`                        apistellar plugin for pytest.                                                                                                                                                                             Jun 18, 2019    N/A                    N/A
   :pypi:`pytest-appengine`                         AppEngine integration that works well with pytest-django                                                                                                                                                  Feb 27, 2017    N/A                    N/A
   :pypi:`pytest-appium`                            Pytest plugin for appium                                                                                                                                                                                  Dec 05, 2019    N/A                    N/A
   :pypi:`pytest-approvaltests`                     A plugin to use approvaltests with pytest                                                                                                                                                                 May 08, 2022    4 - Beta               pytest (>=7.0.1)
   :pypi:`pytest-approvaltests-geo`                 Extension for ApprovalTests.Python specific to geo data verification                                                                                                                                      Mar 04, 2023    5 - Production/Stable  pytest
   :pypi:`pytest-archon`                            Rule your architecture like a real developer                                                                                                                                                              Jan 31, 2023    5 - Production/Stable  pytest (>=7.2)
   :pypi:`pytest-argus`                             pyest results colection plugin                                                                                                                                                                            Jun 24, 2021    5 - Production/Stable  pytest (>=6.2.4)
   :pypi:`pytest-arraydiff`                         pytest plugin to help with comparing array output from tests                                                                                                                                              Jan 13, 2022    4 - Beta               pytest (>=4.6)
   :pypi:`pytest-asgi-server`                       Convenient ASGI client/server fixtures for Pytest                                                                                                                                                         Dec 12, 2020    N/A                    pytest (>=5.4.1)
   :pypi:`pytest-asptest`                           test Answer Set Programming programs                                                                                                                                                                      Apr 28, 2018    4 - Beta               N/A
   :pypi:`pytest-assertcount`                       Plugin to count actual number of asserts in pytest                                                                                                                                                        Oct 23, 2022    N/A                    pytest (>=5.0.0)
   :pypi:`pytest-assertions`                        Pytest Assertions                                                                                                                                                                                         Apr 27, 2022    N/A                    N/A
   :pypi:`pytest-assertutil`                        pytest-assertutil                                                                                                                                                                                         May 10, 2019    N/A                    N/A
   :pypi:`pytest-assert-utils`                      Useful assertion utilities for use with pytest                                                                                                                                                            Apr 14, 2022    3 - Alpha              N/A
   :pypi:`pytest-assume`                            A pytest plugin that allows multiple failures per test                                                                                                                                                    Jun 24, 2021    N/A                    pytest (>=2.7)
   :pypi:`pytest-assurka`                           A pytest plugin for Assurka Studio                                                                                                                                                                        Aug 04, 2022    N/A                    N/A
   :pypi:`pytest-ast-back-to-python`                A plugin for pytest devs to view how assertion rewriting recodes the AST                                                                                                                                  Sep 29, 2019    4 - Beta               N/A
   :pypi:`pytest-asteroid`                          PyTest plugin for docker-based testing on database images                                                                                                                                                 Aug 15, 2022    N/A                    pytest (>=6.2.5,<8.0.0)
   :pypi:`pytest-astropy`                           Meta-package containing dependencies for testing                                                                                                                                                          Apr 12, 2022    5 - Production/Stable  pytest (>=4.6)
   :pypi:`pytest-astropy-header`                    pytest plugin to add diagnostic information to the header of the test output                                                                                                                              Sep 06, 2022    3 - Alpha              pytest (>=4.6)
   :pypi:`pytest-ast-transformer`                                                                                                                                                                                                                             May 04, 2019    3 - Alpha              pytest
   :pypi:`pytest-asyncio`                           Pytest support for asyncio                                                                                                                                                                                Mar 19, 2023    4 - Beta               pytest (>=7.0.0)
   :pypi:`pytest-asyncio-cooperative`               Run all your asynchronous tests cooperatively.                                                                                                                                                            May 31, 2023    N/A                    N/A
   :pypi:`pytest-asyncio-network-simulator`         pytest-asyncio-network-simulator: Plugin for pytest for simulator the network in tests                                                                                                                    Jul 31, 2018    3 - Alpha              pytest (<3.7.0,>=3.3.2)
   :pypi:`pytest-async-mongodb`                     pytest plugin for async MongoDB                                                                                                                                                                           Oct 18, 2017    5 - Production/Stable  pytest (>=2.5.2)
   :pypi:`pytest-async-sqlalchemy`                  Database testing fixtures using the SQLAlchemy asyncio API                                                                                                                                                Oct 07, 2021    4 - Beta               pytest (>=6.0.0)
   :pypi:`pytest-atomic`                            Skip rest of tests if previous test failed.                                                                                                                                                               Nov 24, 2018    4 - Beta               N/A
   :pypi:`pytest-attrib`                            pytest plugin to select tests based on attributes similar to the nose-attrib plugin                                                                                                                       May 24, 2016    4 - Beta               N/A
   :pypi:`pytest-austin`                            Austin plugin for pytest                                                                                                                                                                                  Oct 11, 2020    4 - Beta               N/A
   :pypi:`pytest-autocap`                           automatically capture test & fixture stdout/stderr to files                                                                                                                                               May 15, 2022    N/A                    pytest (<7.2,>=7.1.2)
   :pypi:`pytest-autochecklog`                      automatically check condition and log all the checks                                                                                                                                                      Apr 25, 2015    4 - Beta               N/A
   :pypi:`pytest-automation`                        pytest plugin for building a test suite, using YAML files to extend pytest parameterize functionality.                                                                                                    May 20, 2022    N/A                    pytest (>=7.0.0)
   :pypi:`pytest-automock`                          Pytest plugin for automatical mocks creation                                                                                                                                                              May 16, 2023    N/A                    pytest ; extra == 'dev'
   :pypi:`pytest-auto-parametrize`                  pytest plugin: avoid repeating arguments in parametrize                                                                                                                                                   Oct 02, 2016    3 - Alpha              N/A
   :pypi:`pytest-autotest`                          This fixture provides a configured "driver" for Android Automated Testing, using uiautomator2.                                                                                                            Aug 25, 2021    N/A                    pytest
   :pypi:`pytest-aviator`                           Aviator's Flakybot pytest plugin that automatically reruns flaky tests.                                                                                                                                   Nov 04, 2022    4 - Beta               pytest
   :pypi:`pytest-avoidance`                         Makes pytest skip tests that don not need rerunning                                                                                                                                                       May 23, 2019    4 - Beta               pytest (>=3.5.0)
   :pypi:`pytest-aws`                               pytest plugin for testing AWS resource configurations                                                                                                                                                     Oct 04, 2017    4 - Beta               N/A
   :pypi:`pytest-aws-config`                        Protect your AWS credentials in unit tests                                                                                                                                                                May 28, 2021    N/A                    N/A
   :pypi:`pytest-axe`                               pytest plugin for axe-selenium-python                                                                                                                                                                     Nov 12, 2018    N/A                    pytest (>=3.0.0)
   :pypi:`pytest-azure`                             Pytest utilities and mocks for Azure                                                                                                                                                                      Jan 18, 2023    3 - Alpha              pytest
   :pypi:`pytest-azure-devops`                      Simplifies using azure devops parallel strategy (https://docs.microsoft.com/en-us/azure/devops/pipelines/test/parallel-testing-any-test-runner) with pytest.                                              Jun 20, 2022    4 - Beta               pytest (>=3.5.0)
   :pypi:`pytest-azurepipelines`                    Formatting PyTest output for Azure Pipelines UI                                                                                                                                                           Oct 20, 2022    5 - Production/Stable  pytest (>=5.0.0)
   :pypi:`pytest-bandit`                            A bandit plugin for pytest                                                                                                                                                                                Feb 23, 2021    4 - Beta               pytest (>=3.5.0)
   :pypi:`pytest-bandit-xayon`                      A bandit plugin for pytest                                                                                                                                                                                Oct 17, 2022    4 - Beta               pytest (>=3.5.0)
   :pypi:`pytest-base-url`                          pytest plugin for URL based testing                                                                                                                                                                       Mar 27, 2022    5 - Production/Stable  pytest (>=3.0.0,<8.0.0)
   :pypi:`pytest-bdd`                               BDD for pytest                                                                                                                                                                                            Nov 08, 2022    6 - Mature             pytest (>=6.2.0)
   :pypi:`pytest-bdd-html`                          pytest plugin to display BDD info in HTML test report                                                                                                                                                     Nov 22, 2022    3 - Alpha              pytest (!=6.0.0,>=5.0)
   :pypi:`pytest-bdd-ng`                            BDD for pytest                                                                                                                                                                                            Jul 01, 2023    4 - Beta               pytest (>=5.0)
   :pypi:`pytest-bdd-splinter`                      Common steps for pytest bdd and splinter integration                                                                                                                                                      Aug 12, 2019    5 - Production/Stable  pytest (>=4.0.0)
   :pypi:`pytest-bdd-web`                           A simple plugin to use with pytest                                                                                                                                                                        Jan 02, 2020    4 - Beta               pytest (>=3.5.0)
   :pypi:`pytest-bdd-wrappers`                                                                                                                                                                                                                                Feb 11, 2020    2 - Pre-Alpha          N/A
   :pypi:`pytest-beakerlib`                         A pytest plugin that reports test results to the BeakerLib framework                                                                                                                                      Mar 17, 2017    5 - Production/Stable  pytest
   :pypi:`pytest-beds`                              Fixtures for testing Google Appengine (GAE) apps                                                                                                                                                          Jun 07, 2016    4 - Beta               N/A
   :pypi:`pytest-beeprint`                          use icdiff for better error messages in pytest assertions                                                                                                                                                 Jun 09, 2023    4 - Beta               N/A
   :pypi:`pytest-bench`                             Benchmark utility that plugs into pytest.                                                                                                                                                                 Jul 21, 2014    3 - Alpha              N/A
   :pypi:`pytest-benchmark`                         A \`\`pytest\`\` fixture for benchmarking code. It will group the tests into rounds that are calibrated to the chosen timer.                                                                              Oct 25, 2022    5 - Production/Stable  pytest (>=3.8)
   :pypi:`pytest-better-datadir`                    A small example package                                                                                                                                                                                   Mar 13, 2023    N/A                    N/A
   :pypi:`pytest-bg-process`                        Pytest plugin to initialize background process                                                                                                                                                            Jan 24, 2022    4 - Beta               pytest (>=3.5.0)
   :pypi:`pytest-bigchaindb`                        A BigchainDB plugin for pytest.                                                                                                                                                                           Jan 24, 2022    4 - Beta               N/A
   :pypi:`pytest-bigquery-mock`                     Provides a mock fixture for python bigquery client                                                                                                                                                        Dec 28, 2022    N/A                    pytest (>=5.0)
   :pypi:`pytest-black`                             A pytest plugin to enable format checking with black                                                                                                                                                      Oct 05, 2020    4 - Beta               N/A
   :pypi:`pytest-black-multipy`                     Allow '--black' on older Pythons                                                                                                                                                                          Jan 14, 2021    5 - Production/Stable  pytest (!=3.7.3,>=3.5) ; extra == 'testing'
   :pypi:`pytest-black-ng`                          A pytest plugin to enable format checking with black                                                                                                                                                      Oct 20, 2022    4 - Beta               pytest (>=7.0.0)
   :pypi:`pytest-blame`                             A pytest plugin helps developers to debug by providing useful commits history.                                                                                                                            May 04, 2019    N/A                    pytest (>=4.4.0)
   :pypi:`pytest-blender`                           Blender Pytest plugin.                                                                                                                                                                                    Jan 04, 2023    N/A                    pytest ; extra == 'dev'
   :pypi:`pytest-blink1`                            Pytest plugin to emit notifications via the Blink(1) RGB LED                                                                                                                                              Jan 07, 2018    4 - Beta               N/A
   :pypi:`pytest-blockage`                          Disable network requests during a test run.                                                                                                                                                               Dec 21, 2021    N/A                    pytest
   :pypi:`pytest-blocker`                           pytest plugin to mark a test as blocker and skip all other tests                                                                                                                                          Sep 07, 2015    4 - Beta               N/A
   :pypi:`pytest-blue`                              A pytest plugin that adds a \`blue\` fixture for printing stuff in blue.                                                                                                                                  Sep 05, 2022    N/A                    N/A
   :pypi:`pytest-board`                             Local continuous test runner with pytest and watchdog.                                                                                                                                                    Jan 20, 2019    N/A                    N/A
   :pypi:`pytest-boost-xml`                         Plugin for pytest to generate boost xml reports                                                                                                                                                           Nov 30, 2022    4 - Beta               N/A
   :pypi:`pytest-bootstrap`                                                                                                                                                                                                                                   Mar 04, 2022    N/A                    N/A
   :pypi:`pytest-bpdb`                              A py.test plug-in to enable drop to bpdb debugger on test failure.                                                                                                                                        Jan 19, 2015    2 - Pre-Alpha          N/A
   :pypi:`pytest-bravado`                           Pytest-bravado automatically generates from OpenAPI specification client fixtures.                                                                                                                        Feb 15, 2022    N/A                    N/A
   :pypi:`pytest-breakword`                         Use breakword with pytest                                                                                                                                                                                 Aug 04, 2021    N/A                    pytest (>=6.2.4,<7.0.0)
   :pypi:`pytest-breed-adapter`                     A simple plugin to connect with breed-server                                                                                                                                                              Nov 07, 2018    4 - Beta               pytest (>=3.5.0)
   :pypi:`pytest-briefcase`                         A pytest plugin for running tests on a Briefcase project.                                                                                                                                                 Jun 14, 2020    4 - Beta               pytest (>=3.5.0)
   :pypi:`pytest-browser`                           A pytest plugin for console based browser test selection just after the collection phase                                                                                                                  Dec 10, 2016    3 - Alpha              N/A
   :pypi:`pytest-browsermob-proxy`                  BrowserMob proxy plugin for py.test.                                                                                                                                                                      Jun 11, 2013    4 - Beta               N/A
   :pypi:`pytest-browserstack-local`                \`\`py.test\`\` plugin to run \`\`BrowserStackLocal\`\` in background.                                                                                                                                    Feb 09, 2018    N/A                    N/A
   :pypi:`pytest-budosystems`                       Budo Systems is a martial arts school management system. This module is the Budo Systems Pytest Plugin.                                                                                                   May 07, 2023    3 - Alpha              pytest
   :pypi:`pytest-bug`                               Pytest plugin for marking tests as a bug                                                                                                                                                                  Jun 23, 2023    5 - Production/Stable  pytest (>=7.1.0)
   :pypi:`pytest-bugtong-tag`                       pytest-bugtong-tag is a plugin for pytest                                                                                                                                                                 Jan 16, 2022    N/A                    N/A
   :pypi:`pytest-bugzilla`                          py.test bugzilla integration plugin                                                                                                                                                                       May 05, 2010    4 - Beta               N/A
   :pypi:`pytest-bugzilla-notifier`                 A plugin that allows you to execute create, update, and read information from BugZilla bugs                                                                                                               Jun 15, 2018    4 - Beta               pytest (>=2.9.2)
   :pypi:`pytest-buildkite`                         Plugin for pytest that automatically publishes coverage and pytest report annotations to Buildkite.                                                                                                       Jul 13, 2019    4 - Beta               pytest (>=3.5.0)
   :pypi:`pytest-builtin-types`                                                                                                                                                                                                                               Nov 17, 2021    N/A                    pytest
   :pypi:`pytest-bwrap`                             Run your tests in Bubblewrap sandboxes                                                                                                                                                                    Oct 26, 2018    3 - Alpha              N/A
   :pypi:`pytest-cache`                             pytest plugin with mechanisms for caching across test runs                                                                                                                                                Jun 04, 2013    3 - Alpha              N/A
   :pypi:`pytest-cache-assert`                      Cache assertion data to simplify regression testing of complex serializable data                                                                                                                          Feb 26, 2023    5 - Production/Stable  pytest (>=5.0.0)
   :pypi:`pytest-cagoule`                           Pytest plugin to only run tests affected by changes                                                                                                                                                       Jan 01, 2020    3 - Alpha              N/A
   :pypi:`pytest-cairo`                             Pytest support for cairo-lang and starknet                                                                                                                                                                Apr 17, 2022    N/A                    pytest
   :pypi:`pytest-call-checker`                      Small pytest utility to easily create test doubles                                                                                                                                                        Oct 16, 2022    4 - Beta               pytest (>=7.1.3,<8.0.0)
   :pypi:`pytest-camel-collect`                     Enable CamelCase-aware pytest class collection                                                                                                                                                            Aug 02, 2020    N/A                    pytest (>=2.9)
   :pypi:`pytest-canonical-data`                    A plugin which allows to compare results with canonical results, based on previous runs                                                                                                                   May 08, 2020    2 - Pre-Alpha          pytest (>=3.5.0)
   :pypi:`pytest-caprng`                            A plugin that replays pRNG state on failure.                                                                                                                                                              May 02, 2018    4 - Beta               N/A
   :pypi:`pytest-capture-deprecatedwarnings`        pytest plugin to capture all deprecatedwarnings and put them in one file                                                                                                                                  Apr 30, 2019    N/A                    N/A
   :pypi:`pytest-capture-warnings`                  pytest plugin to capture all warnings and put them in one file of your choice                                                                                                                             May 03, 2022    N/A                    pytest
   :pypi:`pytest-cases`                             Separate test code from test cases in pytest.                                                                                                                                                             Feb 23, 2023    5 - Production/Stable  N/A
   :pypi:`pytest-cassandra`                         Cassandra CCM Test Fixtures for pytest                                                                                                                                                                    Nov 04, 2017    1 - Planning           N/A
   :pypi:`pytest-catchlog`                          py.test plugin to catch log messages. This is a fork of pytest-capturelog.                                                                                                                                Jan 24, 2016    4 - Beta               pytest (>=2.6)
   :pypi:`pytest-catch-server`                      Pytest plugin with server for catching HTTP requests.                                                                                                                                                     Dec 12, 2019    5 - Production/Stable  N/A
   :pypi:`pytest-celery`                            pytest-celery a shim pytest plugin to enable celery.contrib.pytest                                                                                                                                        May 06, 2021    N/A                    N/A
   :pypi:`pytest-chainmaker`                        pytest plugin for chainmaker                                                                                                                                                                              Oct 15, 2021    N/A                    N/A
   :pypi:`pytest-chalice`                           A set of py.test fixtures for AWS Chalice                                                                                                                                                                 Jul 01, 2020    4 - Beta               N/A
   :pypi:`pytest-change-assert`                     修改报错中文为英文                                                                                                                                                                                        Oct 19, 2022    N/A                    N/A
   :pypi:`pytest-change-demo`                       turn . into √，turn F into x                                                                                                                                                                              Mar 02, 2022    N/A                    pytest
   :pypi:`pytest-change-report`                     turn . into √，turn F into x                                                                                                                                                                              Sep 14, 2020    N/A                    pytest
   :pypi:`pytest-change-xds`                        turn . into √，turn F into x                                                                                                                                                                              Apr 16, 2022    N/A                    pytest
   :pypi:`pytest-chdir`                             A pytest fixture for changing current working directory                                                                                                                                                   Jan 28, 2020    N/A                    pytest (>=5.0.0,<6.0.0)
   :pypi:`pytest-check`                             A pytest plugin that allows multiple failures per test.                                                                                                                                                   Jun 06, 2023    N/A                    pytest
   :pypi:`pytest-checkdocs`                         check the README when running tests                                                                                                                                                                       Oct 09, 2022    5 - Production/Stable  pytest (>=6) ; extra == 'testing'
   :pypi:`pytest-checkipdb`                         plugin to check if there are ipdb debugs left                                                                                                                                                             Jul 22, 2020    5 - Production/Stable  pytest (>=2.9.2)
   :pypi:`pytest-check-library`                     check your missing library                                                                                                                                                                                Jul 17, 2022    N/A                    N/A
   :pypi:`pytest-check-libs`                        check your missing library                                                                                                                                                                                Jul 17, 2022    N/A                    N/A
   :pypi:`pytest-check-links`                       Check links in files                                                                                                                                                                                      Jul 29, 2020    N/A                    pytest>=7.0
   :pypi:`pytest-check-mk`                          pytest plugin to test Check_MK checks                                                                                                                                                                     Nov 19, 2015    4 - Beta               pytest
   :pypi:`pytest-check-requirements`                A package to prevent Dependency Confusion attacks against Yandex.                                                                                                                                         Feb 10, 2023    N/A                    N/A
   :pypi:`pytest-chic-report`                       A pytest plugin to send a report and printing summary of tests.                                                                                                                                           Jan 31, 2023    5 - Production/Stable  N/A
   :pypi:`pytest-chunks`                            Run only a chunk of your test suite                                                                                                                                                                       Jul 05, 2022    N/A                    pytest (>=6.0.0)
   :pypi:`pytest-circleci`                          py.test plugin for CircleCI                                                                                                                                                                               May 03, 2019    N/A                    N/A
   :pypi:`pytest-circleci-parallelized`             Parallelize pytest across CircleCI workers.                                                                                                                                                               Oct 20, 2022    N/A                    N/A
   :pypi:`pytest-circleci-parallelized-rjp`         Parallelize pytest across CircleCI workers.                                                                                                                                                               Jun 21, 2022    N/A                    pytest
   :pypi:`pytest-ckan`                              Backport of CKAN 2.9 pytest plugin and fixtures to CAKN 2.8                                                                                                                                               Apr 28, 2020    4 - Beta               pytest
   :pypi:`pytest-clarity`                           A plugin providing an alternative, colourful diff output for failing assertions.                                                                                                                          Jun 11, 2021    N/A                    N/A
   :pypi:`pytest-cldf`                              Easy quality control for CLDF datasets using pytest                                                                                                                                                       Nov 07, 2022    N/A                    pytest (>=3.6)
   :pypi:`pytest-click`                             Pytest plugin for Click                                                                                                                                                                                   Feb 11, 2022    5 - Production/Stable  pytest (>=5.0)
   :pypi:`pytest-cli-fixtures`                      Automatically register fixtures for custom CLI arguments                                                                                                                                                  Jul 28, 2022    N/A                    pytest (~=7.0)
   :pypi:`pytest-clld`                                                                                                                                                                                                                                        Jul 06, 2022    N/A                    pytest (>=3.6)
   :pypi:`pytest-cloud`                             Distributed tests planner plugin for pytest testing framework.                                                                                                                                            Oct 05, 2020    6 - Mature             N/A
   :pypi:`pytest-cloudflare-worker`                 pytest plugin for testing cloudflare workers                                                                                                                                                              Mar 30, 2021    4 - Beta               pytest (>=6.0.0)
   :pypi:`pytest-cloudist`                          Distribute tests to cloud machines without fuss                                                                                                                                                           Sep 02, 2022    4 - Beta               pytest (>=7.1.2,<8.0.0)
   :pypi:`pytest-cmake`                             Provide CMake module for Pytest                                                                                                                                                                           Jan 21, 2023    N/A                    pytest<8,>=4
   :pypi:`pytest-cmake-presets`                     Execute CMake Presets via pytest                                                                                                                                                                          Dec 26, 2022    N/A                    pytest (>=7.2.0,<8.0.0)
   :pypi:`pytest-cobra`                             PyTest plugin for testing Smart Contracts for Ethereum blockchain.                                                                                                                                        Jun 29, 2019    3 - Alpha              pytest (<4.0.0,>=3.7.1)
   :pypi:`pytest-codecarbon`                        Pytest plugin for measuring carbon emissions                                                                                                                                                              Jun 15, 2022    N/A                    pytest
   :pypi:`pytest-codecheckers`                      pytest plugin to add source code sanity checks (pep8 and friends)                                                                                                                                         Feb 13, 2010    N/A                    N/A
   :pypi:`pytest-codecov`                           Pytest plugin for uploading pytest-cov results to codecov.io                                                                                                                                              Nov 29, 2022    4 - Beta               pytest (>=4.6.0)
   :pypi:`pytest-codegen`                           Automatically create pytest test signatures                                                                                                                                                               Aug 23, 2020    2 - Pre-Alpha          N/A
   :pypi:`pytest-codeowners`                        Pytest plugin for selecting tests by GitHub CODEOWNERS.                                                                                                                                                   Mar 30, 2022    4 - Beta               pytest (>=6.0.0)
   :pypi:`pytest-codestyle`                         pytest plugin to run pycodestyle                                                                                                                                                                          Mar 23, 2020    3 - Alpha              N/A
   :pypi:`pytest-codspeed`                          Pytest plugin to create CodSpeed benchmarks                                                                                                                                                               Dec 02, 2022    5 - Production/Stable  pytest>=3.8
   :pypi:`pytest-collect-formatter`                 Formatter for pytest collect output                                                                                                                                                                       Mar 29, 2021    5 - Production/Stable  N/A
   :pypi:`pytest-collect-formatter2`                Formatter for pytest collect output                                                                                                                                                                       May 31, 2021    5 - Production/Stable  N/A
   :pypi:`pytest-collector`                         Python package for collecting pytest.                                                                                                                                                                     Aug 02, 2022    N/A                    pytest (>=7.0,<8.0)
   :pypi:`pytest-colordots`                         Colorizes the progress indicators                                                                                                                                                                         Oct 06, 2017    5 - Production/Stable  N/A
   :pypi:`pytest-commander`                         An interactive GUI test runner for PyTest                                                                                                                                                                 Aug 17, 2021    N/A                    pytest (<7.0.0,>=6.2.4)
   :pypi:`pytest-common-subject`                    pytest framework for testing different aspects of a common method                                                                                                                                         May 15, 2022    N/A                    pytest (>=3.6,<8)
   :pypi:`pytest-compare`                           pytest plugin for comparing call arguments.                                                                                                                                                               Jun 22, 2023    5 - Production/Stable  N/A
   :pypi:`pytest-concurrent`                        Concurrently execute test cases with multithread, multiprocess and gevent                                                                                                                                 Jan 12, 2019    4 - Beta               pytest (>=3.1.1)
   :pypi:`pytest-config`                            Base configurations and utilities for developing    your Python project test suite with pytest.                                                                                                           Nov 07, 2014    5 - Production/Stable  N/A
   :pypi:`pytest-confluence-report`                 Package stands for pytest plugin to upload results into Confluence page.                                                                                                                                  Apr 17, 2022    N/A                    N/A
   :pypi:`pytest-console-scripts`                   Pytest plugin for testing console scripts                                                                                                                                                                 May 31, 2023    4 - Beta               pytest (>=4.0.0)
   :pypi:`pytest-consul`                            pytest plugin with fixtures for testing consul aware apps                                                                                                                                                 Nov 24, 2018    3 - Alpha              pytest
   :pypi:`pytest-container`                         Pytest fixtures for writing container based tests                                                                                                                                                         Jun 19, 2023    4 - Beta               pytest (>=3.10)
   :pypi:`pytest-contextfixture`                    Define pytest fixtures as context managers.                                                                                                                                                               Mar 12, 2013    4 - Beta               N/A
   :pypi:`pytest-contexts`                          A plugin to run tests written with the Contexts framework using pytest                                                                                                                                    May 19, 2021    4 - Beta               N/A
   :pypi:`pytest-cookies`                           The pytest plugin for your Cookiecutter templates. 🍪                                                                                                                                                     Mar 22, 2023    5 - Production/Stable  pytest (>=3.9.0)
   :pypi:`pytest-copier`                            A pytest plugin to help testing Copier templates                                                                                                                                                          Jun 23, 2023    4 - Beta               pytest>=7.1.2
   :pypi:`pytest-couchdbkit`                        py.test extension for per-test couchdb databases using couchdbkit                                                                                                                                         Apr 17, 2012    N/A                    N/A
   :pypi:`pytest-count`                             count erros and send email                                                                                                                                                                                Jan 12, 2018    4 - Beta               N/A
   :pypi:`pytest-cov`                               Pytest plugin for measuring coverage.                                                                                                                                                                     May 24, 2023    5 - Production/Stable  pytest (>=4.6)
   :pypi:`pytest-cover`                             Pytest plugin for measuring coverage. Forked from \`pytest-cov\`.                                                                                                                                         Aug 01, 2015    5 - Production/Stable  N/A
   :pypi:`pytest-coverage`                                                                                                                                                                                                                                    Jun 17, 2015    N/A                    N/A
   :pypi:`pytest-coverage-context`                  Coverage dynamic context support for PyTest, including sub-processes                                                                                                                                      Jun 28, 2023    4 - Beta               N/A
   :pypi:`pytest-coveragemarkers`                   Using pytest markers to track functional coverage and filtering of tests                                                                                                                                  Nov 29, 2022    N/A                    pytest (>=7.1.2,<8.0.0)
   :pypi:`pytest-cov-exclude`                       Pytest plugin for excluding tests based on coverage data                                                                                                                                                  Apr 29, 2016    4 - Beta               pytest (>=2.8.0,<2.9.0); extra == 'dev'
   :pypi:`pytest-cpp`                               Use pytest's runner to discover and execute C++ tests                                                                                                                                                     Jan 30, 2023    5 - Production/Stable  pytest (>=7.0)
   :pypi:`pytest-cppython`                          A pytest plugin that imports CPPython testing types                                                                                                                                                       Jun 19, 2023    N/A                    N/A
   :pypi:`pytest-cqase`                             Custom qase pytest plugin                                                                                                                                                                                 Aug 22, 2022    N/A                    pytest (>=7.1.2,<8.0.0)
   :pypi:`pytest-cram`                              Run cram tests with pytest.                                                                                                                                                                               Aug 08, 2020    N/A                    N/A
   :pypi:`pytest-crate`                             Manages CrateDB instances during your integration tests                                                                                                                                                   May 28, 2019    3 - Alpha              pytest (>=4.0)
   :pypi:`pytest-crayons`                           A pytest plugin for colorful print statements                                                                                                                                                             Mar 19, 2023    N/A                    pytest
   :pypi:`pytest-create`                            pytest-create                                                                                                                                                                                             Feb 15, 2023    1 - Planning           N/A
   :pypi:`pytest-cricri`                            A Cricri plugin for pytest.                                                                                                                                                                               Jan 27, 2018    N/A                    pytest
   :pypi:`pytest-crontab`                           add crontab task in crontab                                                                                                                                                                               Dec 09, 2019    N/A                    N/A
   :pypi:`pytest-csv`                               CSV output for pytest.                                                                                                                                                                                    Apr 22, 2021    N/A                    pytest (>=6.0)
   :pypi:`pytest-csv-params`                        Pytest plugin for Test Case Parametrization with CSV files                                                                                                                                                Jul 01, 2023    5 - Production/Stable  pytest (>=7.4.0,<8.0.0)
   :pypi:`pytest-curio`                             Pytest support for curio.                                                                                                                                                                                 Oct 07, 2020    N/A                    N/A
   :pypi:`pytest-curl-report`                       pytest plugin to generate curl command line report                                                                                                                                                        Dec 11, 2016    4 - Beta               N/A
   :pypi:`pytest-custom-concurrency`                Custom grouping concurrence for pytest                                                                                                                                                                    Feb 08, 2021    N/A                    N/A
   :pypi:`pytest-custom-exit-code`                  Exit pytest test session with custom exit code in different scenarios                                                                                                                                     Aug 07, 2019    4 - Beta               pytest (>=4.0.2)
   :pypi:`pytest-custom-nodeid`                     Custom grouping for pytest-xdist, rename test cases name and test cases nodeid, support allure report                                                                                                     Mar 07, 2021    N/A                    N/A
   :pypi:`pytest-custom-report`                     Configure the symbols displayed for test outcomes                                                                                                                                                         Jan 30, 2019    N/A                    pytest
   :pypi:`pytest-custom-scheduling`                 Custom grouping for pytest-xdist, rename test cases name and test cases nodeid, support allure report                                                                                                     Mar 01, 2021    N/A                    N/A
   :pypi:`pytest-cython`                            A plugin for testing Cython extension modules                                                                                                                                                             Feb 16, 2023    5 - Production/Stable  pytest (>=4.6.0)
   :pypi:`pytest-cython-collect`                                                                                                                                                                                                                              Jun 17, 2022    N/A                    pytest
   :pypi:`pytest-darker`                            A pytest plugin for checking of modified code using Darker                                                                                                                                                Aug 16, 2020    N/A                    pytest (>=6.0.1) ; extra == 'test'
   :pypi:`pytest-dash`                              pytest fixtures to run dash applications.                                                                                                                                                                 Mar 18, 2019    N/A                    N/A
   :pypi:`pytest-data`                              Useful functions for managing data for pytest fixtures                                                                                                                                                    Nov 01, 2016    5 - Production/Stable  N/A
   :pypi:`pytest-databricks`                        Pytest plugin for remote Databricks notebooks testing                                                                                                                                                     Jul 29, 2020    N/A                    pytest
   :pypi:`pytest-datadir`                           pytest plugin for test data directories and files                                                                                                                                                         Oct 25, 2022    5 - Production/Stable  pytest (>=5.0)
   :pypi:`pytest-datadir-mgr`                       Manager for test data: downloads, artifact caching, and a tmpdir context.                                                                                                                                 Apr 06, 2023    5 - Production/Stable  pytest (>=7.1)
   :pypi:`pytest-datadir-ng`                        Fixtures for pytest allowing test functions/methods to easily retrieve test resources from the local filesystem.                                                                                          Dec 25, 2019    5 - Production/Stable  pytest
   :pypi:`pytest-datadir-nng`                       Fixtures for pytest allowing test functions/methods to easily retrieve test resources from the local filesystem.                                                                                          Nov 09, 2022    5 - Production/Stable  pytest (>=7.0.0,<8.0.0)
   :pypi:`pytest-data-extractor`                    A pytest plugin to extract relevant metadata about tests into an external file (currently only json support)                                                                                              Jul 19, 2022    N/A                    pytest (>=7.0.1)
   :pypi:`pytest-data-file`                         Fixture "data" and "case_data" for test from yaml file                                                                                                                                                    Dec 04, 2019    N/A                    N/A
   :pypi:`pytest-datafiles`                         py.test plugin to create a 'tmp_path' containing predefined files/directories.                                                                                                                            Feb 24, 2023    5 - Production/Stable  pytest (>=3.6)
   :pypi:`pytest-datafixtures`                      Data fixtures for pytest made simple                                                                                                                                                                      Dec 05, 2020    5 - Production/Stable  N/A
   :pypi:`pytest-data-from-files`                   pytest plugin to provide data from files loaded automatically                                                                                                                                             Oct 13, 2021    4 - Beta               pytest
   :pypi:`pytest-dataplugin`                        A pytest plugin for managing an archive of test data.                                                                                                                                                     Sep 16, 2017    1 - Planning           N/A
   :pypi:`pytest-datarecorder`                      A py.test plugin recording and comparing test output.                                                                                                                                                     Jan 08, 2023    5 - Production/Stable  pytest
   :pypi:`pytest-dataset`                           Plugin for loading different datasets for pytest by prefix from json or yaml files                                                                                                                        May 01, 2023    5 - Production/Stable  N/A
   :pypi:`pytest-data-suites`                       Class-based pytest parametrization                                                                                                                                                                        Jul 24, 2022    N/A                    pytest (>=6.0,<8.0)
   :pypi:`pytest-datatest`                          A pytest plugin for test driven data-wrangling (this is the development version of datatest's pytest integration).                                                                                        Oct 15, 2020    4 - Beta               pytest (>=3.3)
   :pypi:`pytest-db`                                Session scope fixture "db" for mysql query or change                                                                                                                                                      Dec 04, 2019    N/A                    N/A
   :pypi:`pytest-dbfixtures`                        Databases fixtures plugin for py.test.                                                                                                                                                                    Dec 07, 2016    4 - Beta               N/A
   :pypi:`pytest-db-plugin`                                                                                                                                                                                                                                   Nov 27, 2021    N/A                    pytest (>=5.0)
   :pypi:`pytest-dbt`                               Unit test dbt models with standard python tooling                                                                                                                                                         Jun 08, 2023    2 - Pre-Alpha          pytest (>=7.0.0,<8.0.0)
   :pypi:`pytest-dbt-adapter`                       A pytest plugin for testing dbt adapter plugins                                                                                                                                                           Nov 24, 2021    N/A                    pytest (<7,>=6)
   :pypi:`pytest-dbt-conventions`                   A pytest plugin for linting a dbt project's conventions                                                                                                                                                   Mar 02, 2022    N/A                    pytest (>=6.2.5,<7.0.0)
   :pypi:`pytest-dbt-core`                          Pytest extension for dbt.                                                                                                                                                                                 May 03, 2023    N/A                    pytest (>=6.2.5) ; extra == 'test'
   :pypi:`pytest-dbus-notification`                 D-BUS notifications for pytest results.                                                                                                                                                                   Mar 05, 2014    5 - Production/Stable  N/A
   :pypi:`pytest-dbx`                               Pytest plugin to run unit tests for dbx (Databricks CLI extensions) related code                                                                                                                          Nov 29, 2022    N/A                    pytest (>=7.1.3,<8.0.0)
   :pypi:`pytest-deadfixtures`                      A simple plugin to list unused fixtures in pytest                                                                                                                                                         Jul 23, 2020    5 - Production/Stable  N/A
   :pypi:`pytest-deepcov`                           deepcov                                                                                                                                                                                                   Mar 30, 2021    N/A                    N/A
   :pypi:`pytest-defer`                                                                                                                                                                                                                                       Aug 24, 2021    N/A                    N/A
   :pypi:`pytest-demo-plugin`                       pytest示例插件                                                                                                                                                                                            May 15, 2021    N/A                    N/A
   :pypi:`pytest-dependency`                        Manage dependencies of tests                                                                                                                                                                              Feb 14, 2020    4 - Beta               N/A
   :pypi:`pytest-depends`                           Tests that depend on other tests                                                                                                                                                                          Apr 05, 2020    5 - Production/Stable  pytest (>=3)
   :pypi:`pytest-deprecate`                         Mark tests as testing a deprecated feature with a warning note.                                                                                                                                           Jul 01, 2019    N/A                    N/A
   :pypi:`pytest-describe`                          Describe-style plugin for pytest                                                                                                                                                                          Apr 09, 2023    5 - Production/Stable  pytest (<8,>=4.6)
   :pypi:`pytest-describe-it`                       plugin for rich text descriptions                                                                                                                                                                         Jul 19, 2019    4 - Beta               pytest
   :pypi:`pytest-devpi-server`                      DevPI server fixture for py.test                                                                                                                                                                          May 28, 2019    5 - Production/Stable  pytest
   :pypi:`pytest-dhos`                              Common fixtures for pytest in DHOS services and libraries                                                                                                                                                 Sep 07, 2022    N/A                    N/A
   :pypi:`pytest-diamond`                           pytest plugin for diamond                                                                                                                                                                                 Aug 31, 2015    4 - Beta               N/A
   :pypi:`pytest-dicom`                             pytest plugin to provide DICOM fixtures                                                                                                                                                                   Dec 19, 2018    3 - Alpha              pytest
   :pypi:`pytest-dictsdiff`                                                                                                                                                                                                                                   Jul 26, 2019    N/A                    N/A
   :pypi:`pytest-diff`                              A simple plugin to use with pytest                                                                                                                                                                        Mar 30, 2019    4 - Beta               pytest (>=3.5.0)
   :pypi:`pytest-diffeo`                            A package to prevent Dependency Confusion attacks against Yandex.                                                                                                                                         Feb 10, 2023    N/A                    N/A
   :pypi:`pytest-diff-selector`                     Get tests affected by code changes (using git)                                                                                                                                                            Feb 24, 2022    4 - Beta               pytest (>=6.2.2) ; extra == 'all'
   :pypi:`pytest-difido`                            PyTest plugin for generating Difido reports                                                                                                                                                               Oct 23, 2022    4 - Beta               pytest (>=4.0.0)
   :pypi:`pytest-dir-equal`                         pytest-dir-equals is a pytest plugin providing helpers to assert directories equality allowing golden testing                                                                                             Jun 23, 2023    4 - Beta               pytest>=7.1.2
   :pypi:`pytest-disable`                           pytest plugin to disable a test and skip it from testrun                                                                                                                                                  Sep 10, 2015    4 - Beta               N/A
   :pypi:`pytest-disable-plugin`                    Disable plugins per test                                                                                                                                                                                  Feb 28, 2019    4 - Beta               pytest (>=3.5.0)
   :pypi:`pytest-discord`                           A pytest plugin to notify test results to a Discord channel.                                                                                                                                              Feb 05, 2023    4 - Beta               pytest (!=6.0.0,<8,>=3.3.2)
   :pypi:`pytest-django`                            A Django plugin for pytest.                                                                                                                                                                               Dec 07, 2021    5 - Production/Stable  pytest (>=5.4.0)
   :pypi:`pytest-django-ahead`                      A Django plugin for pytest.                                                                                                                                                                               Oct 27, 2016    5 - Production/Stable  pytest (>=2.9)
   :pypi:`pytest-djangoapp`                         Nice pytest plugin to help you with Django pluggable application testing.                                                                                                                                 May 19, 2023    4 - Beta               pytest
   :pypi:`pytest-django-cache-xdist`                A djangocachexdist plugin for pytest                                                                                                                                                                      May 12, 2020    4 - Beta               N/A
   :pypi:`pytest-django-casperjs`                   Integrate CasperJS with your django tests as a pytest fixture.                                                                                                                                            Mar 15, 2015    2 - Pre-Alpha          N/A
   :pypi:`pytest-django-dotenv`                     Pytest plugin used to setup environment variables with django-dotenv                                                                                                                                      Nov 26, 2019    4 - Beta               pytest (>=2.6.0)
   :pypi:`pytest-django-factories`                  Factories for your Django models that can be used as Pytest fixtures.                                                                                                                                     Nov 12, 2020    4 - Beta               N/A
   :pypi:`pytest-django-filefield`                  Replaces FileField.storage with something you can patch globally.                                                                                                                                         May 09, 2022    5 - Production/Stable  pytest >= 5.2
   :pypi:`pytest-django-gcir`                       A Django plugin for pytest.                                                                                                                                                                               Mar 06, 2018    5 - Production/Stable  N/A
   :pypi:`pytest-django-haystack`                   Cleanup your Haystack indexes between tests                                                                                                                                                               Sep 03, 2017    5 - Production/Stable  pytest (>=2.3.4)
   :pypi:`pytest-django-ifactory`                   A model instance factory for pytest-django                                                                                                                                                                Jun 06, 2023    5 - Production/Stable  N/A
   :pypi:`pytest-django-lite`                       The bare minimum to integrate py.test with Django.                                                                                                                                                        Jan 30, 2014    N/A                    N/A
   :pypi:`pytest-django-liveserver-ssl`                                                                                                                                                                                                                       Jan 20, 2022    3 - Alpha              N/A
   :pypi:`pytest-django-model`                      A Simple Way to Test your Django Models                                                                                                                                                                   Feb 14, 2019    4 - Beta               N/A
   :pypi:`pytest-django-ordering`                   A pytest plugin for preserving the order in which Django runs tests.                                                                                                                                      Jul 25, 2019    5 - Production/Stable  pytest (>=2.3.0)
   :pypi:`pytest-django-queries`                    Generate performance reports from your django database performance tests.                                                                                                                                 Mar 01, 2021    N/A                    N/A
   :pypi:`pytest-djangorestframework`               A djangorestframework plugin for pytest                                                                                                                                                                   Aug 11, 2019    4 - Beta               N/A
   :pypi:`pytest-django-rq`                         A pytest plugin to help writing unit test for django-rq                                                                                                                                                   Apr 13, 2020    4 - Beta               N/A
   :pypi:`pytest-django-sqlcounts`                  py.test plugin for reporting the number of SQLs executed per django testcase.                                                                                                                             Jun 16, 2015    4 - Beta               N/A
   :pypi:`pytest-django-testing-postgresql`         Use a temporary PostgreSQL database with pytest-django                                                                                                                                                    Jan 31, 2022    4 - Beta               N/A
   :pypi:`pytest-doc`                               A documentation plugin for py.test.                                                                                                                                                                       Jun 28, 2015    5 - Production/Stable  N/A
   :pypi:`pytest-docfiles`                          pytest plugin to test codeblocks in your documentation.                                                                                                                                                   Dec 22, 2021    4 - Beta               pytest (>=3.7.0)
   :pypi:`pytest-docgen`                            An RST Documentation Generator for pytest-based test suites                                                                                                                                               Apr 17, 2020    N/A                    N/A
   :pypi:`pytest-docker`                            Simple pytest fixtures for Docker and docker-compose based tests                                                                                                                                          Sep 14, 2022    N/A                    pytest (<8.0,>=4.0)
   :pypi:`pytest-docker-apache-fixtures`            Pytest fixtures for testing with apache2 (httpd).                                                                                                                                                         Feb 16, 2022    4 - Beta               pytest
   :pypi:`pytest-docker-butla`                                                                                                                                                                                                                                Jun 16, 2019    3 - Alpha              N/A
   :pypi:`pytest-dockerc`                           Run, manage and stop Docker Compose project from Docker API                                                                                                                                               Oct 09, 2020    5 - Production/Stable  pytest (>=3.0)
   :pypi:`pytest-docker-compose`                    Manages Docker containers during your integration tests                                                                                                                                                   Jan 26, 2021    5 - Production/Stable  pytest (>=3.3)
   :pypi:`pytest-docker-db`                         A plugin to use docker databases for pytests                                                                                                                                                              Mar 20, 2021    5 - Production/Stable  pytest (>=3.1.1)
   :pypi:`pytest-docker-fixtures`                   pytest docker fixtures                                                                                                                                                                                    May 02, 2023    3 - Alpha              pytest
   :pypi:`pytest-docker-git-fixtures`               Pytest fixtures for testing with git scm.                                                                                                                                                                 Feb 09, 2022    4 - Beta               pytest
   :pypi:`pytest-docker-haproxy-fixtures`           Pytest fixtures for testing with haproxy.                                                                                                                                                                 Feb 09, 2022    4 - Beta               pytest
   :pypi:`pytest-docker-pexpect`                    pytest plugin for writing functional tests with pexpect and docker                                                                                                                                        Jan 14, 2019    N/A                    pytest
   :pypi:`pytest-docker-postgresql`                 A simple plugin to use with pytest                                                                                                                                                                        Sep 24, 2019    4 - Beta               pytest (>=3.5.0)
   :pypi:`pytest-docker-py`                         Easy to use, simple to extend, pytest plugin that minimally leverages docker-py.                                                                                                                          Nov 27, 2018    N/A                    pytest (==4.0.0)
   :pypi:`pytest-docker-registry-fixtures`          Pytest fixtures for testing with docker registries.                                                                                                                                                       Apr 08, 2022    4 - Beta               pytest
   :pypi:`pytest-docker-service`                    pytest plugin to start docker container                                                                                                                                                                   Feb 22, 2023    3 - Alpha              pytest (>=7.1.3)
   :pypi:`pytest-docker-squid-fixtures`             Pytest fixtures for testing with squid.                                                                                                                                                                   Feb 09, 2022    4 - Beta               pytest
   :pypi:`pytest-docker-tools`                      Docker integration tests for pytest                                                                                                                                                                       Feb 17, 2022    4 - Beta               pytest (>=6.0.1)
   :pypi:`pytest-docs`                              Documentation tool for pytest                                                                                                                                                                             Nov 11, 2018    4 - Beta               pytest (>=3.5.0)
   :pypi:`pytest-docstyle`                          pytest plugin to run pydocstyle                                                                                                                                                                           Mar 23, 2020    3 - Alpha              N/A
   :pypi:`pytest-doctest-custom`                    A py.test plugin for customizing string representations of doctest results.                                                                                                                               Jul 25, 2016    4 - Beta               N/A
   :pypi:`pytest-doctest-ellipsis-markers`          Setup additional values for ELLIPSIS_MARKER for doctests                                                                                                                                                  Jan 12, 2018    4 - Beta               N/A
   :pypi:`pytest-doctest-import`                    A simple pytest plugin to import names and add them to the doctest namespace.                                                                                                                             Nov 13, 2018    4 - Beta               pytest (>=3.3.0)
   :pypi:`pytest-doctestplus`                       Pytest plugin with advanced doctest features.                                                                                                                                                             Jun 08, 2023    3 - Alpha              pytest (>=4.6)
   :pypi:`pytest-dolphin`                           Some extra stuff that we use ininternally                                                                                                                                                                 Nov 30, 2016    4 - Beta               pytest (==3.0.4)
   :pypi:`pytest-doorstop`                          A pytest plugin for adding test results into doorstop items.                                                                                                                                              Jun 09, 2020    4 - Beta               pytest (>=3.5.0)
   :pypi:`pytest-dotenv`                            A py.test plugin that parses environment files before running tests                                                                                                                                       Jun 16, 2020    4 - Beta               pytest (>=5.0.0)
   :pypi:`pytest-draw`                              Pytest plugin for randomly selecting a specific number of tests                                                                                                                                           Mar 21, 2023    3 - Alpha              pytest
   :pypi:`pytest-drf`                               A Django REST framework plugin for pytest.                                                                                                                                                                Jul 12, 2022    5 - Production/Stable  pytest (>=3.7)
   :pypi:`pytest-drivings`                          Tool to allow webdriver automation to be ran locally or remotely                                                                                                                                          Jan 13, 2021    N/A                    N/A
   :pypi:`pytest-drop-dup-tests`                    A Pytest plugin to drop duplicated tests during collection                                                                                                                                                May 23, 2020    4 - Beta               pytest (>=2.7)
   :pypi:`pytest-dummynet`                          A py.test plugin providing access to a dummynet.                                                                                                                                                          Dec 15, 2021    5 - Production/Stable  pytest
   :pypi:`pytest-dump2json`                         A pytest plugin for dumping test results to json.                                                                                                                                                         Jun 29, 2015    N/A                    N/A
   :pypi:`pytest-duration-insights`                                                                                                                                                                                                                           Jun 25, 2021    N/A                    N/A
   :pypi:`pytest-durations`                         Pytest plugin reporting fixtures and test functions execution time.                                                                                                                                       Apr 22, 2022    5 - Production/Stable  pytest (>=4.6)
   :pypi:`pytest-dynamicrerun`                      A pytest plugin to rerun tests dynamically based off of test outcome and output.                                                                                                                          Aug 15, 2020    4 - Beta               N/A
   :pypi:`pytest-dynamodb`                          DynamoDB fixtures for pytest                                                                                                                                                                              Jun 12, 2023    5 - Production/Stable  pytest
   :pypi:`pytest-easy-addoption`                    pytest-easy-addoption: Easy way to work with pytest addoption                                                                                                                                             Jan 22, 2020    N/A                    N/A
   :pypi:`pytest-easy-api`                          Simple API testing with pytest                                                                                                                                                                            Mar 26, 2018    N/A                    N/A
   :pypi:`pytest-easyMPI`                           Package that supports mpi tests in pytest                                                                                                                                                                 Oct 21, 2020    N/A                    N/A
   :pypi:`pytest-easyread`                          pytest plugin that makes terminal printouts of the reports easier to read                                                                                                                                 Nov 17, 2017    N/A                    N/A
   :pypi:`pytest-easy-server`                       Pytest plugin for easy testing against servers                                                                                                                                                            May 01, 2021    4 - Beta               pytest (<5.0.0,>=4.3.1) ; python_version < "3.5"
   :pypi:`pytest-ebics-sandbox`                     A pytest plugin for testing against an EBICS sandbox server. Requires docker.                                                                                                                             Aug 15, 2022    N/A                    N/A
   :pypi:`pytest-ec2`                               Pytest execution on EC2 instance                                                                                                                                                                          Oct 22, 2019    3 - Alpha              N/A
   :pypi:`pytest-echo`                              pytest plugin with mechanisms for echoing environment variables, package version and generic attributes                                                                                                   Jan 08, 2020    5 - Production/Stable  N/A
   :pypi:`pytest-ekstazi`                           Pytest plugin to select test using Ekstazi algorithm                                                                                                                                                      Sep 10, 2022    N/A                    pytest
   :pypi:`pytest-elasticsearch`                     Elasticsearch fixtures and fixture factories for Pytest.                                                                                                                                                  Mar 01, 2022    5 - Production/Stable  pytest (>=6.2.0)
   :pypi:`pytest-elements`                          Tool to help automate user interfaces                                                                                                                                                                     Jan 13, 2021    N/A                    pytest (>=5.4,<6.0)
   :pypi:`pytest-eliot`                             An eliot plugin for pytest.                                                                                                                                                                               Aug 31, 2022    1 - Planning           pytest (>=5.4.0)
   :pypi:`pytest-elk-reporter`                      A simple plugin to use with pytest                                                                                                                                                                        Jan 24, 2021    4 - Beta               pytest (>=3.5.0)
   :pypi:`pytest-email`                             Send execution result email                                                                                                                                                                               Jul 08, 2020    N/A                    pytest
   :pypi:`pytest-embedded`                          A pytest plugin that designed for embedded testing.                                                                                                                                                       Jun 14, 2023    5 - Production/Stable  pytest>=7.0
   :pypi:`pytest-embedded-arduino`                  Make pytest-embedded plugin work with Arduino.                                                                                                                                                            Jun 14, 2023    5 - Production/Stable  N/A
   :pypi:`pytest-embedded-idf`                      Make pytest-embedded plugin work with ESP-IDF.                                                                                                                                                            Jun 14, 2023    5 - Production/Stable  N/A
   :pypi:`pytest-embedded-jtag`                     Make pytest-embedded plugin work with JTAG.                                                                                                                                                               Jun 14, 2023    5 - Production/Stable  N/A
   :pypi:`pytest-embedded-qemu`                     Make pytest-embedded plugin work with QEMU.                                                                                                                                                               Jun 14, 2023    5 - Production/Stable  N/A
   :pypi:`pytest-embedded-serial`                   Make pytest-embedded plugin work with Serial.                                                                                                                                                             Jun 14, 2023    5 - Production/Stable  N/A
   :pypi:`pytest-embedded-serial-esp`               Make pytest-embedded plugin work with Espressif target boards.                                                                                                                                            Jun 14, 2023    5 - Production/Stable  N/A
   :pypi:`pytest-embrace`                           💝  Dataclasses-as-tests. Describe the runtime once and multiply coverage with no boilerplate.                                                                                                            Mar 25, 2023    N/A                    pytest (>=7.0,<8.0)
   :pypi:`pytest-emoji`                             A pytest plugin that adds emojis to your test result report                                                                                                                                               Feb 19, 2019    4 - Beta               pytest (>=4.2.1)
   :pypi:`pytest-emoji-output`                      Pytest plugin to represent test output with emoji support                                                                                                                                                 Apr 09, 2023    4 - Beta               pytest (==7.0.1)
   :pypi:`pytest-enabler`                           Enable installed pytest plugins                                                                                                                                                                           Jun 26, 2023    5 - Production/Stable  pytest (>=6) ; extra == 'testing'
   :pypi:`pytest-encode`                            set your encoding and logger                                                                                                                                                                              Nov 06, 2021    N/A                    N/A
   :pypi:`pytest-encode-kane`                       set your encoding and logger                                                                                                                                                                              Nov 16, 2021    N/A                    pytest
   :pypi:`pytest-enhanced-reports`                  Enhanced test reports for pytest                                                                                                                                                                          Dec 15, 2022    N/A                    N/A
   :pypi:`pytest-enhancements`                      Improvements for pytest (rejected upstream)                                                                                                                                                               Oct 30, 2019    4 - Beta               N/A
   :pypi:`pytest-env`                               py.test plugin that allows you to add environment variables.                                                                                                                                              Jun 15, 2023    5 - Production/Stable  pytest>=7.3.1
   :pypi:`pytest-envfiles`                          A py.test plugin that parses environment files before running tests                                                                                                                                       Oct 08, 2015    3 - Alpha              N/A
   :pypi:`pytest-env-info`                          Push information about the running pytest into envvars                                                                                                                                                    Nov 25, 2017    4 - Beta               pytest (>=3.1.1)
   :pypi:`pytest-envraw`                            py.test plugin that allows you to add environment variables.                                                                                                                                              Aug 27, 2020    4 - Beta               pytest (>=2.6.0)
   :pypi:`pytest-envvars`                           Pytest plugin to validate use of envvars on your tests                                                                                                                                                    Jun 13, 2020    5 - Production/Stable  pytest (>=3.0.0)
   :pypi:`pytest-env-yaml`                                                                                                                                                                                                                                    Apr 02, 2019    N/A                    N/A
   :pypi:`pytest-eradicate`                         pytest plugin to check for commented out code                                                                                                                                                             Sep 08, 2020    N/A                    pytest (>=2.4.2)
   :pypi:`pytest-error-for-skips`                   Pytest plugin to treat skipped tests a test failure                                                                                                                                                       Dec 19, 2019    4 - Beta               pytest (>=4.6)
   :pypi:`pytest-eth`                               PyTest plugin for testing Smart Contracts for Ethereum Virtual Machine (EVM).                                                                                                                             Aug 14, 2020    1 - Planning           N/A
   :pypi:`pytest-ethereum`                          pytest-ethereum: Pytest library for ethereum projects.                                                                                                                                                    Jun 24, 2019    3 - Alpha              pytest (==3.3.2); extra == 'dev'
   :pypi:`pytest-eucalyptus`                        Pytest Plugin for BDD                                                                                                                                                                                     Jun 28, 2022    N/A                    pytest (>=4.2.0)
   :pypi:`pytest-eventlet`                          Applies eventlet monkey-patch as a pytest plugin.                                                                                                                                                         Oct 04, 2021    N/A                    pytest ; extra == 'dev'
   :pypi:`pytest-examples`                          Pytest plugin for testing examples in docstrings and markdown files.                                                                                                                                      May 05, 2023    4 - Beta               pytest>=7
   :pypi:`pytest-excel`                             pytest plugin for generating excel reports                                                                                                                                                                Jan 31, 2022    5 - Production/Stable  N/A
   :pypi:`pytest-exceptional`                       Better exceptions                                                                                                                                                                                         Mar 16, 2017    4 - Beta               N/A
   :pypi:`pytest-exception-script`                  Walk your code through exception script to check it's resiliency to failures.                                                                                                                             Aug 04, 2020    3 - Alpha              pytest
   :pypi:`pytest-executable`                        pytest plugin for testing executables                                                                                                                                                                     Mar 25, 2023    N/A                    pytest (<8,>=4.3)
   :pypi:`pytest-execution-timer`                   A timer for the phases of Pytest's execution.                                                                                                                                                             Dec 24, 2021    4 - Beta               N/A
   :pypi:`pytest-expect`                            py.test plugin to store test expectations and mark tests based on them                                                                                                                                    Apr 21, 2016    4 - Beta               N/A
   :pypi:`pytest-expectdir`                         A pytest plugin to provide initial/expected directories, and check a test transforms the initial directory to the expected one                                                                            Mar 19, 2023    5 - Production/Stable  pytest (>=5.0)
   :pypi:`pytest-expecter`                          Better testing with expecter and pytest.                                                                                                                                                                  Sep 18, 2022    5 - Production/Stable  N/A
   :pypi:`pytest-expectr`                           This plugin is used to expect multiple assert using pytest framework.                                                                                                                                     Oct 05, 2018    N/A                    pytest (>=2.4.2)
   :pypi:`pytest-expect-test`                       A fixture to support expect tests in pytest                                                                                                                                                               Apr 10, 2023    4 - Beta               pytest (>=3.5.0)
   :pypi:`pytest-experiments`                       A pytest plugin to help developers of research-oriented software projects keep track of the results of their numerical experiments.                                                                       Dec 13, 2021    4 - Beta               pytest (>=6.2.5,<7.0.0)
   :pypi:`pytest-explicit`                          A Pytest plugin to ignore certain marked tests by default                                                                                                                                                 Jun 15, 2021    5 - Production/Stable  pytest
   :pypi:`pytest-exploratory`                       Interactive console for pytest.                                                                                                                                                                           Feb 21, 2022    N/A                    pytest (>=6.2)
   :pypi:`pytest-extensions`                        A collection of helpers for pytest to ease testing                                                                                                                                                        Aug 17, 2022    4 - Beta               pytest ; extra == 'testing'
   :pypi:`pytest-external-blockers`                 a special outcome for tests that are blocked for external reasons                                                                                                                                         Oct 05, 2021    N/A                    pytest
   :pypi:`pytest-extra-durations`                   A pytest plugin to get durations on a per-function basis and per module basis.                                                                                                                            Apr 21, 2020    4 - Beta               pytest (>=3.5.0)
   :pypi:`pytest-extra-markers`                     Additional pytest markers to dynamically enable/disable tests viia CLI flags                                                                                                                              Mar 05, 2023    4 - Beta               pytest
   :pypi:`pytest-fabric`                            Provides test utilities to run fabric task tests by using docker containers                                                                                                                               Sep 12, 2018    5 - Production/Stable  N/A
   :pypi:`pytest-factor`                            A package to prevent Dependency Confusion attacks against Yandex.                                                                                                                                         Feb 10, 2023    N/A                    N/A
   :pypi:`pytest-factory`                           Use factories for test setup with py.test                                                                                                                                                                 Sep 06, 2020    3 - Alpha              pytest (>4.3)
   :pypi:`pytest-factoryboy`                        Factory Boy support for pytest.                                                                                                                                                                           Dec 01, 2022    6 - Mature             pytest (>=5.0.0)
   :pypi:`pytest-factoryboy-fixtures`               Generates pytest fixtures that allow the use of type hinting                                                                                                                                              Jun 25, 2020    N/A                    N/A
   :pypi:`pytest-factoryboy-state`                  Simple factoryboy random state management                                                                                                                                                                 Mar 22, 2022    5 - Production/Stable  pytest (>=5.0)
   :pypi:`pytest-failed-screen-record`              Create a video of the screen when pytest fails                                                                                                                                                            Jan 05, 2023    4 - Beta               pytest (>=7.1.2d,<8.0.0)
   :pypi:`pytest-failed-screenshot`                 Test case fails,take a screenshot,save it,attach it to the allure                                                                                                                                         Apr 21, 2021    N/A                    N/A
   :pypi:`pytest-failed-to-verify`                  A pytest plugin that helps better distinguishing real test failures from setup flakiness.                                                                                                                 Aug 08, 2019    5 - Production/Stable  pytest (>=4.1.0)
   :pypi:`pytest-fail-slow`                         Fail tests that take too long to run                                                                                                                                                                      Aug 13, 2022    4 - Beta               pytest (>=6.0)
   :pypi:`pytest-faker`                             Faker integration with the pytest framework.                                                                                                                                                              Dec 19, 2016    6 - Mature             N/A
   :pypi:`pytest-falcon`                            Pytest helpers for Falcon.                                                                                                                                                                                Sep 07, 2016    4 - Beta               N/A
   :pypi:`pytest-falcon-client`                     Pytest \`client\` fixture for the Falcon Framework                                                                                                                                                        Mar 19, 2019    N/A                    N/A
   :pypi:`pytest-fantasy`                           Pytest plugin for Flask Fantasy Framework                                                                                                                                                                 Mar 14, 2019    N/A                    N/A
   :pypi:`pytest-fastapi`                                                                                                                                                                                                                                     Dec 27, 2020    N/A                    N/A
   :pypi:`pytest-fastapi-deps`                      A fixture which allows easy replacement of fastapi dependencies for testing                                                                                                                               Jul 20, 2022    5 - Production/Stable  pytest
   :pypi:`pytest-fastest`                           Use SCM and coverage to run only needed tests                                                                                                                                                             Jun 15, 2023    4 - Beta               pytest (>=4.4)
   :pypi:`pytest-fast-first`                        Pytest plugin that runs fast tests first                                                                                                                                                                  Jan 19, 2023    3 - Alpha              pytest
   :pypi:`pytest-faulthandler`                      py.test plugin that activates the fault handler module for tests (dummy package)                                                                                                                          Jul 04, 2019    6 - Mature             pytest (>=5.0)
   :pypi:`pytest-fauxfactory`                       Integration of fauxfactory into pytest.                                                                                                                                                                   Dec 06, 2017    5 - Production/Stable  pytest (>=3.2)
   :pypi:`pytest-figleaf`                           py.test figleaf coverage plugin                                                                                                                                                                           Jan 18, 2010    5 - Production/Stable  N/A
   :pypi:`pytest-filecov`                           A pytest plugin to detect unused files                                                                                                                                                                    Jun 27, 2021    4 - Beta               pytest
   :pypi:`pytest-filedata`                          easily load data from files                                                                                                                                                                               Jan 17, 2019    4 - Beta               N/A
   :pypi:`pytest-filemarker`                        A pytest plugin that runs marked tests when files change.                                                                                                                                                 Dec 01, 2020    N/A                    pytest
   :pypi:`pytest-file-watcher`                      Pytest-File-Watcher is a CLI tool that watches for changes in your code and runs pytest on the changed files.                                                                                             Mar 23, 2023    N/A                    pytest
   :pypi:`pytest-filter-case`                       run test cases filter by mark                                                                                                                                                                             Nov 05, 2020    N/A                    N/A
   :pypi:`pytest-filter-subpackage`                 Pytest plugin for filtering based on sub-packages                                                                                                                                                         Dec 12, 2022    3 - Alpha              pytest (>=3.0)
   :pypi:`pytest-find-dependencies`                 A pytest plugin to find dependencies between tests                                                                                                                                                        Apr 09, 2022    4 - Beta               pytest (>=4.3.0)
   :pypi:`pytest-finer-verdicts`                    A pytest plugin to treat non-assertion failures as test errors.                                                                                                                                           Jun 18, 2020    N/A                    pytest (>=5.4.3)
   :pypi:`pytest-firefox`                           pytest plugin to manipulate firefox                                                                                                                                                                       Aug 08, 2017    3 - Alpha              pytest (>=3.0.2)
   :pypi:`pytest-fixture-classes`                   Fixtures as classes that work well with dependency injection, autocompletetion, type checkers, and language servers                                                                                       Jan 20, 2023    4 - Beta               pytest
   :pypi:`pytest-fixture-config`                    Fixture configuration utils for py.test                                                                                                                                                                   May 28, 2019    5 - Production/Stable  pytest
   :pypi:`pytest-fixture-maker`                     Pytest plugin to load fixtures from YAML files                                                                                                                                                            Sep 21, 2021    N/A                    N/A
   :pypi:`pytest-fixture-marker`                    A pytest plugin to add markers based on fixtures used.                                                                                                                                                    Oct 11, 2020    5 - Production/Stable  N/A
   :pypi:`pytest-fixture-order`                     pytest plugin to control fixture evaluation order                                                                                                                                                         May 16, 2022    5 - Production/Stable  pytest (>=3.0)
   :pypi:`pytest-fixture-ref`                       Lets users reference fixtures without name matching magic.                                                                                                                                                Nov 17, 2022    4 - Beta               N/A
   :pypi:`pytest-fixture-rtttg`                     Warn or fail on fixture name clash                                                                                                                                                                        Feb 23, 2022    N/A                    pytest (>=7.0.1,<8.0.0)
   :pypi:`pytest-fixtures`                          Common fixtures for pytest                                                                                                                                                                                May 01, 2019    5 - Production/Stable  N/A
   :pypi:`pytest-fixture-tools`                     Plugin for pytest which provides tools for fixtures                                                                                                                                                       Aug 18, 2020    6 - Mature             pytest
   :pypi:`pytest-fixture-typecheck`                 A pytest plugin to assert type annotations at runtime.                                                                                                                                                    Aug 24, 2021    N/A                    pytest
   :pypi:`pytest-flake8`                            pytest plugin to check FLAKE8 requirements                                                                                                                                                                Mar 18, 2022    4 - Beta               pytest (>=7.0)
   :pypi:`pytest-flake8-path`                       A pytest fixture for testing flake8 plugins.                                                                                                                                                              Jun 16, 2023    5 - Production/Stable  pytest
   :pypi:`pytest-flake8-v2`                         pytest plugin to check FLAKE8 requirements                                                                                                                                                                Mar 01, 2022    5 - Production/Stable  pytest (>=7.0)
   :pypi:`pytest-flakefinder`                       Runs tests multiple times to expose flakiness.                                                                                                                                                            Oct 26, 2022    4 - Beta               pytest (>=2.7.1)
   :pypi:`pytest-flakes`                            pytest plugin to check source code with pyflakes                                                                                                                                                          Dec 02, 2021    5 - Production/Stable  pytest (>=5)
   :pypi:`pytest-flaptastic`                        Flaptastic py.test plugin                                                                                                                                                                                 Mar 17, 2019    N/A                    N/A
   :pypi:`pytest-flask`                             A set of py.test fixtures to test Flask applications.                                                                                                                                                     Feb 27, 2021    5 - Production/Stable  pytest (>=5.2)
   :pypi:`pytest-flask-ligand`                      Pytest fixtures and helper functions to use for testing flask-ligand microservices.                                                                                                                       Apr 25, 2023    4 - Beta               pytest (~=7.3)
   :pypi:`pytest-flask-sqlalchemy`                  A pytest plugin for preserving test isolation in Flask-SQlAlchemy using database transactions.                                                                                                            Apr 30, 2022    4 - Beta               pytest (>=3.2.1)
   :pypi:`pytest-flask-sqlalchemy-transactions`     Run tests in transactions using pytest, Flask, and SQLalchemy.                                                                                                                                            Aug 02, 2018    4 - Beta               pytest (>=3.2.1)
   :pypi:`pytest-flexreport`                                                                                                                                                                                                                                  Apr 15, 2023    4 - Beta               pytest
   :pypi:`pytest-fluent`                            A pytest plugin in order to provide logs via fluentd                                                                                                                                                      Jun 26, 2023    4 - Beta               pytest (>=7.0.0)
   :pypi:`pytest-fluentbit`                         A pytest plugin in order to provide logs via fluentbit                                                                                                                                                    Jun 16, 2023    4 - Beta               pytest (>=7.0.0)
   :pypi:`pytest-flyte`                             Pytest fixtures for simplifying Flyte integration testing                                                                                                                                                 May 03, 2021    N/A                    pytest
   :pypi:`pytest-focus`                             A pytest plugin that alerts user of failed test cases with screen notifications                                                                                                                           May 04, 2019    4 - Beta               pytest
   :pypi:`pytest-forbid`                                                                                                                                                                                                                                      Mar 07, 2023    N/A                    pytest (>=7.2.2,<8.0.0)
   :pypi:`pytest-forcefail`                         py.test plugin to make the test failing regardless of pytest.mark.xfail                                                                                                                                   May 15, 2018    4 - Beta               N/A
   :pypi:`pytest-forward-compatability`             A name to avoid typosquating pytest-foward-compatibility                                                                                                                                                  Sep 06, 2020    N/A                    N/A
   :pypi:`pytest-forward-compatibility`             A pytest plugin to shim pytest commandline options for fowards compatibility                                                                                                                              Sep 29, 2020    N/A                    N/A
   :pypi:`pytest-frappe`                            Pytest Frappe Plugin - A set of pytest fixtures to test Frappe applications                                                                                                                               May 03, 2023    4 - Beta               pytest>=7.0.0
   :pypi:`pytest-freezegun`                         Wrap tests with fixtures in freeze_time                                                                                                                                                                   Jul 19, 2020    4 - Beta               pytest (>=3.0.0)
   :pypi:`pytest-freezer`                           Pytest plugin providing a fixture interface for spulec/freezegun                                                                                                                                          Jun 21, 2023    N/A                    pytest >= 3.6
   :pypi:`pytest-freeze-reqs`                       Check if requirement files are frozen                                                                                                                                                                     Apr 29, 2021    N/A                    N/A
   :pypi:`pytest-frozen-uuids`                      Deterministically frozen UUID's for your tests                                                                                                                                                            Apr 17, 2022    N/A                    pytest (>=3.0)
   :pypi:`pytest-func-cov`                          Pytest plugin for measuring function coverage                                                                                                                                                             Apr 15, 2021    3 - Alpha              pytest (>=5)
   :pypi:`pytest-funparam`                          An alternative way to parametrize test cases.                                                                                                                                                             Dec 02, 2021    4 - Beta               pytest >=4.6.0
   :pypi:`pytest-fxa`                               pytest plugin for Firefox Accounts                                                                                                                                                                        Aug 28, 2018    5 - Production/Stable  N/A
   :pypi:`pytest-fxtest`                                                                                                                                                                                                                                      Oct 27, 2020    N/A                    N/A
   :pypi:`pytest-fzf`                               fzf-based test selector for pytest                                                                                                                                                                        Aug 17, 2022    1 - Planning           pytest (>=7.1.2)
   :pypi:`pytest-gather-fixtures`                   set up asynchronous pytest fixtures concurrently                                                                                                                                                          Apr 12, 2022    N/A                    pytest (>=6.0.0)
   :pypi:`pytest-gc`                                The garbage collector plugin for py.test                                                                                                                                                                  Feb 01, 2018    N/A                    N/A
   :pypi:`pytest-gcov`                              Uses gcov to measure test coverage of a C library                                                                                                                                                         Feb 01, 2018    3 - Alpha              N/A
   :pypi:`pytest-gevent`                            Ensure that gevent is properly patched when invoking pytest                                                                                                                                               Feb 25, 2020    N/A                    pytest
   :pypi:`pytest-gherkin`                           A flexible framework for executing BDD gherkin tests                                                                                                                                                      Jul 27, 2019    3 - Alpha              pytest (>=5.0.0)
   :pypi:`pytest-gh-log-group`                      pytest plugin for gh actions                                                                                                                                                                              Jan 11, 2022    3 - Alpha              pytest
   :pypi:`pytest-ghostinspector`                    For finding/executing Ghost Inspector tests                                                                                                                                                               May 17, 2016    3 - Alpha              N/A
   :pypi:`pytest-girder`                            A set of pytest fixtures for testing Girder applications.                                                                                                                                                 Jun 28, 2023    N/A                    N/A
   :pypi:`pytest-git`                               Git repository fixture for py.test                                                                                                                                                                        May 28, 2019    5 - Production/Stable  pytest
   :pypi:`pytest-gitconfig`                         Provide a gitconfig sandbox for testing                                                                                                                                                                   Jun 22, 2023    4 - Beta               pytest>=7.1.2
   :pypi:`pytest-gitcov`                            Pytest plugin for reporting on coverage of the last git commit.                                                                                                                                           Jan 11, 2020    2 - Pre-Alpha          N/A
   :pypi:`pytest-git-fixtures`                      Pytest fixtures for testing with git.                                                                                                                                                                     Mar 11, 2021    4 - Beta               pytest
   :pypi:`pytest-github`                            Plugin for py.test that associates tests with github issues using a marker.                                                                                                                               Mar 07, 2019    5 - Production/Stable  N/A
   :pypi:`pytest-github-actions-annotate-failures`  pytest plugin to annotate failed tests with a workflow command for GitHub Actions                                                                                                                         May 04, 2023    5 - Production/Stable  pytest (>=4.0.0)
   :pypi:`pytest-github-report`                     Generate a GitHub report using pytest in GitHub Workflows                                                                                                                                                 Jun 03, 2022    4 - Beta               N/A
   :pypi:`pytest-gitignore`                         py.test plugin to ignore the same files as git                                                                                                                                                            Jul 17, 2015    4 - Beta               N/A
   :pypi:`pytest-gitlabci-parallelized`             Parallelize pytest across GitLab CI workers.                                                                                                                                                              Mar 08, 2023    N/A                    N/A
   :pypi:`pytest-git-selector`                      Utility to select tests that have had its dependencies modified (as identified by git diff)                                                                                                               Nov 17, 2022    N/A                    N/A
   :pypi:`pytest-glamor-allure`                     Extends allure-pytest functionality                                                                                                                                                                       Jul 22, 2022    4 - Beta               pytest
   :pypi:`pytest-gnupg-fixtures`                    Pytest fixtures for testing with gnupg.                                                                                                                                                                   Mar 04, 2021    4 - Beta               pytest
   :pypi:`pytest-golden`                            Plugin for pytest that offloads expected outputs to data files                                                                                                                                            Jul 18, 2022    N/A                    pytest (>=6.1.2)
   :pypi:`pytest-goldie`                            A plugin to support golden tests with pytest.                                                                                                                                                             May 23, 2023    4 - Beta               pytest (>=3.5.0)
   :pypi:`pytest-google-chat`                       Notify google chat channel for test results                                                                                                                                                               Mar 27, 2022    4 - Beta               pytest
   :pypi:`pytest-graphql-schema`                    Get graphql schema as fixture for pytest                                                                                                                                                                  Oct 18, 2019    N/A                    N/A
   :pypi:`pytest-greendots`                         Green progress dots                                                                                                                                                                                       Feb 08, 2014    3 - Alpha              N/A
   :pypi:`pytest-group-by-class`                    A Pytest plugin for running a subset of your tests by splitting them in to groups of classes.                                                                                                             Jun 27, 2023    5 - Production/Stable  pytest (>=2.5)
   :pypi:`pytest-growl`                             Growl notifications for pytest results.                                                                                                                                                                   Jan 13, 2014    5 - Production/Stable  N/A
   :pypi:`pytest-grpc`                              pytest plugin for grpc                                                                                                                                                                                    May 01, 2020    N/A                    pytest (>=3.6.0)
   :pypi:`pytest-grunnur`                           Py.Test plugin for Grunnur-based packages.                                                                                                                                                                Feb 05, 2023    N/A                    N/A
   :pypi:`pytest-hammertime`                        Display "🔨 " instead of "." for passed pytest tests.                                                                                                                                                     Jul 28, 2018    N/A                    pytest
   :pypi:`pytest-harmony`                           Chain tests and data with pytest                                                                                                                                                                          Jan 17, 2023    N/A                    pytest (>=7.2.1,<8.0.0)
   :pypi:`pytest-harvest`                           Store data created during your pytest tests execution, and retrieve it at the end of the session, e.g. for applicative benchmarking purposes.                                                             Jun 10, 2022    5 - Production/Stable  N/A
   :pypi:`pytest-helm-chart`                        A plugin to provide different types and configs of Kubernetes clusters that can be used for testing.                                                                                                      Jun 15, 2020    4 - Beta               pytest (>=5.4.2,<6.0.0)
   :pypi:`pytest-helm-charts`                       A plugin to provide different types and configs of Kubernetes clusters that can be used for testing.                                                                                                      Mar 08, 2023    4 - Beta               pytest (>=7.1.2,<8.0.0)
   :pypi:`pytest-helper`                            Functions to help in using the pytest testing framework                                                                                                                                                   May 31, 2019    5 - Production/Stable  N/A
   :pypi:`pytest-helpers`                           pytest helpers                                                                                                                                                                                            May 17, 2020    N/A                    pytest
   :pypi:`pytest-helpers-namespace`                 Pytest Helpers Namespace Plugin                                                                                                                                                                           Dec 29, 2021    5 - Production/Stable  pytest (>=6.0.0)
   :pypi:`pytest-hidecaptured`                      Hide captured output                                                                                                                                                                                      May 04, 2018    4 - Beta               pytest (>=2.8.5)
   :pypi:`pytest-historic`                          Custom report to display pytest historical execution records                                                                                                                                              Apr 08, 2020    N/A                    pytest
   :pypi:`pytest-historic-hook`                     Custom listener to store execution results into MYSQL DB, which is used for pytest-historic report                                                                                                        Apr 08, 2020    N/A                    pytest
   :pypi:`pytest-homeassistant`                     A pytest plugin for use with homeassistant custom components.                                                                                                                                             Aug 12, 2020    4 - Beta               N/A
   :pypi:`pytest-homeassistant-custom-component`    Experimental package to automatically extract test plugins for Home Assistant custom components                                                                                                           Jun 24, 2023    3 - Alpha              pytest (==7.3.1)
   :pypi:`pytest-honey`                             A simple plugin to use with pytest                                                                                                                                                                        Jan 07, 2022    4 - Beta               pytest (>=3.5.0)
   :pypi:`pytest-honors`                            Report on tests that honor constraints, and guard against regressions                                                                                                                                     Mar 06, 2020    4 - Beta               N/A
   :pypi:`pytest-hot-reloading`                                                                                                                                                                                                                               Jun 23, 2023    N/A                    N/A
   :pypi:`pytest-hot-test`                          A plugin that tracks test changes                                                                                                                                                                         Dec 10, 2022    4 - Beta               pytest (>=3.5.0)
   :pypi:`pytest-hoverfly`                          Simplify working with Hoverfly from pytest                                                                                                                                                                Jan 30, 2023    N/A                    pytest (>=5.0)
   :pypi:`pytest-hoverfly-wrapper`                  Integrates the Hoverfly HTTP proxy into Pytest                                                                                                                                                            Feb 27, 2023    5 - Production/Stable  pytest (>=3.7.0)
   :pypi:`pytest-hpfeeds`                           Helpers for testing hpfeeds in your python project                                                                                                                                                        Feb 28, 2023    4 - Beta               pytest (>=6.2.4,<7.0.0)
   :pypi:`pytest-html`                              pytest plugin for generating HTML reports                                                                                                                                                                 Apr 08, 2023    5 - Production/Stable  pytest (!=6.0.0,>=5.0)
   :pypi:`pytest-html-lee`                          optimized pytest plugin for generating HTML reports                                                                                                                                                       Jun 30, 2020    5 - Production/Stable  pytest (>=5.0)
   :pypi:`pytest-html-merger`                       Pytest HTML reports merging utility                                                                                                                                                                       Apr 03, 2022    N/A                    N/A
   :pypi:`pytest-html-object-storage`               Pytest report plugin for send HTML report on object-storage                                                                                                                                               Mar 04, 2022    5 - Production/Stable  N/A
   :pypi:`pytest-html-profiling`                    Pytest plugin for generating HTML reports with per-test profiling and optionally call graph visualizations. Based on pytest-html by Dave Hunt.                                                            Feb 11, 2020    5 - Production/Stable  pytest (>=3.0)
   :pypi:`pytest-html-reporter`                     Generates a static html report based on pytest framework                                                                                                                                                  Feb 13, 2022    N/A                    N/A
   :pypi:`pytest-html-report-merger`                                                                                                                                                                                                                          Aug 31, 2022    N/A                    N/A
   :pypi:`pytest-html-thread`                       pytest plugin for generating HTML reports                                                                                                                                                                 Dec 29, 2020    5 - Production/Stable  N/A
   :pypi:`pytest-http`                              Fixture "http" for http requests                                                                                                                                                                          Dec 05, 2019    N/A                    N/A
   :pypi:`pytest-httpbin`                           Easily test your HTTP library against a local copy of httpbin                                                                                                                                             May 08, 2023    5 - Production/Stable  pytest ; extra == 'test'
   :pypi:`pytest-httpdbg`                           A pytest plugin to record HTTP(S) requests with stack trace                                                                                                                                               May 09, 2023    3 - Alpha              pytest (>=7.0.0)
   :pypi:`pytest-http-mocker`                       Pytest plugin for http mocking (via https://github.com/vilus/mocker)                                                                                                                                      Oct 20, 2019    N/A                    N/A
   :pypi:`pytest-httpretty`                         A thin wrapper of HTTPretty for pytest                                                                                                                                                                    Feb 16, 2014    3 - Alpha              N/A
   :pypi:`pytest-httpserver`                        pytest-httpserver is a httpserver for pytest                                                                                                                                                              May 22, 2023    3 - Alpha              N/A
   :pypi:`pytest-httptesting`                       http_testing framework on top of pytest                                                                                                                                                                   Jun 03, 2023    N/A                    pytest (>=7.2.0,<8.0.0)
   :pypi:`pytest-httpx`                             Send responses to httpx.                                                                                                                                                                                  Apr 12, 2023    5 - Production/Stable  pytest (<8.0,>=6.0)
   :pypi:`pytest-httpx-blockage`                    Disable httpx requests during a test run                                                                                                                                                                  Feb 16, 2023    N/A                    pytest (>=7.2.1)
   :pypi:`pytest-hue`                               Visualise PyTest status via your Phillips Hue lights                                                                                                                                                      May 09, 2019    N/A                    N/A
   :pypi:`pytest-hylang`                            Pytest plugin to allow running tests written in hylang                                                                                                                                                    Mar 28, 2021    N/A                    pytest
   :pypi:`pytest-hypo-25`                           help hypo module for pytest                                                                                                                                                                               Jan 12, 2020    3 - Alpha              N/A
   :pypi:`pytest-ibutsu`                            A plugin to sent pytest results to an Ibutsu server                                                                                                                                                       Aug 05, 2022    4 - Beta               pytest>=7.1
   :pypi:`pytest-icdiff`                            use icdiff for better error messages in pytest assertions                                                                                                                                                 Aug 09, 2022    4 - Beta               N/A
   :pypi:`pytest-idapro`                            A pytest plugin for idapython. Allows a pytest setup to run tests outside and inside IDA in an automated manner by runnig pytest inside IDA and by mocking idapython api                                  Nov 03, 2018    N/A                    N/A
   :pypi:`pytest-idem`                              A pytest plugin to help with testing idem projects                                                                                                                                                        Jun 23, 2023    5 - Production/Stable  N/A
   :pypi:`pytest-idempotent`                        Pytest plugin for testing function idempotence.                                                                                                                                                           Jul 25, 2022    N/A                    N/A
   :pypi:`pytest-ignore-flaky`                      ignore failures from flaky tests (pytest plugin)                                                                                                                                                          Apr 23, 2021    5 - Production/Stable  N/A
   :pypi:`pytest-image-diff`                                                                                                                                                                                                                                  Mar 09, 2023    3 - Alpha              pytest
   :pypi:`pytest-incremental`                       an incremental test runner (pytest plugin)                                                                                                                                                                Apr 24, 2021    5 - Production/Stable  N/A
   :pypi:`pytest-influxdb`                          Plugin for influxdb and pytest integration.                                                                                                                                                               Apr 20, 2021    N/A                    N/A
   :pypi:`pytest-info-collector`                    pytest plugin to collect information from tests                                                                                                                                                           May 26, 2019    3 - Alpha              N/A
   :pypi:`pytest-informative-node`                  display more node ininformation.                                                                                                                                                                          Apr 25, 2019    4 - Beta               N/A
   :pypi:`pytest-infrastructure`                    pytest stack validation prior to testing executing                                                                                                                                                        Apr 12, 2020    4 - Beta               N/A
   :pypi:`pytest-ini`                               Reuse pytest.ini to store env variables                                                                                                                                                                   Apr 26, 2022    N/A                    N/A
   :pypi:`pytest-inline`                            A pytest plugin for writing inline tests.                                                                                                                                                                 Feb 08, 2023    4 - Beta               pytest (>=7.0.0)
   :pypi:`pytest-inmanta`                           A py.test plugin providing fixtures to simplify inmanta modules testing.                                                                                                                                  Feb 23, 2023    5 - Production/Stable  N/A
   :pypi:`pytest-inmanta-extensions`                Inmanta tests package                                                                                                                                                                                     Apr 12, 2023    5 - Production/Stable  N/A
   :pypi:`pytest-inmanta-lsm`                       Common fixtures for inmanta LSM related modules                                                                                                                                                           May 17, 2023    5 - Production/Stable  N/A
   :pypi:`pytest-inmanta-yang`                      Common fixtures used in inmanta yang related modules                                                                                                                                                      Jun 16, 2022    4 - Beta               N/A
   :pypi:`pytest-Inomaly`                           A simple image diff plugin for pytest                                                                                                                                                                     Feb 13, 2018    4 - Beta               N/A
   :pypi:`pytest-insta`                             A practical snapshot testing plugin for pytest                                                                                                                                                            Nov 02, 2022    N/A                    pytest (>=7.2.0,<8.0.0)
   :pypi:`pytest-instafail`                         pytest plugin to show failures instantly                                                                                                                                                                  Mar 31, 2023    4 - Beta               pytest (>=5)
   :pypi:`pytest-instrument`                        pytest plugin to instrument tests                                                                                                                                                                         Apr 05, 2020    5 - Production/Stable  pytest (>=5.1.0)
   :pypi:`pytest-integration`                       Organizing pytests by integration or not                                                                                                                                                                  Nov 17, 2022    N/A                    N/A
   :pypi:`pytest-integration-mark`                  Automatic integration test marking and excluding plugin for pytest                                                                                                                                        May 22, 2023    N/A                    pytest (>=5.2)
   :pypi:`pytest-interactive`                       A pytest plugin for console based interactive test selection just after the collection phase                                                                                                              Nov 30, 2017    3 - Alpha              N/A
   :pypi:`pytest-intercept-remote`                  Pytest plugin for intercepting outgoing connection requests during pytest run.                                                                                                                            May 24, 2021    4 - Beta               pytest (>=4.6)
   :pypi:`pytest-interface-tester`                  Pytest plugin for checking charm relation interface protocol compliance.                                                                                                                                  Jun 29, 2023    4 - Beta               pytest
   :pypi:`pytest-invenio`                           Pytest fixtures for Invenio.                                                                                                                                                                              Jun 02, 2023    5 - Production/Stable  pytest (<7.2.0,>=6)
   :pypi:`pytest-involve`                           Run tests covering a specific file or changeset                                                                                                                                                           Feb 02, 2020    4 - Beta               pytest (>=3.5.0)
   :pypi:`pytest-ipdb`                              A py.test plug-in to enable drop to ipdb debugger on test failure.                                                                                                                                        Mar 20, 2013    2 - Pre-Alpha          N/A
   :pypi:`pytest-ipynb`                             THIS PROJECT IS ABANDONED                                                                                                                                                                                 Jan 29, 2019    3 - Alpha              N/A
   :pypi:`pytest-isolate`                                                                                                                                                                                                                                     Feb 20, 2023    4 - Beta               pytest
   :pypi:`pytest-isort`                             py.test plugin to check import ordering using isort                                                                                                                                                       Oct 31, 2022    5 - Production/Stable  pytest (>=5.0)
   :pypi:`pytest-is-running`                        pytest plugin providing a function to check if pytest is running.                                                                                                                                         Jun 16, 2023    5 - Production/Stable  N/A
   :pypi:`pytest-it`                                Pytest plugin to display test reports as a plaintext spec, inspired by Rspec: https://github.com/mattduck/pytest-it.                                                                                      Jan 22, 2020    4 - Beta               N/A
   :pypi:`pytest-iterassert`                        Nicer list and iterable assertion messages for pytest                                                                                                                                                     May 11, 2020    3 - Alpha              N/A
   :pypi:`pytest-iters`                             A contextmanager pytest fixture for handling multiple mock iters                                                                                                                                          May 24, 2022    N/A                    N/A
   :pypi:`pytest-jasmine`                           Run jasmine tests from your pytest test suite                                                                                                                                                             Nov 04, 2017    1 - Planning           N/A
   :pypi:`pytest-jelastic`                          Pytest plugin defining the necessary command-line options to pass to pytests testing a Jelastic environment.                                                                                              Nov 16, 2022    N/A                    pytest (>=7.2.0,<8.0.0)
   :pypi:`pytest-jest`                              A custom jest-pytest oriented Pytest reporter                                                                                                                                                             May 22, 2018    4 - Beta               pytest (>=3.3.2)
   :pypi:`pytest-jinja`                             A plugin to generate customizable jinja-based HTML reports in pytest                                                                                                                                      Oct 04, 2022    3 - Alpha              pytest (>=6.2.5,<7.0.0)
   :pypi:`pytest-jira`                              py.test JIRA integration plugin, using markers                                                                                                                                                            Jun 12, 2023    3 - Alpha              N/A
   :pypi:`pytest-jira-xfail`                        Plugin skips (xfail) tests if unresolved Jira issue(s) linked                                                                                                                                             Jun 19, 2023    N/A                    pytest (>=7.2.0)
   :pypi:`pytest-jira-xray`                         pytest plugin to integrate tests with JIRA XRAY                                                                                                                                                           Jun 06, 2023    4 - Beta               pytest
   :pypi:`pytest-job-selection`                     A pytest plugin for load balancing test suites                                                                                                                                                            Jan 30, 2023    4 - Beta               pytest (>=3.5.0)
   :pypi:`pytest-jobserver`                         Limit parallel tests with posix jobserver.                                                                                                                                                                May 15, 2019    5 - Production/Stable  pytest
   :pypi:`pytest-joke`                              Test failures are better served with humor.                                                                                                                                                               Oct 08, 2019    4 - Beta               pytest (>=4.2.1)
   :pypi:`pytest-json`                              Generate JSON test reports                                                                                                                                                                                Jan 18, 2016    4 - Beta               N/A
   :pypi:`pytest-json-fixtures`                     JSON output for the --fixtures flag                                                                                                                                                                       Mar 14, 2023    4 - Beta               N/A
   :pypi:`pytest-jsonlint`                          UNKNOWN                                                                                                                                                                                                   Aug 04, 2016    N/A                    N/A
   :pypi:`pytest-json-report`                       A pytest plugin to report test results as JSON files                                                                                                                                                      Mar 15, 2022    4 - Beta               pytest (>=3.8.0)
   :pypi:`pytest-jtr`                               pytest plugin supporting json test report output                                                                                                                                                          Nov 29, 2022    N/A                    pytest (>=7.1.2,<8.0.0)
   :pypi:`pytest-jupyter`                           A pytest plugin for testing Jupyter libraries and extensions.                                                                                                                                             Mar 30, 2023    4 - Beta               pytest
   :pypi:`pytest-jupyterhub`                        A reusable JupyterHub pytest plugin                                                                                                                                                                       Apr 25, 2023    5 - Production/Stable  pytest
   :pypi:`pytest-kafka`                             Zookeeper, Kafka server, and Kafka consumer fixtures for Pytest                                                                                                                                           Jun 14, 2023    N/A                    pytest
   :pypi:`pytest-kafkavents`                        A plugin to send pytest events to Kafka                                                                                                                                                                   Sep 08, 2021    4 - Beta               pytest
   :pypi:`pytest-kasima`                            Display horizontal lines above and below the captured standard output for easy viewing.                                                                                                                   Jan 26, 2023    5 - Production/Stable  pytest (>=7.2.1,<8.0.0)
   :pypi:`pytest-keep-together`                     Pytest plugin to customize test ordering by running all 'related' tests together                                                                                                                          Dec 07, 2022    5 - Production/Stable  pytest
   :pypi:`pytest-kexi`                                                                                                                                                                                                                                        Apr 29, 2022    N/A                    pytest (>=7.1.2,<8.0.0)
   :pypi:`pytest-kind`                              Kubernetes test support with KIND for pytest                                                                                                                                                              Nov 30, 2022    5 - Production/Stable  N/A
   :pypi:`pytest-kivy`                              Kivy GUI tests fixtures using pytest                                                                                                                                                                      Jul 06, 2021    4 - Beta               pytest (>=3.6)
   :pypi:`pytest-knows`                             A pytest plugin that can automaticly skip test case based on dependence info calculated by trace                                                                                                          Aug 22, 2014    N/A                    N/A
   :pypi:`pytest-konira`                            Run Konira DSL tests with py.test                                                                                                                                                                         Oct 09, 2011    N/A                    N/A
   :pypi:`pytest-koopmans`                          A plugin for testing the koopmans package                                                                                                                                                                 Nov 21, 2022    4 - Beta               pytest (>=3.5.0)
   :pypi:`pytest-krtech-common`                     pytest krtech common library                                                                                                                                                                              Nov 28, 2016    4 - Beta               N/A
   :pypi:`pytest-kubernetes`                                                                                                                                                                                                                                  May 17, 2023    N/A                    pytest (>=7.2.1,<8.0.0)
   :pypi:`pytest-kwparametrize`                     Alternate syntax for @pytest.mark.parametrize with test cases as dictionaries and default value fallbacks                                                                                                 Jan 22, 2021    N/A                    pytest (>=6)
   :pypi:`pytest-lambda`                            Define pytest fixtures with lambda functions.                                                                                                                                                             Aug 20, 2022    3 - Alpha              pytest (>=3.6,<8)
   :pypi:`pytest-lamp`                                                                                                                                                                                                                                        Jan 06, 2017    3 - Alpha              N/A
   :pypi:`pytest-langchain`                         Pytest-style test runner for langchain agents                                                                                                                                                             Feb 26, 2023    N/A                    pytest
   :pypi:`pytest-lark`                              A package for enhancing pytest                                                                                                                                                                            Nov 20, 2022    N/A                    N/A
   :pypi:`pytest-launchable`                        Launchable Pytest Plugin                                                                                                                                                                                  Apr 05, 2023    N/A                    pytest (>=4.2.0)
   :pypi:`pytest-layab`                             Pytest fixtures for layab.                                                                                                                                                                                Oct 05, 2020    5 - Production/Stable  N/A
   :pypi:`pytest-lazy-fixture`                      It helps to use fixtures in pytest.mark.parametrize                                                                                                                                                       Feb 01, 2020    4 - Beta               pytest (>=3.2.5)
   :pypi:`pytest-lazy-fixtures`                     Allows you to use fixtures in @pytest.mark.parametrize.                                                                                                                                                   May 28, 2023    N/A                    pytest (>=7.2.1,<8.0.0)
   :pypi:`pytest-ldap`                              python-ldap fixtures for pytest                                                                                                                                                                           Aug 18, 2020    N/A                    pytest
   :pypi:`pytest-leak-finder`                       Find the test that's leaking before the one that fails                                                                                                                                                    Feb 15, 2023    4 - Beta               pytest (>=3.5.0)
   :pypi:`pytest-leaks`                             A pytest plugin to trace resource leaks.                                                                                                                                                                  Nov 27, 2019    1 - Planning           N/A
   :pypi:`pytest-level`                             Select tests of a given level or lower                                                                                                                                                                    Oct 21, 2019    N/A                    pytest
   :pypi:`pytest-libfaketime`                       A python-libfaketime plugin for pytest.                                                                                                                                                                   Dec 22, 2018    4 - Beta               pytest (>=3.0.0)
   :pypi:`pytest-libiio`                            A pytest plugin to manage interfacing with libiio contexts                                                                                                                                                Jul 11, 2022    4 - Beta               N/A
   :pypi:`pytest-libnotify`                         Pytest plugin that shows notifications about the test run                                                                                                                                                 Apr 02, 2021    3 - Alpha              pytest
   :pypi:`pytest-ligo`                                                                                                                                                                                                                                        Jan 16, 2020    4 - Beta               N/A
   :pypi:`pytest-lineno`                            A pytest plugin to show the line numbers of test functions                                                                                                                                                Dec 04, 2020    N/A                    pytest
   :pypi:`pytest-line-profiler`                     Profile code executed by pytest                                                                                                                                                                           May 03, 2021    4 - Beta               pytest (>=3.5.0)
   :pypi:`pytest-line-profiler-apn`                 Profile code executed by pytest                                                                                                                                                                           Dec 05, 2022    N/A                    pytest (>=3.5.0)
   :pypi:`pytest-lisa`                              Pytest plugin for organizing tests.                                                                                                                                                                       Jan 21, 2021    3 - Alpha              pytest (>=6.1.2,<7.0.0)
   :pypi:`pytest-listener`                          A simple network listener                                                                                                                                                                                 May 28, 2019    5 - Production/Stable  pytest
   :pypi:`pytest-litf`                              A pytest plugin that stream output in LITF format                                                                                                                                                         Jan 18, 2021    4 - Beta               pytest (>=3.1.1)
   :pypi:`pytest-live`                              Live results for pytest                                                                                                                                                                                   Mar 08, 2020    N/A                    pytest
   :pypi:`pytest-local-badge`                       Generate local badges (shields) reporting your test suite status.                                                                                                                                         Jan 15, 2023    N/A                    pytest (>=6.1.0)
   :pypi:`pytest-localftpserver`                    A PyTest plugin which provides an FTP fixture for your tests                                                                                                                                              Oct 04, 2022    5 - Production/Stable  pytest
   :pypi:`pytest-localserver`                       pytest plugin to test server connections locally.                                                                                                                                                         Jan 30, 2023    4 - Beta               N/A
   :pypi:`pytest-localstack`                        Pytest plugin for AWS integration tests                                                                                                                                                                   Jun 07, 2023    4 - Beta               pytest (>=6.0.0,<7.0.0)
   :pypi:`pytest-lockable`                          lockable resource plugin for pytest                                                                                                                                                                       Jul 20, 2022    5 - Production/Stable  pytest
   :pypi:`pytest-locker`                            Used to lock object during testing. Essentially changing assertions from being hard coded to asserting that nothing changed                                                                               Oct 29, 2021    N/A                    pytest (>=5.4)
   :pypi:`pytest-log`                               print log                                                                                                                                                                                                 Aug 15, 2021    N/A                    pytest (>=3.8)
   :pypi:`pytest-logbook`                           py.test plugin to capture logbook log messages                                                                                                                                                            Nov 23, 2015    5 - Production/Stable  pytest (>=2.8)
   :pypi:`pytest-logdog`                            Pytest plugin to test logging                                                                                                                                                                             Jun 15, 2021    1 - Planning           pytest (>=6.2.0)
   :pypi:`pytest-logfest`                           Pytest plugin providing three logger fixtures with basic or full writing to log files                                                                                                                     Jul 21, 2019    4 - Beta               pytest (>=3.5.0)
   :pypi:`pytest-logger`                            Plugin configuring handlers for loggers from Python logging module.                                                                                                                                       Jul 25, 2019    4 - Beta               pytest (>=3.2)
   :pypi:`pytest-logging`                           Configures logging and allows tweaking the log level with a py.test flag                                                                                                                                  Nov 04, 2015    4 - Beta               N/A
   :pypi:`pytest-logging-end-to-end-test-tool`                                                                                                                                                                                                                Sep 23, 2022    N/A                    pytest (>=7.1.2,<8.0.0)
   :pypi:`pytest-logikal`                           Common testing environment                                                                                                                                                                                Jun 22, 2023    5 - Production/Stable  pytest (==7.3.1)
   :pypi:`pytest-log-report`                        Package for creating a pytest test run reprot                                                                                                                                                             Dec 26, 2019    N/A                    N/A
   :pypi:`pytest-loguru`                            Pytest Loguru                                                                                                                                                                                             Apr 12, 2022    5 - Production/Stable  N/A
   :pypi:`pytest-loop`                              pytest plugin for looping tests                                                                                                                                                                           Jul 22, 2022    5 - Production/Stable  pytest (>=6)
   :pypi:`pytest-lsp`                               pytest plugin for end-to-end testing of language servers                                                                                                                                                  May 19, 2023    3 - Alpha              pytest
   :pypi:`pytest-manual-marker`                     pytest marker for marking manual tests                                                                                                                                                                    Aug 04, 2022    3 - Alpha              pytest>=7
   :pypi:`pytest-markdoctest`                       A pytest plugin to doctest your markdown files                                                                                                                                                            Jul 22, 2022    4 - Beta               pytest (>=6)
   :pypi:`pytest-markdown`                          Test your markdown docs with pytest                                                                                                                                                                       Jan 15, 2021    4 - Beta               pytest (>=6.0.1,<7.0.0)
   :pypi:`pytest-markdown-docs`                     Run markdown code fences through pytest                                                                                                                                                                   Mar 09, 2023    N/A                    N/A
   :pypi:`pytest-marker-bugzilla`                   py.test bugzilla integration plugin, using markers                                                                                                                                                        Jan 09, 2020    N/A                    N/A
   :pypi:`pytest-markers-presence`                  A simple plugin to detect missed pytest tags and markers"                                                                                                                                                 Feb 04, 2021    4 - Beta               pytest (>=6.0)
   :pypi:`pytest-markfiltration`                    UNKNOWN                                                                                                                                                                                                   Nov 08, 2011    3 - Alpha              N/A
   :pypi:`pytest-mark-no-py3`                       pytest plugin and bowler codemod to help migrate tests to Python 3                                                                                                                                        May 17, 2019    N/A                    pytest
   :pypi:`pytest-marks`                             UNKNOWN                                                                                                                                                                                                   Nov 23, 2012    3 - Alpha              N/A
   :pypi:`pytest-matcher`                           Match test output against patterns stored in files                                                                                                                                                        Dec 10, 2021    5 - Production/Stable  N/A
   :pypi:`pytest-match-skip`                        Skip matching marks. Matches partial marks using wildcards.                                                                                                                                               May 15, 2019    4 - Beta               pytest (>=4.4.1)
   :pypi:`pytest-mat-report`                        this is report                                                                                                                                                                                            Jan 20, 2021    N/A                    N/A
   :pypi:`pytest-matrix`                            Provide tools for generating tests from combinations of fixtures.                                                                                                                                         Jun 24, 2020    5 - Production/Stable  pytest (>=5.4.3,<6.0.0)
   :pypi:`pytest-maybe-context`                     Simplify tests with warning and exception cases.                                                                                                                                                          Apr 16, 2023    N/A                    pytest (>=7,<8)
   :pypi:`pytest-maybe-raises`                      Pytest fixture for optional exception testing.                                                                                                                                                            May 27, 2022    N/A                    pytest ; extra == 'dev'
   :pypi:`pytest-mccabe`                            pytest plugin to run the mccabe code complexity checker.                                                                                                                                                  Jul 22, 2020    3 - Alpha              pytest (>=5.4.0)
   :pypi:`pytest-md`                                Plugin for generating Markdown reports for pytest results                                                                                                                                                 Jul 11, 2019    3 - Alpha              pytest (>=4.2.1)
   :pypi:`pytest-md-report`                         A pytest plugin to make a test results report with Markdown table format.                                                                                                                                 Jun 25, 2023    4 - Beta               pytest (!=6.0.0,<8,>=3.3.2)
   :pypi:`pytest-memlog`                            Log memory usage during tests                                                                                                                                                                             May 03, 2023    N/A                    pytest (>=7.3.0,<8.0.0)
   :pypi:`pytest-memprof`                           Estimates memory consumption of test functions                                                                                                                                                            Mar 29, 2019    4 - Beta               N/A
   :pypi:`pytest-memray`                            A simple plugin to use with pytest                                                                                                                                                                        Jun 06, 2023    N/A                    pytest>=7.2
   :pypi:`pytest-menu`                              A pytest plugin for console based interactive test selection just after the collection phase                                                                                                              Oct 04, 2017    3 - Alpha              pytest (>=2.4.2)
   :pypi:`pytest-mercurial`                         pytest plugin to write integration tests for projects using Mercurial Python internals                                                                                                                    Nov 21, 2020    1 - Planning           N/A
   :pypi:`pytest-mesh`                              pytest_mesh插件                                                                                                                                                                                           Aug 05, 2022    N/A                    pytest (==7.1.2)
   :pypi:`pytest-message`                           Pytest plugin for sending report message of marked tests execution                                                                                                                                        Aug 04, 2022    N/A                    pytest (>=6.2.5)
   :pypi:`pytest-messenger`                         Pytest to Slack reporting plugin                                                                                                                                                                          Nov 24, 2022    5 - Production/Stable  N/A
   :pypi:`pytest-metadata`                          pytest plugin for test session metadata                                                                                                                                                                   May 27, 2023    5 - Production/Stable  pytest>=7.0.0
   :pypi:`pytest-metrics`                           Custom metrics report for pytest                                                                                                                                                                          Apr 04, 2020    N/A                    pytest
   :pypi:`pytest-mh`                                Pytest multihost plugin                                                                                                                                                                                   Jun 08, 2023    N/A                    pytest
   :pypi:`pytest-mimesis`                           Mimesis integration with the pytest test runner                                                                                                                                                           Mar 21, 2020    5 - Production/Stable  pytest (>=4.2)
   :pypi:`pytest-minecraft`                         A pytest plugin for running tests against Minecraft releases                                                                                                                                              Apr 06, 2022    N/A                    pytest (>=6.0.1)
   :pypi:`pytest-mini`                              A plugin to test mp                                                                                                                                                                                       Feb 06, 2023    N/A                    pytest (>=7.2.0,<8.0.0)
   :pypi:`pytest-missing-fixtures`                  Pytest plugin that creates missing fixtures                                                                                                                                                               Oct 14, 2020    4 - Beta               pytest (>=3.5.0)
   :pypi:`pytest-ml`                                Test your machine learning!                                                                                                                                                                               May 04, 2019    4 - Beta               N/A
   :pypi:`pytest-mocha`                             pytest plugin to display test execution output like a mochajs                                                                                                                                             Apr 02, 2020    4 - Beta               pytest (>=5.4.0)
   :pypi:`pytest-mock`                              Thin-wrapper around the mock package for easier use with pytest                                                                                                                                           Jun 15, 2023    5 - Production/Stable  pytest (>=5.0)
   :pypi:`pytest-mock-api`                          A mock API server with configurable routes and responses available as a fixture.                                                                                                                          Feb 13, 2019    1 - Planning           pytest (>=4.0.0)
   :pypi:`pytest-mock-generator`                    A pytest fixture wrapper for https://pypi.org/project/mock-generator                                                                                                                                      May 16, 2022    5 - Production/Stable  N/A
   :pypi:`pytest-mock-helper`                       Help you mock HTTP call and generate mock code                                                                                                                                                            Jan 24, 2018    N/A                    pytest
   :pypi:`pytest-mockito`                           Base fixtures for mockito                                                                                                                                                                                 Jul 11, 2018    4 - Beta               N/A
   :pypi:`pytest-mockredis`                         An in-memory mock of a Redis server that runs in a separate thread. This is to be used for unit-tests that require a Redis database.                                                                      Jan 02, 2018    2 - Pre-Alpha          N/A
   :pypi:`pytest-mock-resources`                    A pytest plugin for easily instantiating reproducible mock resources.                                                                                                                                     Jun 09, 2023    N/A                    pytest (>=1.0)
   :pypi:`pytest-mock-server`                       Mock server plugin for pytest                                                                                                                                                                             Jan 09, 2022    4 - Beta               pytest (>=3.5.0)
   :pypi:`pytest-mockservers`                       A set of fixtures to test your requests to HTTP/UDP servers                                                                                                                                               Mar 31, 2020    N/A                    pytest (>=4.3.0)
   :pypi:`pytest-mocktcp`                           A pytest plugin for testing TCP clients                                                                                                                                                                   Oct 11, 2022    N/A                    pytest
   :pypi:`pytest-modified-env`                      Pytest plugin to fail a test if it leaves modified \`os.environ\` afterwards.                                                                                                                             Jan 29, 2022    4 - Beta               N/A
   :pypi:`pytest-modifyjunit`                       Utility for adding additional properties to junit xml for IDM QE                                                                                                                                          Jan 10, 2019    N/A                    N/A
   :pypi:`pytest-modifyscope`                       pytest plugin to modify fixture scope                                                                                                                                                                     Apr 12, 2020    N/A                    pytest
   :pypi:`pytest-molecule`                          PyTest Molecule Plugin :: discover and run molecule tests                                                                                                                                                 Mar 29, 2022    5 - Production/Stable  pytest (>=7.0.0)
   :pypi:`pytest-mongo`                             MongoDB process and client fixtures plugin for Pytest.                                                                                                                                                    Jun 07, 2021    5 - Production/Stable  pytest
   :pypi:`pytest-mongodb`                           pytest plugin for MongoDB fixtures                                                                                                                                                                        May 16, 2023    5 - Production/Stable  N/A
   :pypi:`pytest-monitor`                           Pytest plugin for analyzing resource usage.                                                                                                                                                               Jun 25, 2023    5 - Production/Stable  pytest
   :pypi:`pytest-monkeyplus`                        pytest's monkeypatch subclass with extra functionalities                                                                                                                                                  Sep 18, 2012    5 - Production/Stable  N/A
   :pypi:`pytest-monkeytype`                        pytest-monkeytype: Generate Monkeytype annotations from your pytest tests.                                                                                                                                Jul 29, 2020    4 - Beta               N/A
   :pypi:`pytest-moto`                              Fixtures for integration tests of AWS services,uses moto mocking library.                                                                                                                                 Aug 28, 2015    1 - Planning           N/A
   :pypi:`pytest-motor`                             A pytest plugin for motor, the non-blocking MongoDB driver.                                                                                                                                               Jul 21, 2021    3 - Alpha              pytest
   :pypi:`pytest-mp`                                A test batcher for multiprocessed Pytest runs                                                                                                                                                             May 23, 2018    4 - Beta               pytest
   :pypi:`pytest-mpi`                               pytest plugin to collect information from tests                                                                                                                                                           Jan 08, 2022    3 - Alpha              pytest
   :pypi:`pytest-mpiexec`                           pytest plugin for running individual tests with mpiexec                                                                                                                                                   Apr 13, 2023    3 - Alpha              pytest
   :pypi:`pytest-mpl`                               pytest plugin to help with testing figures output from Matplotlib                                                                                                                                         Jul 23, 2022    4 - Beta               pytest
   :pypi:`pytest-mproc`                             low-startup-overhead, scalable, distributed-testing pytest plugin                                                                                                                                         Nov 15, 2022    4 - Beta               pytest (>=6)
   :pypi:`pytest-mqtt`                              pytest-mqtt supports testing systems based on MQTT                                                                                                                                                        Mar 15, 2023    4 - Beta               pytest (<8) ; extra == 'test'
   :pypi:`pytest-multihost`                         Utility for writing multi-host tests for pytest                                                                                                                                                           Apr 07, 2020    4 - Beta               N/A
   :pypi:`pytest-multilog`                          Multi-process logs handling and other helpers for pytest                                                                                                                                                  Jan 17, 2023    N/A                    pytest
   :pypi:`pytest-multithreading`                    a pytest plugin for th and concurrent testing                                                                                                                                                             Dec 07, 2022    N/A                    N/A
   :pypi:`pytest-multithreading-allure`             pytest_multithreading_allure                                                                                                                                                                              Nov 25, 2022    N/A                    N/A
   :pypi:`pytest-mutagen`                           Add the mutation testing feature to pytest                                                                                                                                                                Jul 24, 2020    N/A                    pytest (>=5.4)
   :pypi:`pytest-mypy`                              Mypy static type checker plugin for Pytest                                                                                                                                                                Dec 18, 2022    4 - Beta               pytest (>=6.2) ; python_version >= "3.10"
   :pypi:`pytest-mypyd`                             Mypy static type checker plugin for Pytest                                                                                                                                                                Aug 20, 2019    4 - Beta               pytest (<4.7,>=2.8) ; python_version < "3.5"
   :pypi:`pytest-mypy-plugins`                      pytest plugin for writing tests for mypy plugins                                                                                                                                                          Jun 29, 2023    4 - Beta               pytest (>=7.0.0)
   :pypi:`pytest-mypy-plugins-shim`                 Substitute for "pytest-mypy-plugins" for Python implementations which aren't supported by mypy.                                                                                                           Apr 12, 2021    N/A                    pytest>=6.0.0
   :pypi:`pytest-mypy-testing`                      Pytest plugin to check mypy output.                                                                                                                                                                       Feb 25, 2023    N/A                    pytest>=7,<8
   :pypi:`pytest-mysql`                             MySQL process and client fixtures for pytest                                                                                                                                                              Mar 27, 2023    5 - Production/Stable  pytest (>=6.2)
   :pypi:`pytest-needle`                            pytest plugin for visual testing websites using selenium                                                                                                                                                  Dec 10, 2018    4 - Beta               pytest (<5.0.0,>=3.0.0)
   :pypi:`pytest-neo`                               pytest-neo is a plugin for pytest that shows tests like screen of Matrix.                                                                                                                                 Jan 08, 2022    3 - Alpha              pytest (>=6.2.0)
   :pypi:`pytest-netdut`                            "Automated software testing for switches using pytest"                                                                                                                                                    Jun 19, 2023    N/A                    pytest (>=3.5.0)
   :pypi:`pytest-network`                           A simple plugin to disable network on socket level.                                                                                                                                                       May 07, 2020    N/A                    N/A
   :pypi:`pytest-network-endpoints`                 Network endpoints plugin for pytest                                                                                                                                                                       Mar 06, 2022    N/A                    pytest
   :pypi:`pytest-never-sleep`                       pytest plugin helps to avoid adding tests without mock \`time.sleep\`                                                                                                                                     May 05, 2021    3 - Alpha              pytest (>=3.5.1)
   :pypi:`pytest-nginx`                             nginx fixture for pytest                                                                                                                                                                                  Aug 12, 2017    5 - Production/Stable  N/A
   :pypi:`pytest-nginx-iplweb`                      nginx fixture for pytest - iplweb temporary fork                                                                                                                                                          Mar 01, 2019    5 - Production/Stable  N/A
   :pypi:`pytest-ngrok`                                                                                                                                                                                                                                       Jan 20, 2022    3 - Alpha              pytest
   :pypi:`pytest-ngsfixtures`                       pytest ngs fixtures                                                                                                                                                                                       Sep 06, 2019    2 - Pre-Alpha          pytest (>=5.0.0)
   :pypi:`pytest-nhsd-apim`                         Pytest plugin accessing NHSDigital's APIM proxies                                                                                                                                                         Jun 07, 2023    N/A                    pytest (==6.2.5)
   :pypi:`pytest-nice`                              A pytest plugin that alerts user of failed test cases with screen notifications                                                                                                                           May 04, 2019    4 - Beta               pytest
   :pypi:`pytest-nice-parametrize`                  A small snippet for nicer PyTest's Parametrize                                                                                                                                                            Apr 17, 2021    5 - Production/Stable  N/A
   :pypi:`pytest-nlcov`                             Pytest plugin to get the coverage of the new lines (based on git diff) only                                                                                                                               Jul 07, 2021    N/A                    N/A
   :pypi:`pytest-nocustom`                          Run all tests without custom markers                                                                                                                                                                      Jul 07, 2021    5 - Production/Stable  N/A
   :pypi:`pytest-nodev`                             Test-driven source code search for Python.                                                                                                                                                                Jul 21, 2016    4 - Beta               pytest (>=2.8.1)
   :pypi:`pytest-nogarbage`                         Ensure a test produces no garbage                                                                                                                                                                         Aug 29, 2021    5 - Production/Stable  pytest (>=4.6.0)
   :pypi:`pytest-notice`                            Send pytest execution result email                                                                                                                                                                        Nov 05, 2020    N/A                    N/A
   :pypi:`pytest-notification`                      A pytest plugin for sending a desktop notification and playing a sound upon completion of tests                                                                                                           Jun 19, 2020    N/A                    pytest (>=4)
   :pypi:`pytest-notifier`                          A pytest plugin to notify test result                                                                                                                                                                     Jun 12, 2020    3 - Alpha              pytest
   :pypi:`pytest-notimplemented`                    Pytest markers for not implemented features and tests.                                                                                                                                                    Aug 27, 2019    N/A                    pytest (>=5.1,<6.0)
   :pypi:`pytest-notion`                            A PyTest Reporter to send test runs to Notion.so                                                                                                                                                          Aug 07, 2019    N/A                    N/A
   :pypi:`pytest-nunit`                             A pytest plugin for generating NUnit3 test result XML output                                                                                                                                              Oct 20, 2022    5 - Production/Stable  pytest (>=4.6.0)
   :pypi:`pytest-oar`                               PyTest plugin for the OAR testing framework                                                                                                                                                               May 02, 2023    N/A                    pytest>=6.0.1
   :pypi:`pytest-object-getter`                     Import any object from a 3rd party module while mocking its namespace on demand.                                                                                                                          Jul 31, 2022    5 - Production/Stable  pytest
   :pypi:`pytest-ochrus`                            pytest results data-base and HTML reporter                                                                                                                                                                Feb 21, 2018    4 - Beta               N/A
   :pypi:`pytest-odoo`                              py.test plugin to run Odoo tests                                                                                                                                                                          Nov 17, 2022    4 - Beta               pytest (>=7.2.0)
   :pypi:`pytest-odoo-fixtures`                     Project description                                                                                                                                                                                       Jun 25, 2019    N/A                    N/A
   :pypi:`pytest-oerp`                              pytest plugin to test OpenERP modules                                                                                                                                                                     Feb 28, 2012    3 - Alpha              N/A
   :pypi:`pytest-offline`                                                                                                                                                                                                                                     Mar 09, 2023    1 - Planning           pytest (>=7.0.0,<8.0.0)
   :pypi:`pytest-ogsm-plugin`                       针对特定项目定制化插件，优化了pytest报告展示方式,并添加了项目所需特定参数                                                                                                                                 May 16, 2023    N/A                    N/A
   :pypi:`pytest-ok`                                The ultimate pytest output plugin                                                                                                                                                                         Apr 01, 2019    4 - Beta               N/A
   :pypi:`pytest-only`                              Use @pytest.mark.only to run a single test                                                                                                                                                                Jun 14, 2022    5 - Production/Stable  pytest (<7.1); python_version <= "3.6"
   :pypi:`pytest-oot`                               Run object-oriented tests in a simple format                                                                                                                                                              Sep 18, 2016    4 - Beta               N/A
   :pypi:`pytest-openfiles`                         Pytest plugin for detecting inadvertent open file handles                                                                                                                                                 Apr 16, 2020    3 - Alpha              pytest (>=4.6)
   :pypi:`pytest-opentelemetry`                     A pytest plugin for instrumenting test runs via OpenTelemetry                                                                                                                                             Mar 15, 2023    N/A                    pytest
   :pypi:`pytest-opentmi`                           pytest plugin for publish results to opentmi                                                                                                                                                              Jun 02, 2022    5 - Production/Stable  pytest (>=5.0)
   :pypi:`pytest-operator`                          Fixtures for Operators                                                                                                                                                                                    Sep 28, 2022    N/A                    pytest
   :pypi:`pytest-optional`                          include/exclude values of fixtures in pytest                                                                                                                                                              Oct 07, 2015    N/A                    N/A
   :pypi:`pytest-optional-tests`                    Easy declaration of optional tests (i.e., that are not run by default)                                                                                                                                    Jul 09, 2019    4 - Beta               pytest (>=4.5.0)
   :pypi:`pytest-orchestration`                     A pytest plugin for orchestrating tests                                                                                                                                                                   Jul 18, 2019    N/A                    N/A
   :pypi:`pytest-order`                             pytest plugin to run your tests in a specific order                                                                                                                                                       Mar 10, 2023    4 - Beta               pytest (>=5.0) ; python_version < "3.10"
   :pypi:`pytest-ordering`                          pytest plugin to run your tests in a specific order                                                                                                                                                       Nov 14, 2018    4 - Beta               pytest
   :pypi:`pytest-order-modify`                      新增run_marker 来自定义用例的执行顺序                                                                                                                                                                     Nov 04, 2022    N/A                    N/A
   :pypi:`pytest-osxnotify`                         OS X notifications for py.test results.                                                                                                                                                                   May 15, 2015    N/A                    N/A
   :pypi:`pytest-otel`                              pytest-otel report OpenTelemetry traces about test executed                                                                                                                                               Jan 18, 2023    N/A                    N/A
   :pypi:`pytest-override-env-var`                  Pytest mark to override a value of an environment variable.                                                                                                                                               Feb 25, 2023    N/A                    N/A
   :pypi:`pytest-owner`                             Add owner mark for tests                                                                                                                                                                                  Apr 25, 2022    N/A                    N/A
   :pypi:`pytest-pact`                              A simple plugin to use with pytest                                                                                                                                                                        Jan 07, 2019    4 - Beta               N/A
   :pypi:`pytest-pahrametahrize`                    Parametrize your tests with a Boston accent.                                                                                                                                                              Nov 24, 2021    4 - Beta               pytest (>=6.0,<7.0)
   :pypi:`pytest-parallel`                          a pytest plugin for parallel and concurrent testing                                                                                                                                                       Oct 10, 2021    3 - Alpha              pytest (>=3.0.0)
   :pypi:`pytest-parallel-39`                       a pytest plugin for parallel and concurrent testing                                                                                                                                                       Jul 12, 2021    3 - Alpha              pytest (>=3.0.0)
   :pypi:`pytest-parallelize-tests`                 pytest plugin that parallelizes test execution across multiple hosts                                                                                                                                      Jan 27, 2023    4 - Beta               N/A
   :pypi:`pytest-param`                             pytest plugin to test all, first, last or random params                                                                                                                                                   Sep 11, 2016    4 - Beta               pytest (>=2.6.0)
   :pypi:`pytest-paramark`                          Configure pytest fixtures using a combination of"parametrize" and markers                                                                                                                                 Jan 10, 2020    4 - Beta               pytest (>=4.5.0)
   :pypi:`pytest-parametrization`                   Simpler PyTest parametrization                                                                                                                                                                            May 22, 2022    5 - Production/Stable  N/A
   :pypi:`pytest-parametrize-cases`                 A more user-friendly way to write parametrized tests.                                                                                                                                                     Mar 13, 2022    N/A                    pytest (>=6.1.2)
   :pypi:`pytest-parametrized`                      Pytest decorator for parametrizing tests with default iterables.                                                                                                                                          Sep 13, 2022    5 - Production/Stable  pytest
   :pypi:`pytest-parametrize-suite`                 A simple pytest extension for creating a named test suite.                                                                                                                                                Jan 19, 2023    5 - Production/Stable  pytest
   :pypi:`pytest-parawtf`                           Finally spell paramete?ri[sz]e correctly                                                                                                                                                                  Dec 03, 2018    4 - Beta               pytest (>=3.6.0)
   :pypi:`pytest-pass`                              Check out https://github.com/elilutsky/pytest-pass                                                                                                                                                        Dec 04, 2019    N/A                    N/A
   :pypi:`pytest-passrunner`                        Pytest plugin providing the 'run_on_pass' marker                                                                                                                                                          Feb 10, 2021    5 - Production/Stable  pytest (>=4.6.0)
   :pypi:`pytest-paste-config`                      Allow setting the path to a paste config file                                                                                                                                                             Sep 18, 2013    3 - Alpha              N/A
   :pypi:`pytest-patch`                             An automagic \`patch\` fixture that can patch objects directly or by name.                                                                                                                                Apr 29, 2023    3 - Alpha              pytest (>=7.0.0)
   :pypi:`pytest-patches`                           A contextmanager pytest fixture for handling multiple mock patches                                                                                                                                        Aug 30, 2021    4 - Beta               pytest (>=3.5.0)
   :pypi:`pytest-pdb`                               pytest plugin which adds pdb helper commands related to pytest.                                                                                                                                           Jul 31, 2018    N/A                    N/A
   :pypi:`pytest-peach`                             pytest plugin for fuzzing with Peach API Security                                                                                                                                                         Apr 12, 2019    4 - Beta               pytest (>=2.8.7)
   :pypi:`pytest-pep257`                            py.test plugin for pep257                                                                                                                                                                                 Jul 09, 2016    N/A                    N/A
   :pypi:`pytest-pep8`                              pytest plugin to check PEP8 requirements                                                                                                                                                                  Apr 27, 2014    N/A                    N/A
   :pypi:`pytest-percent`                           Change the exit code of pytest test sessions when a required percent of tests pass.                                                                                                                       May 21, 2020    N/A                    pytest (>=5.2.0)
   :pypi:`pytest-perf`                              Run performance tests against the mainline code.                                                                                                                                                          Jun 02, 2023    5 - Production/Stable  pytest (>=6) ; extra == 'testing'
   :pypi:`pytest-performance`                       A simple plugin to ensure the execution of critical sections of code has not been impacted                                                                                                                Sep 11, 2020    5 - Production/Stable  pytest (>=3.7.0)
   :pypi:`pytest-persistence`                       Pytest tool for persistent objects                                                                                                                                                                        Jun 14, 2023    N/A                    N/A
   :pypi:`pytest-pg`                                A tiny plugin for pytest which runs PostgreSQL in Docker                                                                                                                                                  May 04, 2023    5 - Production/Stable  pytest (>=6.0.0)
   :pypi:`pytest-pgsql`                             Pytest plugins and helpers for tests using a Postgres database.                                                                                                                                           May 13, 2020    5 - Production/Stable  pytest (>=3.0.0)
   :pypi:`pytest-phmdoctest`                        pytest plugin to test Python examples in Markdown using phmdoctest.                                                                                                                                       Apr 15, 2022    4 - Beta               pytest (>=5.4.3)
   :pypi:`pytest-picked`                            Run the tests related to the changed files                                                                                                                                                                Dec 23, 2020    N/A                    pytest (>=3.5.0)
   :pypi:`pytest-pigeonhole`                                                                                                                                                                                                                                  Jun 25, 2018    5 - Production/Stable  pytest (>=3.4)
   :pypi:`pytest-pikachu`                           Show surprise when tests are passing                                                                                                                                                                      Aug 05, 2021    5 - Production/Stable  pytest
   :pypi:`pytest-pilot`                             Slice in your test base thanks to powerful markers.                                                                                                                                                       Oct 09, 2020    5 - Production/Stable  N/A
   :pypi:`pytest-pingguo-pytest-plugin`             pingguo test                                                                                                                                                                                              Oct 26, 2022    4 - Beta               N/A
   :pypi:`pytest-pings`                             🦊 The pytest plugin for Firefox Telemetry 📊                                                                                                                                                             Jun 29, 2019    3 - Alpha              pytest (>=5.0.0)
   :pypi:`pytest-pinned`                            A simple pytest plugin for pinning tests                                                                                                                                                                  Sep 17, 2021    4 - Beta               pytest (>=3.5.0)
   :pypi:`pytest-pinpoint`                          A pytest plugin which runs SBFL algorithms to detect faults.                                                                                                                                              Sep 25, 2020    N/A                    pytest (>=4.4.0)
   :pypi:`pytest-pipeline`                          Pytest plugin for functional testing of data analysispipelines                                                                                                                                            Jan 24, 2017    3 - Alpha              N/A
   :pypi:`pytest-platform-markers`                  Markers for pytest to skip tests on specific platforms                                                                                                                                                    Sep 09, 2019    4 - Beta               pytest (>=3.6.0)
   :pypi:`pytest-play`                              pytest plugin that let you automate actions and assertions with test metrics reporting executing plain YAML files                                                                                         Jun 12, 2019    5 - Production/Stable  N/A
   :pypi:`pytest-playbook`                          Pytest plugin for reading playbooks.                                                                                                                                                                      Jan 21, 2021    3 - Alpha              pytest (>=6.1.2,<7.0.0)
   :pypi:`pytest-playwright`                        A pytest wrapper with fixtures for Playwright to automate web browsers                                                                                                                                    Apr 24, 2023    N/A                    pytest (<8.0.0,>=6.2.4)
   :pypi:`pytest-playwright-async`                  ASYNC Pytest plugin for Playwright                                                                                                                                                                        Jun 26, 2023    N/A                    N/A
   :pypi:`pytest-playwrights`                       A pytest wrapper with fixtures for Playwright to automate web browsers                                                                                                                                    Dec 02, 2021    N/A                    N/A
   :pypi:`pytest-playwright-snapshot`               A pytest wrapper for snapshot testing with playwright                                                                                                                                                     Aug 19, 2021    N/A                    N/A
   :pypi:`pytest-playwright-visual`                 A pytest fixture for visual testing with Playwright                                                                                                                                                       Apr 28, 2022    N/A                    N/A
   :pypi:`pytest-plone`                             Pytest plugin to test Plone addons                                                                                                                                                                        Jan 05, 2023    3 - Alpha              pytest
   :pypi:`pytest-plt`                               Fixtures for quickly making Matplotlib plots in tests                                                                                                                                                     Aug 17, 2020    5 - Production/Stable  pytest
   :pypi:`pytest-plugin-helpers`                    A plugin to help developing and testing other plugins                                                                                                                                                     Nov 23, 2019    4 - Beta               pytest (>=3.5.0)
   :pypi:`pytest-plus`                              PyTest Plus Plugin :: extends pytest functionality                                                                                                                                                        Dec 24, 2022    5 - Production/Stable  pytest (>=6.0.1)
   :pypi:`pytest-pmisc`                                                                                                                                                                                                                                       Mar 21, 2019    5 - Production/Stable  N/A
   :pypi:`pytest-pointers`                          Pytest plugin to define functions you test with special marks for better navigation and reports                                                                                                           Dec 26, 2022    N/A                    N/A
   :pypi:`pytest-pokie`                             Pokie plugin for pytest                                                                                                                                                                                   May 22, 2023    5 - Production/Stable  N/A
   :pypi:`pytest-polarion-cfme`                     pytest plugin for collecting test cases and recording test results                                                                                                                                        Nov 13, 2017    3 - Alpha              N/A
   :pypi:`pytest-polarion-collect`                  pytest plugin for collecting polarion test cases data                                                                                                                                                     Jun 18, 2020    3 - Alpha              pytest
   :pypi:`pytest-polecat`                           Provides Polecat pytest fixtures                                                                                                                                                                          Aug 12, 2019    4 - Beta               N/A
   :pypi:`pytest-ponyorm`                           PonyORM in Pytest                                                                                                                                                                                         Oct 31, 2018    N/A                    pytest (>=3.1.1)
   :pypi:`pytest-poo`                               Visualize your crappy tests                                                                                                                                                                               Mar 25, 2021    5 - Production/Stable  pytest (>=2.3.4)
   :pypi:`pytest-poo-fail`                          Visualize your failed tests with poo                                                                                                                                                                      Feb 12, 2015    5 - Production/Stable  N/A
   :pypi:`pytest-pop`                               A pytest plugin to help with testing pop projects                                                                                                                                                         May 09, 2023    5 - Production/Stable  pytest
   :pypi:`pytest-porringer`                                                                                                                                                                                                                                   Jun 24, 2023    N/A                    pytest>=7.1.2
   :pypi:`pytest-portion`                           Select a portion of the collected tests                                                                                                                                                                   Jan 28, 2021    4 - Beta               pytest (>=3.5.0)
   :pypi:`pytest-postgres`                          Run PostgreSQL in Docker container in Pytest.                                                                                                                                                             Mar 22, 2020    N/A                    pytest
   :pypi:`pytest-postgresql`                        Postgresql fixtures and fixture factories for Pytest.                                                                                                                                                     May 20, 2023    5 - Production/Stable  pytest (>=6.2)
   :pypi:`pytest-pot`                               A package for enhancing pytest                                                                                                                                                                            Nov 20, 2022    N/A                    N/A
   :pypi:`pytest-power`                             pytest plugin with powerful fixtures                                                                                                                                                                      Dec 31, 2020    N/A                    pytest (>=5.4)
   :pypi:`pytest-prefer-nested-dup-tests`           A Pytest plugin to drop duplicated tests during collection, but will prefer keeping nested packages.                                                                                                      Apr 27, 2022    4 - Beta               pytest (>=7.1.1,<8.0.0)
   :pypi:`pytest-pretty`                            pytest plugin for printing summary data as I want it                                                                                                                                                      Apr 05, 2023    5 - Production/Stable  pytest>=7
   :pypi:`pytest-pretty-terminal`                   pytest plugin for generating prettier terminal output                                                                                                                                                     Jan 31, 2022    N/A                    pytest (>=3.4.1)
   :pypi:`pytest-pride`                             Minitest-style test colors                                                                                                                                                                                Apr 02, 2016    3 - Alpha              N/A
   :pypi:`pytest-print`                             pytest-print adds the printer fixture you can use to print messages to the user (directly to the pytest runner, not stdout)                                                                               Jun 28, 2023    5 - Production/Stable  pytest>=7.3.2
   :pypi:`pytest-profiles`                          pytest plugin for configuration profiles                                                                                                                                                                  Dec 09, 2021    4 - Beta               pytest (>=3.7.0)
   :pypi:`pytest-profiling`                         Profiling plugin for py.test                                                                                                                                                                              May 28, 2019    5 - Production/Stable  pytest
   :pypi:`pytest-progress`                          pytest plugin for instant test progress status                                                                                                                                                            Jan 31, 2022    5 - Production/Stable  N/A
   :pypi:`pytest-prometheus`                        Report test pass / failures to a Prometheus PushGateway                                                                                                                                                   Oct 03, 2017    N/A                    N/A
   :pypi:`pytest-prometheus-pushgateway`            Pytest report plugin for Zulip                                                                                                                                                                            Sep 27, 2022    5 - Production/Stable  pytest
   :pypi:`pytest-prosper`                           Test helpers for Prosper projects                                                                                                                                                                         Sep 24, 2018    N/A                    N/A
   :pypi:`pytest-pspec`                             A rspec format reporter for Python ptest                                                                                                                                                                  Jun 02, 2020    4 - Beta               pytest (>=3.0.0)
   :pypi:`pytest-psqlgraph`                         pytest plugin for testing applications that use psqlgraph                                                                                                                                                 Oct 19, 2021    4 - Beta               pytest (>=6.0)
   :pypi:`pytest-ptera`                             Use ptera probes in tests                                                                                                                                                                                 Mar 01, 2022    N/A                    pytest (>=6.2.4,<7.0.0)
   :pypi:`pytest-pudb`                              Pytest PuDB debugger integration                                                                                                                                                                          Oct 25, 2018    3 - Alpha              pytest (>=2.0)
   :pypi:`pytest-pumpkin-spice`                     A pytest plugin that makes your test reporting pumpkin-spiced                                                                                                                                             Sep 18, 2022    4 - Beta               N/A
   :pypi:`pytest-purkinje`                          py.test plugin for purkinje test runner                                                                                                                                                                   Oct 28, 2017    2 - Pre-Alpha          N/A
   :pypi:`pytest-pusher`                            pytest plugin for push report to minio                                                                                                                                                                    Jan 06, 2023    5 - Production/Stable  pytest (>=3.6)
   :pypi:`pytest-py125`                                                                                                                                                                                                                                       Dec 03, 2022    N/A                    N/A
   :pypi:`pytest-pycharm`                           Plugin for py.test to enter PyCharm debugger on uncaught exceptions                                                                                                                                       Aug 13, 2020    5 - Production/Stable  pytest (>=2.3)
   :pypi:`pytest-pycodestyle`                       pytest plugin to run pycodestyle                                                                                                                                                                          Oct 28, 2022    3 - Alpha              N/A
   :pypi:`pytest-pydev`                             py.test plugin to connect to a remote debug server with PyDev or PyCharm.                                                                                                                                 Nov 15, 2017    3 - Alpha              N/A
   :pypi:`pytest-pydocstyle`                        pytest plugin to run pydocstyle                                                                                                                                                                           Jan 05, 2023    3 - Alpha              N/A
   :pypi:`pytest-pylint`                            pytest plugin to check source code with pylint                                                                                                                                                            Sep 10, 2022    5 - Production/Stable  pytest (>=5.4)
   :pypi:`pytest-pymysql-autorecord`                Record PyMySQL queries and mock with the stored data.                                                                                                                                                     Sep 02, 2022    N/A                    N/A
   :pypi:`pytest-pyodide`                           "Pytest plugin for testing applications that use Pyodide"                                                                                                                                                 Jun 19, 2023    N/A                    pytest
   :pypi:`pytest-pypi`                              Easily test your HTTP library against a local copy of pypi                                                                                                                                                Mar 04, 2018    3 - Alpha              N/A
   :pypi:`pytest-pypom-navigation`                  Core engine for cookiecutter-qa and pytest-play packages                                                                                                                                                  Feb 18, 2019    4 - Beta               pytest (>=3.0.7)
   :pypi:`pytest-pyppeteer`                         A plugin to run pyppeteer in pytest                                                                                                                                                                       Apr 28, 2022    N/A                    pytest (>=6.2.5,<7.0.0)
   :pypi:`pytest-pyq`                               Pytest fixture "q" for pyq                                                                                                                                                                                Mar 10, 2020    5 - Production/Stable  N/A
   :pypi:`pytest-pyramid`                           pytest_pyramid - provides fixtures for testing pyramid applications with pytest test suite                                                                                                                Dec 13, 2022    5 - Production/Stable  pytest
   :pypi:`pytest-pyramid-server`                    Pyramid server fixture for py.test                                                                                                                                                                        May 28, 2019    5 - Production/Stable  pytest
   :pypi:`pytest-pyreport`                          PyReport is a lightweight reporting plugin for Pytest that provides concise HTML report                                                                                                                   May 08, 2023    N/A                    pytest (>=7.3.1)
   :pypi:`pytest-pyright`                           Pytest plugin for type checking code with Pyright                                                                                                                                                         Nov 20, 2022    4 - Beta               pytest (>=7.0.0)
   :pypi:`pytest-pyspec`                            A plugin that transforms the pytest output into a result similar to the RSpec. It enables the use of docstrings to display results and also enables the use of the prefixes "describe", "with" and "it".  Mar 12, 2023    5 - Production/Stable  pytest (>=7.2.1,<8.0.0)
   :pypi:`pytest-pystack`                           Plugin to run pystack after a timeout for a test suite.                                                                                                                                                   May 07, 2023    N/A                    pytest (>=3.5.0)
   :pypi:`pytest-pytestrail`                        Pytest plugin for interaction with TestRail                                                                                                                                                               Aug 27, 2020    4 - Beta               pytest (>=3.8.0)
   :pypi:`pytest-pythonpath`                        pytest plugin for adding to the PYTHONPATH from command line or configs.                                                                                                                                  Feb 10, 2022    5 - Production/Stable  pytest (<7,>=2.5.2)
   :pypi:`pytest-pytorch`                           pytest plugin for a better developer experience when working with the PyTorch test suite                                                                                                                  May 25, 2021    4 - Beta               pytest
   :pypi:`pytest-pyvista`                           Pytest-pyvista package                                                                                                                                                                                    Mar 19, 2023    4 - Beta               pytest>=3.5.0
   :pypi:`pytest-qaseio`                            Pytest plugin for Qase.io integration                                                                                                                                                                     May 11, 2023    4 - Beta               pytest (>=7.2.2,<8.0.0)
   :pypi:`pytest-qasync`                            Pytest support for qasync.                                                                                                                                                                                Jul 12, 2021    4 - Beta               pytest (>=5.4.0)
   :pypi:`pytest-qatouch`                           Pytest plugin for uploading test results to your QA Touch Testrun.                                                                                                                                        Feb 14, 2023    4 - Beta               pytest (>=6.2.0)
   :pypi:`pytest-qgis`                              A pytest plugin for testing QGIS python plugins                                                                                                                                                           Jun 30, 2023    5 - Production/Stable  pytest (>=6.2.5)
   :pypi:`pytest-qml`                               Run QML Tests with pytest                                                                                                                                                                                 Dec 02, 2020    4 - Beta               pytest (>=6.0.0)
   :pypi:`pytest-qr`                                pytest plugin to generate test result QR codes                                                                                                                                                            Nov 25, 2021    4 - Beta               N/A
   :pypi:`pytest-qt`                                pytest support for PyQt and PySide applications                                                                                                                                                           Oct 25, 2022    5 - Production/Stable  pytest (>=3.0.0)
   :pypi:`pytest-qt-app`                            QT app fixture for py.test                                                                                                                                                                                Dec 23, 2015    5 - Production/Stable  N/A
   :pypi:`pytest-quarantine`                        A plugin for pytest to manage expected test failures                                                                                                                                                      Nov 24, 2019    5 - Production/Stable  pytest (>=4.6)
   :pypi:`pytest-quickcheck`                        pytest plugin to generate random data inspired by QuickCheck                                                                                                                                              Nov 05, 2022    4 - Beta               pytest (>=4.0)
   :pypi:`pytest-rabbitmq`                          RabbitMQ process and client fixtures for pytest                                                                                                                                                           Jun 16, 2023    5 - Production/Stable  pytest (>=6.2)
   :pypi:`pytest-race`                              Race conditions tester for pytest                                                                                                                                                                         Jun 07, 2022    4 - Beta               N/A
   :pypi:`pytest-rage`                              pytest plugin to implement PEP712                                                                                                                                                                         Oct 21, 2011    3 - Alpha              N/A
   :pypi:`pytest-rail`                              pytest plugin for creating TestRail runs and adding results                                                                                                                                               May 02, 2022    N/A                    pytest (>=3.6)
   :pypi:`pytest-railflow-testrail-reporter`        Generate json reports along with specified metadata defined in test markers.                                                                                                                              Jun 29, 2022    5 - Production/Stable  pytest
   :pypi:`pytest-raises`                            An implementation of pytest.raises as a pytest.mark fixture                                                                                                                                               Apr 23, 2020    N/A                    pytest (>=3.2.2)
   :pypi:`pytest-raisesregexp`                      Simple pytest plugin to look for regex in Exceptions                                                                                                                                                      Dec 18, 2015    N/A                    N/A
   :pypi:`pytest-raisin`                            Plugin enabling the use of exception instances with pytest.raises                                                                                                                                         Feb 06, 2022    N/A                    pytest
   :pypi:`pytest-random`                            py.test plugin to randomize tests                                                                                                                                                                         Apr 28, 2013    3 - Alpha              N/A
   :pypi:`pytest-randomly`                          Pytest plugin to randomly order tests and control random.seed.                                                                                                                                            May 11, 2022    5 - Production/Stable  pytest
   :pypi:`pytest-randomness`                        Pytest plugin about random seed management                                                                                                                                                                May 30, 2019    3 - Alpha              N/A
   :pypi:`pytest-random-num`                        Randomise the order in which pytest tests are run with some control over the randomness                                                                                                                   Oct 19, 2020    5 - Production/Stable  N/A
   :pypi:`pytest-random-order`                      Randomise the order in which pytest tests are run with some control over the randomness                                                                                                                   Dec 03, 2022    5 - Production/Stable  pytest (>=3.0.0)
   :pypi:`pytest-readme`                            Test your README.md file                                                                                                                                                                                  Sep 02, 2022    5 - Production/Stable  N/A
   :pypi:`pytest-reana`                             Pytest fixtures for REANA.                                                                                                                                                                                Dec 13, 2022    3 - Alpha              N/A
   :pypi:`pytest-recorder`                          Pytest plugin, meant to facilitate unit tests writing for tools consumming Web APIs.                                                                                                                      Mar 30, 2023    N/A                    N/A
   :pypi:`pytest-recording`                         A pytest plugin that allows you recording of network interactions via VCR.py                                                                                                                              Feb 16, 2023    4 - Beta               pytest (>=3.5.0)
   :pypi:`pytest-recordings`                        Provides pytest plugins for reporting request/response traffic, screenshots, and more to ReportPortal                                                                                                     Aug 13, 2020    N/A                    N/A
   :pypi:`pytest-redis`                             Redis fixtures and fixture factories for Pytest.                                                                                                                                                          Apr 19, 2023    5 - Production/Stable  pytest (>=6.2)
   :pypi:`pytest-redislite`                         Pytest plugin for testing code using Redis                                                                                                                                                                Apr 05, 2022    4 - Beta               pytest
   :pypi:`pytest-redmine`                           Pytest plugin for redmine                                                                                                                                                                                 Mar 19, 2018    1 - Planning           N/A
   :pypi:`pytest-ref`                               A plugin to store reference files to ease regression testing                                                                                                                                              Nov 23, 2019    4 - Beta               pytest (>=3.5.0)
   :pypi:`pytest-reference-formatter`               Conveniently run pytest with a dot-formatted test reference.                                                                                                                                              Oct 01, 2019    4 - Beta               N/A
   :pypi:`pytest-regex`                             Select pytest tests with regular expressions                                                                                                                                                              May 29, 2023    4 - Beta               pytest (>=3.5.0)
   :pypi:`pytest-regex-dependency`                  Management of Pytest dependencies via regex patterns                                                                                                                                                      Jun 12, 2022    N/A                    pytest
   :pypi:`pytest-regressions`                       Easy to use fixtures to write regression tests.                                                                                                                                                           Jan 13, 2023    5 - Production/Stable  pytest (>=6.2.0)
   :pypi:`pytest-regtest`                           pytest plugin for regression tests                                                                                                                                                                        Jul 08, 2022    N/A                    N/A
   :pypi:`pytest-relative-order`                    a pytest plugin that sorts tests using "before" and "after" markers                                                                                                                                       May 17, 2021    4 - Beta               N/A
   :pypi:`pytest-relaxed`                           Relaxed test discovery/organization for pytest                                                                                                                                                            May 23, 2023    5 - Production/Stable  pytest (>=7)
   :pypi:`pytest-remfiles`                          Pytest plugin to create a temporary directory with remote files                                                                                                                                           Jul 01, 2019    5 - Production/Stable  N/A
   :pypi:`pytest-remotedata`                        Pytest plugin for controlling remote data access.                                                                                                                                                         Dec 12, 2022    3 - Alpha              pytest (>=4.6)
   :pypi:`pytest-remote-response`                   Pytest plugin for capturing and mocking connection requests.                                                                                                                                              Apr 26, 2023    5 - Production/Stable  pytest (>=4.6)
   :pypi:`pytest-remove-stale-bytecode`             py.test plugin to remove stale byte code files.                                                                                                                                                           Mar 04, 2020    4 - Beta               pytest
   :pypi:`pytest-reorder`                           Reorder tests depending on their paths and names.                                                                                                                                                         May 31, 2018    4 - Beta               pytest
   :pypi:`pytest-repeat`                            pytest plugin for repeating tests                                                                                                                                                                         Oct 31, 2020    5 - Production/Stable  pytest (>=3.6)
   :pypi:`pytest-replay`                            Saves previous test runs and allow re-execute previous pytest runs to reproduce crashes or flaky tests                                                                                                    Jun 09, 2021    4 - Beta               pytest (>=3.0.0)
   :pypi:`pytest-repo-health`                       A pytest plugin to report on repository standards conformance                                                                                                                                             Apr 17, 2023    3 - Alpha              pytest
   :pypi:`pytest-report`                            Creates json report that is compatible with atom.io's linter message format                                                                                                                               May 11, 2016    4 - Beta               N/A
   :pypi:`pytest-reporter`                          Generate Pytest reports with templates                                                                                                                                                                    Jul 22, 2021    4 - Beta               pytest
   :pypi:`pytest-reporter-html1`                    A basic HTML report template for Pytest                                                                                                                                                                   Jun 05, 2023    4 - Beta               N/A
   :pypi:`pytest-reporter-html-dots`                A basic HTML report for pytest using Jinja2 template engine.                                                                                                                                              Jan 22, 2023    N/A                    N/A
   :pypi:`pytest-reportinfra`                       Pytest plugin for reportinfra                                                                                                                                                                             Aug 11, 2019    3 - Alpha              N/A
   :pypi:`pytest-reporting`                         A plugin to report summarized results in a table format                                                                                                                                                   Oct 25, 2019    4 - Beta               pytest (>=3.5.0)
   :pypi:`pytest-reportlog`                         Replacement for the --resultlog option, focused in simplicity and extensibility                                                                                                                           May 22, 2023    3 - Alpha              pytest
   :pypi:`pytest-report-me`                         A pytest plugin to generate report.                                                                                                                                                                       Dec 31, 2020    N/A                    pytest
   :pypi:`pytest-report-parameters`                 pytest plugin for adding tests' parameters to junit report                                                                                                                                                Jun 18, 2020    3 - Alpha              pytest (>=2.4.2)
   :pypi:`pytest-reportportal`                      Agent for Reporting results of tests to the Report Portal                                                                                                                                                 Jun 30, 2023    N/A                    pytest (>=3.8.0)
   :pypi:`pytest-reports`                           An interesting python package                                                                                                                                                                             Jun 07, 2023    N/A                    N/A
   :pypi:`pytest-reqs`                              pytest plugin to check pinned requirements                                                                                                                                                                May 12, 2019    N/A                    pytest (>=2.4.2)
   :pypi:`pytest-requests`                          A simple plugin to use with pytest                                                                                                                                                                        Jun 24, 2019    4 - Beta               pytest (>=3.5.0)
   :pypi:`pytest-requestselapsed`                   collect and show http requests elapsed time                                                                                                                                                               Aug 14, 2022    N/A                    N/A
   :pypi:`pytest-requests-futures`                  Pytest Plugin to Mock Requests Futures                                                                                                                                                                    Jul 06, 2022    5 - Production/Stable  pytest
   :pypi:`pytest-requires`                          A pytest plugin to elegantly skip tests with optional requirements                                                                                                                                        Dec 21, 2021    4 - Beta               pytest (>=3.5.0)
   :pypi:`pytest-reraise`                           Make multi-threaded pytest test cases fail when they should                                                                                                                                               Sep 20, 2022    5 - Production/Stable  pytest (>=4.6)
   :pypi:`pytest-rerun`                             Re-run only changed files in specified branch                                                                                                                                                             Jul 08, 2019    N/A                    pytest (>=3.6)
   :pypi:`pytest-rerunfailures`                     pytest plugin to re-run tests to eliminate flaky failures                                                                                                                                                 Mar 09, 2023    5 - Production/Stable  pytest (>=5.3)
   :pypi:`pytest-rerunfailures-all-logs`            pytest plugin to re-run tests to eliminate flaky failures                                                                                                                                                 Mar 07, 2022    5 - Production/Stable  N/A
   :pypi:`pytest-reserial`                          Pytest fixture for recording and replaying serial port traffic.                                                                                                                                           Apr 26, 2023    4 - Beta               pytest
   :pypi:`pytest-resilient-circuits`                Resilient Circuits fixtures for PyTest                                                                                                                                                                    Jun 01, 2023    N/A                    pytest (~=4.6) ; python_version == "2.7"
   :pypi:`pytest-resource`                          Load resource fixture plugin to use with pytest                                                                                                                                                           Nov 14, 2018    4 - Beta               N/A
   :pypi:`pytest-resource-path`                     Provides path for uniform access to test resources in isolated directory                                                                                                                                  May 01, 2021    5 - Production/Stable  pytest (>=3.5.0)
   :pypi:`pytest-resource-usage`                    Pytest plugin for reporting running time and peak memory usage                                                                                                                                            Nov 06, 2022    5 - Production/Stable  pytest>=7.0.0
   :pypi:`pytest-responsemock`                      Simplified requests calls mocking for pytest                                                                                                                                                              Mar 10, 2022    5 - Production/Stable  N/A
   :pypi:`pytest-responses`                         py.test integration for responses                                                                                                                                                                         Oct 11, 2022    N/A                    pytest (>=2.5)
   :pypi:`pytest-rest-api`                                                                                                                                                                                                                                    Aug 08, 2022    N/A                    pytest (>=7.1.2,<8.0.0)
   :pypi:`pytest-restrict`                          Pytest plugin to restrict the test types allowed                                                                                                                                                          Jun 16, 2023    5 - Production/Stable  pytest
   :pypi:`pytest-result-log`                        Write the execution result of the case to the log                                                                                                                                                         Apr 17, 2023    N/A                    pytest>=7.2.0
   :pypi:`pytest-result-sender`                                                                                                                                                                                                                               Apr 20, 2023    N/A                    pytest>=7.3.1
   :pypi:`pytest-resume`                            A Pytest plugin to resuming from the last run test                                                                                                                                                        Apr 22, 2023    4 - Beta               pytest (>=7.0)
   :pypi:`pytest-rethinkdb`                         A RethinkDB plugin for pytest.                                                                                                                                                                            Jul 24, 2016    4 - Beta               N/A
   :pypi:`pytest-retry`                             Adds the ability to retry flaky tests in CI environments                                                                                                                                                  Aug 16, 2022    N/A                    pytest (>=7.0.0)
   :pypi:`pytest-retry-class`                       A pytest plugin to rerun entire class on failure                                                                                                                                                          Mar 25, 2023    N/A                    pytest (>=5.3)
   :pypi:`pytest-reusable-testcases`                                                                                                                                                                                                                          Apr 28, 2023    N/A                    N/A
   :pypi:`pytest-reverse`                           Pytest plugin to reverse test order.                                                                                                                                                                      Jun 16, 2023    5 - Production/Stable  pytest
   :pypi:`pytest-rich`                              Leverage rich for richer test session output                                                                                                                                                              Mar 03, 2022    4 - Beta               pytest (>=7.0)
   :pypi:`pytest-rich-reporter`                     A pytest plugin using Rich for beautiful test result formatting.                                                                                                                                          Feb 17, 2022    1 - Planning           pytest (>=5.0.0)
   :pypi:`pytest-richtrace`                         A pytest plugin that displays the names and information of the pytest hook functions as they are executed.                                                                                                Jun 20, 2023    N/A                    N/A
   :pypi:`pytest-ringo`                             pytest plugin to test webapplications using the Ringo webframework                                                                                                                                        Sep 27, 2017    3 - Alpha              N/A
   :pypi:`pytest-rmsis`                             Sycronise pytest results to Jira RMsis                                                                                                                                                                    Aug 10, 2022    N/A                    pytest (>=5.3.5)
   :pypi:`pytest-rng`                               Fixtures for seeding tests and making randomness reproducible                                                                                                                                             Aug 08, 2019    5 - Production/Stable  pytest
   :pypi:`pytest-roast`                             pytest plugin for ROAST configuration override and fixtures                                                                                                                                               Nov 09, 2022    5 - Production/Stable  pytest
   :pypi:`pytest-rocketchat`                        Pytest to Rocket.Chat reporting plugin                                                                                                                                                                    Apr 18, 2021    5 - Production/Stable  N/A
   :pypi:`pytest-rotest`                            Pytest integration with rotest                                                                                                                                                                            Sep 08, 2019    N/A                    pytest (>=3.5.0)
   :pypi:`pytest-rpc`                               Extend py.test for RPC OpenStack testing.                                                                                                                                                                 Feb 22, 2019    4 - Beta               pytest (~=3.6)
   :pypi:`pytest-rst`                               Test code from RST documents with pytest                                                                                                                                                                  Jan 26, 2023    N/A                    N/A
   :pypi:`pytest-rt`                                pytest data collector plugin for Testgr                                                                                                                                                                   May 05, 2022    N/A                    N/A
   :pypi:`pytest-rts`                               Coverage-based regression test selection (RTS) plugin for pytest                                                                                                                                          May 17, 2021    N/A                    pytest
   :pypi:`pytest-ruff`                              pytest plugin to check ruff requirements.                                                                                                                                                                 Jun 08, 2023    4 - Beta               N/A
   :pypi:`pytest-run-changed`                       Pytest plugin that runs changed tests only                                                                                                                                                                Apr 02, 2021    3 - Alpha              pytest
   :pypi:`pytest-runfailed`                         implement a --failed option for pytest                                                                                                                                                                    Mar 24, 2016    N/A                    N/A
   :pypi:`pytest-runner`                            Invoke py.test as distutils command with dependency resolution                                                                                                                                            Feb 25, 2022    5 - Production/Stable  pytest (>=6) ; extra == 'testing'
   :pypi:`pytest-run-subprocess`                    Pytest Plugin for running and testing subprocesses.                                                                                                                                                       Nov 12, 2022    5 - Production/Stable  pytest
   :pypi:`pytest-runtime-types`                     Checks type annotations on runtime while running tests.                                                                                                                                                   Feb 09, 2023    N/A                    pytest
   :pypi:`pytest-runtime-xfail`                     Call runtime_xfail() to mark running test as xfail.                                                                                                                                                       Aug 26, 2021    N/A                    pytest>=5.0.0
   :pypi:`pytest-runtime-yoyo`                      run case mark timeout                                                                                                                                                                                     Jun 12, 2023    N/A                    pytest (>=7.2.0)
   :pypi:`pytest-ry-demo1`                          测试                                                                                                                                                                                                      Mar 26, 2023    N/A                    N/A
   :pypi:`pytest-saccharin`                         pytest-saccharin is a updated fork of pytest-sugar, a plugin for pytest that changes the default look and feel of pytest (e.g. progressbar, show tests that fail instantly).                              Oct 31, 2022    3 - Alpha              N/A
   :pypi:`pytest-salt`                              Pytest Salt Plugin                                                                                                                                                                                        Jan 27, 2020    4 - Beta               N/A
   :pypi:`pytest-salt-containers`                   A Pytest plugin that builds and creates docker containers                                                                                                                                                 Nov 09, 2016    4 - Beta               N/A
   :pypi:`pytest-salt-factories`                    Pytest Salt Plugin                                                                                                                                                                                        Dec 15, 2022    4 - Beta               pytest (>=6.0.0)
   :pypi:`pytest-salt-from-filenames`               Simple PyTest Plugin For Salt's Test Suite Specifically                                                                                                                                                   Jan 29, 2019    4 - Beta               pytest (>=4.1)
   :pypi:`pytest-salt-runtests-bridge`              Simple PyTest Plugin For Salt's Test Suite Specifically                                                                                                                                                   Dec 05, 2019    4 - Beta               pytest (>=4.1)
   :pypi:`pytest-sanic`                             a pytest plugin for Sanic                                                                                                                                                                                 Oct 25, 2021    N/A                    pytest (>=5.2)
   :pypi:`pytest-sanity`                                                                                                                                                                                                                                      Dec 07, 2020    N/A                    N/A
   :pypi:`pytest-sa-pg`                                                                                                                                                                                                                                       May 14, 2019    N/A                    N/A
   :pypi:`pytest-sbase`                             A complete web automation framework for end-to-end testing.                                                                                                                                               Jun 30, 2023    5 - Production/Stable  N/A
   :pypi:`pytest-scenario`                          pytest plugin for test scenarios                                                                                                                                                                          Feb 06, 2017    3 - Alpha              N/A
   :pypi:`pytest-schedule`                          The job of test scheduling for humans.                                                                                                                                                                    Jan 07, 2023    5 - Production/Stable  N/A
   :pypi:`pytest-schema`                            👍 Validate return values against a schema-like object in testing                                                                                                                                         Mar 14, 2022    5 - Production/Stable  pytest (>=3.5.0)
   :pypi:`pytest-securestore`                       An encrypted password store for use within pytest cases                                                                                                                                                   Nov 08, 2021    4 - Beta               N/A
   :pypi:`pytest-select`                            A pytest plugin which allows to (de-)select tests from a file.                                                                                                                                            Jan 18, 2019    3 - Alpha              pytest (>=3.0)
   :pypi:`pytest-selenium`                          pytest plugin for Selenium                                                                                                                                                                                May 28, 2023    5 - Production/Stable  pytest>=6.0.0
   :pypi:`pytest-seleniumbase`                      A complete web automation framework for end-to-end testing.                                                                                                                                               Jun 30, 2023    5 - Production/Stable  N/A
   :pypi:`pytest-selenium-enhancer`                 pytest plugin for Selenium                                                                                                                                                                                Apr 29, 2022    5 - Production/Stable  N/A
   :pypi:`pytest-selenium-pdiff`                    A pytest package implementing perceptualdiff for Selenium tests.                                                                                                                                          Apr 06, 2017    2 - Pre-Alpha          N/A
   :pypi:`pytest-send-email`                        Send pytest execution result email                                                                                                                                                                        Dec 04, 2019    N/A                    N/A
   :pypi:`pytest-sentry`                            A pytest plugin to send testrun information to Sentry.io                                                                                                                                                  Jan 05, 2023    N/A                    N/A
   :pypi:`pytest-sequence-markers`                  Pytest plugin for sequencing markers for execution of tests                                                                                                                                               May 23, 2023    5 - Production/Stable  N/A
   :pypi:`pytest-server-fixtures`                   Extensible server fixures for py.test                                                                                                                                                                     May 28, 2019    5 - Production/Stable  pytest
   :pypi:`pytest-serverless`                        Automatically mocks resources from serverless.yml in pytest using moto.                                                                                                                                   May 09, 2022    4 - Beta               N/A
   :pypi:`pytest-servers`                           pytest servers                                                                                                                                                                                            Apr 15, 2023    3 - Alpha              pytest (>=6.2)
   :pypi:`pytest-services`                          Services plugin for pytest testing framework                                                                                                                                                              Oct 30, 2020    6 - Mature             N/A
   :pypi:`pytest-session2file`                      pytest-session2file (aka: pytest-session_to_file for v0.1.0 - v0.1.2) is a py.test plugin for capturing and saving to file the stdout of py.test.                                                         Jan 26, 2021    3 - Alpha              pytest
   :pypi:`pytest-session-fixture-globalize`         py.test plugin to make session fixtures behave as if written in conftest, even if it is written in some modules                                                                                           May 15, 2018    4 - Beta               N/A
   :pypi:`pytest-session_to_file`                   pytest-session_to_file is a py.test plugin for capturing and saving to file the stdout of py.test.                                                                                                        Oct 01, 2015    3 - Alpha              N/A
   :pypi:`pytest-setupinfo`                         Displaying setup info during pytest command run                                                                                                                                                           Jan 23, 2023    N/A                    N/A
   :pypi:`pytest-sftpserver`                        py.test plugin to locally test sftp server connections.                                                                                                                                                   Sep 16, 2019    4 - Beta               N/A
   :pypi:`pytest-shard`                                                                                                                                                                                                                                       Dec 11, 2020    4 - Beta               pytest
   :pypi:`pytest-share-hdf`                         Plugin to save test data in HDF files and retrieve them for comparison                                                                                                                                    Sep 21, 2022    4 - Beta               pytest (>=3.5.0)
   :pypi:`pytest-sharkreport`                       this is pytest report plugin.                                                                                                                                                                             Jul 11, 2022    N/A                    pytest (>=3.5)
   :pypi:`pytest-shell`                             A pytest plugin to help with testing shell scripts / black box commands                                                                                                                                   Mar 27, 2022    N/A                    N/A
   :pypi:`pytest-shell-utilities`                   Pytest plugin to simplify running shell commands against the system                                                                                                                                       Sep 23, 2022    4 - Beta               pytest (>=6.0.0)
   :pypi:`pytest-sheraf`                            Versatile ZODB abstraction layer - pytest fixtures                                                                                                                                                        Feb 11, 2020    N/A                    pytest
   :pypi:`pytest-sherlock`                          pytest plugin help to find coupled tests                                                                                                                                                                  Jan 16, 2023    5 - Production/Stable  pytest (>=3.5.1)
   :pypi:`pytest-shortcuts`                         Expand command-line shortcuts listed in pytest configuration                                                                                                                                              Oct 29, 2020    4 - Beta               pytest (>=3.5.0)
   :pypi:`pytest-shutil`                            A goodie-bag of unix shell and environment tools for py.test                                                                                                                                              May 28, 2019    5 - Production/Stable  pytest
   :pypi:`pytest-simplehttpserver`                  Simple pytest fixture to spin up an HTTP server                                                                                                                                                           Jun 24, 2021    4 - Beta               N/A
   :pypi:`pytest-simple-plugin`                     Simple pytest plugin                                                                                                                                                                                      Nov 27, 2019    N/A                    N/A
   :pypi:`pytest-simple-settings`                   simple-settings plugin for pytest                                                                                                                                                                         Nov 17, 2020    4 - Beta               pytest
   :pypi:`pytest-single-file-logging`               Allow for multiple processes to log to a single file                                                                                                                                                      May 05, 2016    4 - Beta               pytest (>=2.8.1)
   :pypi:`pytest-skip-markers`                      Pytest Salt Plugin                                                                                                                                                                                        Dec 20, 2022    5 - Production/Stable  pytest (>=7.1.0)
   :pypi:`pytest-skipper`                           A plugin that selects only tests with changes in execution path                                                                                                                                           Mar 26, 2017    3 - Alpha              pytest (>=3.0.6)
   :pypi:`pytest-skippy`                            Automatically skip tests that don't need to run!                                                                                                                                                          Jan 27, 2018    3 - Alpha              pytest (>=2.3.4)
   :pypi:`pytest-skip-slow`                         A pytest plugin to skip \`@pytest.mark.slow\` tests by default.                                                                                                                                           Feb 09, 2023    N/A                    pytest>=6.2.0
   :pypi:`pytest-slack`                             Pytest to Slack reporting plugin                                                                                                                                                                          Dec 15, 2020    5 - Production/Stable  N/A
   :pypi:`pytest-slow`                              A pytest plugin to skip \`@pytest.mark.slow\` tests by default.                                                                                                                                           Sep 28, 2021    N/A                    N/A
   :pypi:`pytest-slowest-first`                     Sort tests by their last duration, slowest first                                                                                                                                                          Dec 11, 2022    4 - Beta               N/A
   :pypi:`pytest-slow-last`                         Run tests in order of execution time (faster tests first)                                                                                                                                                 Dec 10, 2022    4 - Beta               pytest (>=3.5.0)
   :pypi:`pytest-smartcollect`                      A plugin for collecting tests that touch changed code                                                                                                                                                     Oct 04, 2018    N/A                    pytest (>=3.5.0)
   :pypi:`pytest-smartcov`                          Smart coverage plugin for pytest.                                                                                                                                                                         Sep 30, 2017    3 - Alpha              N/A
   :pypi:`pytest-smell`                             Automated bad smell detection tool for Pytest                                                                                                                                                             Jun 26, 2022    N/A                    N/A
   :pypi:`pytest-smtp`                              Send email with pytest execution result                                                                                                                                                                   Feb 20, 2021    N/A                    pytest
   :pypi:`pytest-smtp4dev`                          Plugin for smtp4dev API                                                                                                                                                                                   Jun 27, 2023    5 - Production/Stable  N/A
   :pypi:`pytest-smtpd`                             An SMTP server for testing built on aiosmtpd                                                                                                                                                              May 15, 2023    N/A                    pytest
   :pypi:`pytest-snail`                             Plugin for adding a marker to slow running tests. 🐌                                                                                                                                                      Nov 04, 2019    3 - Alpha              pytest (>=5.0.1)
   :pypi:`pytest-snapci`                            py.test plugin for Snap-CI                                                                                                                                                                                Nov 12, 2015    N/A                    N/A
   :pypi:`pytest-snapshot`                          A plugin for snapshot testing with pytest.                                                                                                                                                                Apr 23, 2022    4 - Beta               pytest (>=3.0.0)
   :pypi:`pytest-snmpserver`                                                                                                                                                                                                                                  May 12, 2021    N/A                    N/A
   :pypi:`pytest-snowflake-bdd`                     Setup test data and run tests on snowflake in BDD style!                                                                                                                                                  Jan 05, 2022    4 - Beta               pytest (>=6.2.0)
   :pypi:`pytest-socket`                            Pytest Plugin to disable socket calls during tests                                                                                                                                                        Feb 03, 2023    4 - Beta               pytest (>=3.6.3)
   :pypi:`pytest-sofaepione`                        Test the installation of SOFA and the SofaEpione plugin.                                                                                                                                                  Aug 17, 2022    N/A                    N/A
   :pypi:`pytest-soft-assertions`                                                                                                                                                                                                                             May 05, 2020    3 - Alpha              pytest
   :pypi:`pytest-solidity`                          A PyTest library plugin for Solidity language.                                                                                                                                                            Jan 15, 2022    1 - Planning           pytest (<7,>=6.0.1) ; extra == 'tests'
   :pypi:`pytest-solr`                              Solr process and client fixtures for py.test.                                                                                                                                                             May 11, 2020    3 - Alpha              pytest (>=3.0.0)
   :pypi:`pytest-sorter`                            A simple plugin to first execute tests that historically failed more                                                                                                                                      Apr 20, 2021    4 - Beta               pytest (>=3.1.1)
   :pypi:`pytest-sosu`                              Unofficial PyTest plugin for Sauce Labs                                                                                                                                                                   Feb 14, 2023    2 - Pre-Alpha          pytest
   :pypi:`pytest-sourceorder`                       Test-ordering plugin for pytest                                                                                                                                                                           Sep 01, 2021    4 - Beta               pytest
   :pypi:`pytest-spark`                             pytest plugin to run the tests with support of pyspark.                                                                                                                                                   Feb 23, 2020    4 - Beta               pytest
   :pypi:`pytest-spawner`                           py.test plugin to spawn process and communicate with them.                                                                                                                                                Jul 31, 2015    4 - Beta               N/A
   :pypi:`pytest-spec`                              Library pytest-spec is a pytest plugin to display test execution output like a SPECIFICATION.                                                                                                             May 04, 2021    N/A                    N/A
   :pypi:`pytest-spec2md`                           Library pytest-spec2md is a pytest plugin to create a markdown specification while running pytest.                                                                                                        Jun 26, 2022    N/A                    pytest (>7.0)
   :pypi:`pytest-speed`                             Modern benchmarking library for python with pytest integration.                                                                                                                                           Jan 22, 2023    3 - Alpha              pytest>=7
   :pypi:`pytest-sphinx`                            Doctest plugin for pytest with support for Sphinx-specific doctest-directives                                                                                                                             Sep 06, 2022    4 - Beta               pytest (>=7.0.0)
   :pypi:`pytest-spiratest`                         Exports unit tests as test runs in SpiraTest/Team/Plan                                                                                                                                                    Feb 08, 2022    N/A                    N/A
   :pypi:`pytest-splinter`                          Splinter plugin for pytest testing framework                                                                                                                                                              Sep 09, 2022    6 - Mature             pytest (>=3.0.0)
   :pypi:`pytest-splinter4`                         Pytest plugin for the splinter automation library                                                                                                                                                         Jun 11, 2022    6 - Mature             pytest (<8.0,>=7.1.2)
   :pypi:`pytest-split`                             Pytest plugin which splits the test suite to equally sized sub suites based on test execution time.                                                                                                       Apr 12, 2023    4 - Beta               pytest (>=5,<8)
   :pypi:`pytest-splitio`                           Split.io SDK integration for e2e tests                                                                                                                                                                    Sep 22, 2020    N/A                    pytest (<7,>=5.0)
   :pypi:`pytest-split-tests`                       A Pytest plugin for running a subset of your tests by splitting them in to equally sized groups. Forked from Mark Adams' original project pytest-test-groups.                                             Jul 30, 2021    5 - Production/Stable  pytest (>=2.5)
   :pypi:`pytest-split-tests-tresorit`                                                                                                                                                                                                                        Feb 22, 2021    1 - Planning           N/A
   :pypi:`pytest-splunk-addon`                      A Dynamic test tool for Splunk Apps and Add-ons                                                                                                                                                           Jun 30, 2023    N/A                    pytest (>5.4.0,<8)
   :pypi:`pytest-splunk-addon-ui-smartx`            Library to support testing Splunk Add-on UX                                                                                                                                                               Mar 07, 2023    N/A                    N/A
   :pypi:`pytest-splunk-env`                        pytest fixtures for interaction with Splunk Enterprise and Splunk Cloud                                                                                                                                   Oct 22, 2020    N/A                    pytest (>=6.1.1,<7.0.0)
   :pypi:`pytest-sqitch`                            sqitch for pytest                                                                                                                                                                                         Apr 06, 2020    4 - Beta               N/A
   :pypi:`pytest-sqlalchemy`                        pytest plugin with sqlalchemy related fixtures                                                                                                                                                            Mar 13, 2018    3 - Alpha              N/A
   :pypi:`pytest-sqlalchemy-mock`                   pytest sqlalchemy plugin for mock                                                                                                                                                                         Mar 15, 2023    3 - Alpha              pytest (>=2.0)
   :pypi:`pytest-sqlalchemy-session`                A pytest plugin for preserving test isolation that use SQLAlchemy.                                                                                                                                        May 19, 2023    4 - Beta               pytest (>=7.0)
   :pypi:`pytest-sql-bigquery`                      Yet another SQL-testing framework for BigQuery provided by pytest plugin                                                                                                                                  Dec 19, 2019    N/A                    pytest
   :pypi:`pytest-sqlfluff`                          A pytest plugin to use sqlfluff to enable format checking of sql files.                                                                                                                                   Dec 21, 2022    4 - Beta               pytest (>=3.5.0)
   :pypi:`pytest-squadcast`                         Pytest report plugin for Squadcast                                                                                                                                                                        Feb 22, 2022    5 - Production/Stable  pytest
   :pypi:`pytest-srcpaths`                          Add paths to sys.path                                                                                                                                                                                     Oct 15, 2021    N/A                    pytest>=6.2.0
   :pypi:`pytest-ssh`                               pytest plugin for ssh command run                                                                                                                                                                         May 27, 2019    N/A                    pytest
   :pypi:`pytest-start-from`                        Start pytest run from a given point                                                                                                                                                                       Apr 11, 2016    N/A                    N/A
   :pypi:`pytest-star-track-issue`                  A package to prevent Dependency Confusion attacks against Yandex.                                                                                                                                         Feb 10, 2023    N/A                    N/A
   :pypi:`pytest-static`                            pytest-static                                                                                                                                                                                             May 07, 2023    1 - Planning           N/A
   :pypi:`pytest-statsd`                            pytest plugin for reporting to graphite                                                                                                                                                                   Nov 30, 2018    5 - Production/Stable  pytest (>=3.0.0)
   :pypi:`pytest-stepfunctions`                     A small description                                                                                                                                                                                       May 08, 2021    4 - Beta               pytest
   :pypi:`pytest-steps`                             Create step-wise / incremental tests in pytest.                                                                                                                                                           Sep 23, 2021    5 - Production/Stable  N/A
   :pypi:`pytest-stepwise`                          Run a test suite one failing test at a time.                                                                                                                                                              Dec 01, 2015    4 - Beta               N/A
   :pypi:`pytest-stf`                               pytest plugin for openSTF                                                                                                                                                                                 Dec 04, 2022    N/A                    pytest (>=5.0)
   :pypi:`pytest-stoq`                              A plugin to pytest stoq                                                                                                                                                                                   Feb 09, 2021    4 - Beta               N/A
   :pypi:`pytest-stress`                            A Pytest plugin that allows you to loop tests for a user defined amount of time.                                                                                                                          Dec 07, 2019    4 - Beta               pytest (>=3.6.0)
   :pypi:`pytest-structlog`                         Structured logging assertions                                                                                                                                                                             Dec 18, 2022    N/A                    pytest
   :pypi:`pytest-structmpd`                         provide structured temporary directory                                                                                                                                                                    Oct 17, 2018    N/A                    N/A
   :pypi:`pytest-stub`                              Stub packages, modules and attributes.                                                                                                                                                                    Apr 28, 2020    5 - Production/Stable  N/A
   :pypi:`pytest-stubprocess`                       Provide stub implementations for subprocesses in Python tests                                                                                                                                             Sep 17, 2018    3 - Alpha              pytest (>=3.5.0)
   :pypi:`pytest-study`                             A pytest plugin to organize long run tests (named studies) without interfering the regular tests                                                                                                          Sep 26, 2017    3 - Alpha              pytest (>=2.0)
   :pypi:`pytest-subprocess`                        A plugin to fake subprocess for pytest                                                                                                                                                                    Jan 28, 2023    5 - Production/Stable  pytest (>=4.0.0)
   :pypi:`pytest-subtesthack`                       A hack to explicitly set up and tear down fixtures.                                                                                                                                                       Jul 16, 2022    N/A                    N/A
   :pypi:`pytest-subtests`                          unittest subTest() support and subtests fixture                                                                                                                                                           May 15, 2023    4 - Beta               pytest (>=7.0)
   :pypi:`pytest-subunit`                           pytest-subunit is a plugin for py.test which outputs testsresult in subunit format.                                                                                                                       Aug 29, 2017    N/A                    N/A
   :pypi:`pytest-sugar`                             pytest-sugar is a plugin for pytest that changes the default look and feel of pytest (e.g. progressbar, show tests that fail instantly).                                                                  Apr 10, 2023    4 - Beta               pytest (>=6.2.0)
   :pypi:`pytest-suitemanager`                      A simple plugin to use with pytest                                                                                                                                                                        Apr 28, 2023    4 - Beta               N/A
   :pypi:`pytest-svn`                               SVN repository fixture for py.test                                                                                                                                                                        May 28, 2019    5 - Production/Stable  pytest
   :pypi:`pytest-symbols`                           pytest-symbols is a pytest plugin that adds support for passing test environment symbols into pytest tests.                                                                                               Nov 20, 2017    3 - Alpha              N/A
   :pypi:`pytest-system-statistics`                 Pytest plugin to track and report system usage statistics                                                                                                                                                 Feb 16, 2022    5 - Production/Stable  pytest (>=6.0.0)
   :pypi:`pytest-system-test-plugin`                Pyst - Pytest System-Test Plugin                                                                                                                                                                          Feb 03, 2022    N/A                    N/A
   :pypi:`pytest-tagging`                           a pytest plugin to tag tests                                                                                                                                                                              Apr 01, 2023    N/A                    pytest (>=7.1.3,<8.0.0)
   :pypi:`pytest-takeltest`                         Fixtures for ansible, testinfra and molecule                                                                                                                                                              Feb 15, 2023    N/A                    N/A
   :pypi:`pytest-talisker`                                                                                                                                                                                                                                    Nov 28, 2021    N/A                    N/A
   :pypi:`pytest-tally`                             A Pytest plugin to generate realtime summary stats, and display them in-console using a text-based dashboard.                                                                                             May 22, 2023    4 - Beta               pytest (>=6.2.5)
   :pypi:`pytest-tap`                               Test Anything Protocol (TAP) reporting plugin for pytest                                                                                                                                                  Oct 27, 2021    5 - Production/Stable  pytest (>=3.0)
   :pypi:`pytest-tape`                              easy assertion with expected results saved to yaml files                                                                                                                                                  Mar 17, 2021    4 - Beta               N/A
   :pypi:`pytest-target`                            Pytest plugin for remote target orchestration.                                                                                                                                                            Jan 21, 2021    3 - Alpha              pytest (>=6.1.2,<7.0.0)
   :pypi:`pytest-tblineinfo`                        tblineinfo is a py.test plugin that insert the node id in the final py.test report when --tb=line option is used                                                                                          Dec 01, 2015    3 - Alpha              pytest (>=2.0)
   :pypi:`pytest-tcpclient`                         A pytest plugin for testing TCP clients                                                                                                                                                                   Nov 16, 2022    N/A                    pytest (<8,>=7.1.3)
   :pypi:`pytest-teamcity-logblock`                 py.test plugin to introduce block structure in teamcity build log, if output is not captured                                                                                                              May 15, 2018    4 - Beta               N/A
   :pypi:`pytest-telegram`                          Pytest to Telegram reporting plugin                                                                                                                                                                       Dec 10, 2020    5 - Production/Stable  N/A
   :pypi:`pytest-telegram-notifier`                 Telegram notification plugin for Pytest                                                                                                                                                                   Jun 27, 2023    5 - Production/Stable  N/A
   :pypi:`pytest-tempdir`                           Predictable and repeatable tempdir support.                                                                                                                                                               Oct 11, 2019    4 - Beta               pytest (>=2.8.1)
   :pypi:`pytest-terra-fixt`                        Terraform and Terragrunt fixtures for pytest                                                                                                                                                              Sep 15, 2022    N/A                    pytest (==6.2.5)
   :pypi:`pytest-terraform`                         A pytest plugin for using terraform fixtures                                                                                                                                                              Jun 20, 2023    N/A                    pytest (>=6.0)
   :pypi:`pytest-terraform-fixture`                 generate terraform resources to use with pytest                                                                                                                                                           Nov 14, 2018    4 - Beta               N/A
   :pypi:`pytest-testbook`                          A plugin to run tests written in Jupyter notebook                                                                                                                                                         Dec 11, 2016    3 - Alpha              N/A
   :pypi:`pytest-testconfig`                        Test configuration plugin for pytest.                                                                                                                                                                     Jan 11, 2020    4 - Beta               pytest (>=3.5.0)
   :pypi:`pytest-testdirectory`                     A py.test plugin providing temporary directories in unit tests.                                                                                                                                           May 02, 2023    5 - Production/Stable  pytest
   :pypi:`pytest-testdox`                           A testdox format reporter for pytest                                                                                                                                                                      Apr 19, 2022    5 - Production/Stable  pytest (>=4.6.0)
   :pypi:`pytest-test-grouping`                     A Pytest plugin for running a subset of your tests by splitting them in to equally sized groups.                                                                                                          Feb 01, 2023    5 - Production/Stable  pytest (>=2.5)
   :pypi:`pytest-test-groups`                       A Pytest plugin for running a subset of your tests by splitting them in to equally sized groups.                                                                                                          Oct 25, 2016    5 - Production/Stable  N/A
   :pypi:`pytest-testinfra`                         Test infrastructures                                                                                                                                                                                      May 21, 2023    5 - Production/Stable  pytest (!=3.0.2)
   :pypi:`pytest-testlink-adaptor`                  pytest reporting plugin for testlink                                                                                                                                                                      Dec 20, 2018    4 - Beta               pytest (>=2.6)
   :pypi:`pytest-testmon`                           selects tests affected by changed files and methods                                                                                                                                                       Jun 16, 2023    4 - Beta               N/A
   :pypi:`pytest-testmon-dev`                       selects tests affected by changed files and methods                                                                                                                                                       Mar 30, 2023    4 - Beta               pytest (<8,>=5)
   :pypi:`pytest-testmon-oc`                        nOly selects tests affected by changed files and methods                                                                                                                                                  Jun 01, 2022    4 - Beta               pytest (<8,>=5)
   :pypi:`pytest-testmon-skip-libraries`            selects tests affected by changed files and methods                                                                                                                                                       Mar 03, 2023    4 - Beta               pytest (<8,>=5)
   :pypi:`pytest-testobject`                        Plugin to use TestObject Suites with Pytest                                                                                                                                                               Sep 24, 2019    4 - Beta               pytest (>=3.1.1)
   :pypi:`pytest-testpluggy`                        set your encoding                                                                                                                                                                                         Jan 07, 2022    N/A                    pytest
   :pypi:`pytest-testrail`                          pytest plugin for creating TestRail runs and adding results                                                                                                                                               Aug 27, 2020    N/A                    pytest (>=3.6)
   :pypi:`pytest-testrail2`                         A pytest plugin to upload results to TestRail.                                                                                                                                                            Feb 10, 2023    N/A                    pytest (<8.0,>=7.2.0)
   :pypi:`pytest-testrail-api-client`               TestRail Api Python Client                                                                                                                                                                                Dec 14, 2021    N/A                    pytest
   :pypi:`pytest-testrail-appetize`                 pytest plugin for creating TestRail runs and adding results                                                                                                                                               Sep 29, 2021    N/A                    N/A
   :pypi:`pytest-testrail-client`                   pytest plugin for Testrail                                                                                                                                                                                Sep 29, 2020    5 - Production/Stable  N/A
   :pypi:`pytest-testrail-e2e`                      pytest plugin for creating TestRail runs and adding results                                                                                                                                               Oct 11, 2021    N/A                    pytest (>=3.6)
   :pypi:`pytest-testrail-integrator`               Pytest plugin for sending report to testrail system.                                                                                                                                                      Aug 01, 2022    N/A                    pytest (>=6.2.5)
   :pypi:`pytest-testrail-ns`                       pytest plugin for creating TestRail runs and adding results                                                                                                                                               Aug 12, 2022    N/A                    N/A
   :pypi:`pytest-testrail-plugin`                   PyTest plugin for TestRail                                                                                                                                                                                Apr 21, 2020    3 - Alpha              pytest
   :pypi:`pytest-testrail-reporter`                                                                                                                                                                                                                           Sep 10, 2018    N/A                    N/A
   :pypi:`pytest-testreport`                                                                                                                                                                                                                                  Dec 01, 2022    4 - Beta               pytest (>=3.5.0)
   :pypi:`pytest-testreport-new`                                                                                                                                                                                                                              Aug 15, 2022    4 - Beta               pytest (>=3.5.0)
   :pypi:`pytest-testslide`                         TestSlide fixture for pytest                                                                                                                                                                              Jan 07, 2021    5 - Production/Stable  pytest (~=6.2)
   :pypi:`pytest-test-this`                         Plugin for py.test to run relevant tests, based on naively checking if a test contains a reference to the symbol you supply                                                                               Sep 15, 2019    2 - Pre-Alpha          pytest (>=2.3)
   :pypi:`pytest-test-utils`                                                                                                                                                                                                                                  Jul 14, 2022    N/A                    pytest (>=5)
   :pypi:`pytest-tesults`                           Tesults plugin for pytest                                                                                                                                                                                 Dec 23, 2022    5 - Production/Stable  pytest (>=3.5.0)
   :pypi:`pytest-textual-snapshot`                  Snapshot testing for Textual apps                                                                                                                                                                         Jun 27, 2023    4 - Beta               pytest (>=7.0.0)
   :pypi:`pytest-tezos`                             pytest-ligo                                                                                                                                                                                               Jan 16, 2020    4 - Beta               N/A
   :pypi:`pytest-th2-bdd`                           pytest_th2_bdd                                                                                                                                                                                            May 13, 2022    N/A                    N/A
   :pypi:`pytest-thawgun`                           Pytest plugin for time travel                                                                                                                                                                             May 26, 2020    3 - Alpha              N/A
   :pypi:`pytest-threadleak`                        Detects thread leaks                                                                                                                                                                                      Jul 03, 2022    4 - Beta               pytest (>=3.1.1)
   :pypi:`pytest-tick`                              Ticking on tests                                                                                                                                                                                          Aug 31, 2021    5 - Production/Stable  pytest (>=6.2.5,<7.0.0)
   :pypi:`pytest-time`                                                                                                                                                                                                                                        Jun 24, 2023    3 - Alpha              pytest
   :pypi:`pytest-timeit`                            A pytest plugin to time test function runs                                                                                                                                                                Oct 13, 2016    4 - Beta               N/A
   :pypi:`pytest-timeout`                           pytest plugin to abort hanging tests                                                                                                                                                                      Jan 18, 2022    5 - Production/Stable  pytest (>=5.0.0)
   :pypi:`pytest-timeouts`                          Linux-only Pytest plugin to control durations of various test case execution phases                                                                                                                       Sep 21, 2019    5 - Production/Stable  N/A
   :pypi:`pytest-timer`                             A timer plugin for pytest                                                                                                                                                                                 Jun 02, 2021    N/A                    N/A
   :pypi:`pytest-timestamper`                       Pytest plugin to add a timestamp prefix to the pytest output                                                                                                                                              Jun 06, 2021    N/A                    N/A
   :pypi:`pytest-timestamps`                        A simple plugin to view timestamps for each test                                                                                                                                                          Apr 01, 2023    N/A                    pytest (>=5.2)
   :pypi:`pytest-tinybird`                          A pytest plugin to report test results to tinybird                                                                                                                                                        Jun 26, 2023    4 - Beta               pytest (>=3.8.0)
   :pypi:`pytest-tipsi-django`                                                                                                                                                                                                                                Nov 17, 2021    4 - Beta               pytest (>=6.0.0)
   :pypi:`pytest-tipsi-testing`                     Better fixtures management. Various helpers                                                                                                                                                               Nov 04, 2020    4 - Beta               pytest (>=3.3.0)
   :pypi:`pytest-tldr`                              A pytest plugin that limits the output to just the things you need.                                                                                                                                       Oct 26, 2022    4 - Beta               pytest (>=3.5.0)
   :pypi:`pytest-tm4j-reporter`                     Cloud Jira Test Management (TM4J) PyTest reporter plugin                                                                                                                                                  Sep 01, 2020    N/A                    pytest
   :pypi:`pytest-tmnet`                             A small example package                                                                                                                                                                                   Mar 01, 2022    N/A                    N/A
   :pypi:`pytest-tmp-files`                         Utilities to create temporary file hierarchies in pytest.                                                                                                                                                 Apr 03, 2022    N/A                    pytest
   :pypi:`pytest-tmpfs`                             A pytest plugin that helps you on using a temporary filesystem for testing.                                                                                                                               Aug 29, 2022    N/A                    pytest
   :pypi:`pytest-tmreport`                          this is a vue-element ui report for pytest                                                                                                                                                                Aug 12, 2022    N/A                    N/A
   :pypi:`pytest-tmux`                              A pytest plugin that enables tmux driven tests                                                                                                                                                            Apr 22, 2023    4 - Beta               N/A
   :pypi:`pytest-todo`                              A small plugin for the pytest testing framework, marking TODO comments as failure                                                                                                                         May 23, 2019    4 - Beta               pytest
   :pypi:`pytest-tomato`                                                                                                                                                                                                                                      Mar 01, 2019    5 - Production/Stable  N/A
   :pypi:`pytest-toolbelt`                          This is just a collection of utilities for pytest, but don't really belong in pytest proper.                                                                                                              Aug 12, 2019    3 - Alpha              N/A
   :pypi:`pytest-toolbox`                           Numerous useful plugins for pytest.                                                                                                                                                                       Apr 07, 2018    N/A                    pytest (>=3.5.0)
   :pypi:`pytest-tools`                             Pytest tools                                                                                                                                                                                              Oct 21, 2022    4 - Beta               N/A
   :pypi:`pytest-tornado`                           A py.test plugin providing fixtures and markers to simplify testing of asynchronous tornado applications.                                                                                                 Jun 17, 2020    5 - Production/Stable  pytest (>=3.6)
   :pypi:`pytest-tornado5`                          A py.test plugin providing fixtures and markers to simplify testing of asynchronous tornado applications.                                                                                                 Nov 16, 2018    5 - Production/Stable  pytest (>=3.6)
   :pypi:`pytest-tornado-yen3`                      A py.test plugin providing fixtures and markers to simplify testing of asynchronous tornado applications.                                                                                                 Oct 15, 2018    5 - Production/Stable  N/A
   :pypi:`pytest-tornasync`                         py.test plugin for testing Python 3.5+ Tornado code                                                                                                                                                       Jul 15, 2019    3 - Alpha              pytest (>=3.0)
   :pypi:`pytest-trace`                             Save OpenTelemetry spans generated during testing                                                                                                                                                         Jun 19, 2022    N/A                    pytest (>=4.6)
   :pypi:`pytest-track`                                                                                                                                                                                                                                       Feb 26, 2021    3 - Alpha              pytest (>=3.0)
   :pypi:`pytest-translations`                      Test your translation files.                                                                                                                                                                              Nov 05, 2021    5 - Production/Stable  N/A
   :pypi:`pytest-travis-fold`                       Folds captured output sections in Travis CI build log                                                                                                                                                     Nov 29, 2017    4 - Beta               pytest (>=2.6.0)
   :pypi:`pytest-trello`                            Plugin for py.test that integrates trello using markers                                                                                                                                                   Nov 20, 2015    5 - Production/Stable  N/A
   :pypi:`pytest-trepan`                            Pytest plugin for trepan debugger.                                                                                                                                                                        Jul 28, 2018    5 - Production/Stable  N/A
   :pypi:`pytest-trialtemp`                         py.test plugin for using the same _trial_temp working directory as trial                                                                                                                                  Jun 08, 2015    N/A                    N/A
   :pypi:`pytest-trio`                              Pytest plugin for trio                                                                                                                                                                                    Nov 01, 2022    N/A                    pytest (>=7.2.0)
   :pypi:`pytest-trytond`                           Pytest plugin for the Tryton server framework                                                                                                                                                             Nov 04, 2022    4 - Beta               pytest (>=5)
   :pypi:`pytest-tspwplib`                          A simple plugin to use with tspwplib                                                                                                                                                                      Jan 08, 2021    4 - Beta               pytest (>=3.5.0)
   :pypi:`pytest-tst`                               Customize pytest options, output and exit code to make it compatible with tst                                                                                                                             Apr 27, 2022    N/A                    pytest (>=5.0.0)
   :pypi:`pytest-tstcls`                            Test Class Base                                                                                                                                                                                           Mar 23, 2020    5 - Production/Stable  N/A
   :pypi:`pytest-tui`                               Text User Interface (TUI) and HTML report for Pytest test runs                                                                                                                                            Jun 12, 2023    4 - Beta               N/A
   :pypi:`pytest-tutorials`                                                                                                                                                                                                                                   Mar 11, 2023    N/A                    N/A
   :pypi:`pytest-twilio-conversations-client-mock`                                                                                                                                                                                                            Aug 02, 2022    N/A                    N/A
   :pypi:`pytest-twisted`                           A twisted plugin for pytest.                                                                                                                                                                              Oct 16, 2022    5 - Production/Stable  pytest (>=2.3)
   :pypi:`pytest-typechecker`                       Run type checkers on specified test files                                                                                                                                                                 Feb 04, 2022    N/A                    pytest (>=6.2.5,<7.0.0)
   :pypi:`pytest-typhoon-config`                    A Typhoon HIL plugin that facilitates test parameter configuration at runtime                                                                                                                             Apr 07, 2022    5 - Production/Stable  N/A
   :pypi:`pytest-typhoon-xray`                      Typhoon HIL plugin for pytest                                                                                                                                                                             Jun 10, 2023    4 - Beta               N/A
   :pypi:`pytest-tytest`                            Typhoon HIL plugin for pytest                                                                                                                                                                             May 25, 2020    4 - Beta               pytest (>=5.4.2)
   :pypi:`pytest-ubersmith`                         Easily mock calls to ubersmith at the \`requests\` level.                                                                                                                                                 Apr 13, 2015    N/A                    N/A
   :pypi:`pytest-ui`                                Text User Interface for running python tests                                                                                                                                                              Jul 05, 2021    4 - Beta               pytest
   :pypi:`pytest-ui-failed-screenshot`              UI自动测试失败时自动截图，并将截图加入到测试报告中                                                                                                                                                        Dec 06, 2022    N/A                    N/A
   :pypi:`pytest-ui-failed-screenshot-allure`       UI自动测试失败时自动截图，并将截图加入到Allure测试报告中                                                                                                                                                  Dec 06, 2022    N/A                    N/A
   :pypi:`pytest-unflakable`                        Unflakable plugin for PyTest                                                                                                                                                                              Mar 24, 2023    4 - Beta               pytest (>=6.2.0)
   :pypi:`pytest-unhandled-exception-exit-code`     Plugin for py.test set a different exit code on uncaught exceptions                                                                                                                                       Jun 22, 2020    5 - Production/Stable  pytest (>=2.3)
   :pypi:`pytest-unittest-filter`                   A pytest plugin for filtering unittest-based test classes                                                                                                                                                 Jan 12, 2019    4 - Beta               pytest (>=3.1.0)
   :pypi:`pytest-unmarked`                          Run only unmarked tests                                                                                                                                                                                   Aug 27, 2019    5 - Production/Stable  N/A
   :pypi:`pytest-unordered`                         Test equality of unordered collections in pytest                                                                                                                                                          Nov 28, 2022    4 - Beta               pytest (>=6.0.0)
   :pypi:`pytest-unstable`                          Set a test as unstable to return 0 even if it failed                                                                                                                                                      Sep 27, 2022    4 - Beta               N/A
   :pypi:`pytest-unused-fixtures`                   A pytest plugin to list unused fixtures after a test run.                                                                                                                                                 Jun 30, 2023    4 - Beta               pytest (>=7.3.2,<8.0.0)
   :pypi:`pytest-upload-report`                     pytest-upload-report is a plugin for pytest that upload your test report for test results.                                                                                                                Jun 18, 2021    5 - Production/Stable  N/A
   :pypi:`pytest-utils`                             Some helpers for pytest.                                                                                                                                                                                  Feb 02, 2023    4 - Beta               pytest (>=7.0.0,<8.0.0)
   :pypi:`pytest-vagrant`                           A py.test plugin providing access to vagrant.                                                                                                                                                             Sep 07, 2021    5 - Production/Stable  pytest
   :pypi:`pytest-valgrind`                                                                                                                                                                                                                                    May 19, 2021    N/A                    N/A
   :pypi:`pytest-variables`                         pytest plugin for providing variables to tests/fixtures                                                                                                                                                   May 27, 2023    5 - Production/Stable  pytest>=7.0.0
   :pypi:`pytest-variant`                           Variant support for Pytest                                                                                                                                                                                Jun 06, 2022    N/A                    N/A
   :pypi:`pytest-vcr`                               Plugin for managing VCR.py cassettes                                                                                                                                                                      Apr 26, 2019    5 - Production/Stable  pytest (>=3.6.0)
   :pypi:`pytest-vcr-delete-on-fail`                A pytest plugin that automates vcrpy cassettes deletion on test failure.                                                                                                                                  Jun 20, 2022    5 - Production/Stable  pytest (>=6.2.2)
   :pypi:`pytest-vcrpandas`                         Test from HTTP interactions to dataframe processed.                                                                                                                                                       Jan 12, 2019    4 - Beta               pytest
   :pypi:`pytest-vcs`                                                                                                                                                                                                                                         Sep 22, 2022    4 - Beta               N/A
   :pypi:`pytest-venv`                              py.test fixture for creating a virtual environment                                                                                                                                                        Aug 04, 2020    4 - Beta               pytest
   :pypi:`pytest-ver`                               Pytest module with Verification Protocol, Verification Report and Trace Matrix                                                                                                                            Mar 22, 2023    4 - Beta               N/A
   :pypi:`pytest-verbose-parametrize`               More descriptive output for parametrized py.test tests                                                                                                                                                    May 28, 2019    5 - Production/Stable  pytest
   :pypi:`pytest-vimqf`                             A simple pytest plugin that will shrink pytest output when specified, to fit vim quickfix window.                                                                                                         Feb 08, 2021    4 - Beta               pytest (>=6.2.2,<7.0.0)
   :pypi:`pytest-virtualenv`                        Virtualenv fixture for py.test                                                                                                                                                                            May 28, 2019    5 - Production/Stable  pytest
   :pypi:`pytest-vnc`                               VNC client for Pytest                                                                                                                                                                                     Feb 25, 2023    N/A                    pytest
   :pypi:`pytest-voluptuous`                        Pytest plugin for asserting data against voluptuous schema.                                                                                                                                               Jun 09, 2020    N/A                    pytest
   :pypi:`pytest-vscodedebug`                       A pytest plugin to easily enable debugging tests within Visual Studio Code                                                                                                                                Dec 04, 2020    4 - Beta               N/A
   :pypi:`pytest-vscode-pycharm-cls`                A PyTest helper to enable start remote debugger on test start or failure or when pytest.set_trace is used.                                                                                                Feb 01, 2023    N/A                    pytest
   :pypi:`pytest-vts`                               pytest plugin for automatic recording of http stubbed tests                                                                                                                                               Jun 05, 2019    N/A                    pytest (>=2.3)
   :pypi:`pytest-vulture`                           A pytest plugin to checks dead code with vulture                                                                                                                                                          Jun 01, 2023    N/A                    pytest (>=7.0.0)
   :pypi:`pytest-vw`                                pytest-vw makes your failing test cases succeed under CI tools scrutiny                                                                                                                                   Oct 07, 2015    4 - Beta               N/A
   :pypi:`pytest-vyper`                             Plugin for the vyper smart contract language.                                                                                                                                                             May 28, 2020    2 - Pre-Alpha          N/A
   :pypi:`pytest-wa-e2e-plugin`                     Pytest plugin for testing whatsapp bots with end to end tests                                                                                                                                             Feb 18, 2020    4 - Beta               pytest (>=3.5.0)
   :pypi:`pytest-wake`                                                                                                                                                                                                                                        May 11, 2023    N/A                    pytest
   :pypi:`pytest-watch`                             Local continuous test runner with pytest and watchdog.                                                                                                                                                    May 20, 2018    N/A                    N/A
   :pypi:`pytest-watcher`                           Automatically rerun your tests on file modifications                                                                                                                                                      Jun 24, 2023    4 - Beta               N/A
   :pypi:`pytest-wdl`                               Pytest plugin for testing WDL workflows.                                                                                                                                                                  Nov 17, 2020    5 - Production/Stable  N/A
   :pypi:`pytest-web3-data`                                                                                                                                                                                                                                   Sep 15, 2022    4 - Beta               pytest
   :pypi:`pytest-webdriver`                         Selenium webdriver fixture for py.test                                                                                                                                                                    May 28, 2019    5 - Production/Stable  pytest
   :pypi:`pytest-wetest`                            Welian API Automation test framework pytest plugin                                                                                                                                                        Nov 10, 2018    4 - Beta               N/A
   :pypi:`pytest-when`                              Utility which makes mocking more readable and controllable                                                                                                                                                Jun 05, 2023    N/A                    pytest>=7.3.1
   :pypi:`pytest-whirlwind`                         Testing Tornado.                                                                                                                                                                                          Jun 12, 2020    N/A                    N/A
   :pypi:`pytest-wholenodeid`                       pytest addon for displaying the whole node id for failures                                                                                                                                                Aug 26, 2015    4 - Beta               pytest (>=2.0)
   :pypi:`pytest-win32consoletitle`                 Pytest progress in console title (Win32 only)                                                                                                                                                             Aug 08, 2021    N/A                    N/A
   :pypi:`pytest-winnotify`                         Windows tray notifications for py.test results.                                                                                                                                                           Apr 22, 2016    N/A                    N/A
   :pypi:`pytest-wiremock`                          A pytest plugin for programmatically using wiremock in integration tests                                                                                                                                  Mar 27, 2022    N/A                    pytest (>=7.1.1,<8.0.0)
   :pypi:`pytest-with-docker`                       pytest with docker helpers.                                                                                                                                                                               Nov 09, 2021    N/A                    pytest
   :pypi:`pytest-workflow`                          A pytest plugin for configuring workflow/pipeline tests using YAML files                                                                                                                                  Jan 13, 2023    5 - Production/Stable  pytest (>=7.0.0)
   :pypi:`pytest-xdist`                             pytest xdist plugin for distributed testing, most importantly across multiple CPUs                                                                                                                        May 19, 2023    5 - Production/Stable  pytest (>=6.2.0)
   :pypi:`pytest-xdist-debug-for-graingert`         pytest xdist plugin for distributed testing and loop-on-failing modes                                                                                                                                     Jul 24, 2019    5 - Production/Stable  pytest (>=4.4.0)
   :pypi:`pytest-xdist-forked`                      forked from pytest-xdist                                                                                                                                                                                  Feb 10, 2020    5 - Production/Stable  pytest (>=4.4.0)
   :pypi:`pytest-xdist-tracker`                     pytest plugin helps to reproduce failures for particular xdist node                                                                                                                                       Nov 18, 2021    3 - Alpha              pytest (>=3.5.1)
   :pypi:`pytest-xdist-worker-stats`                A pytest plugin to list worker statistics after a xdist run.                                                                                                                                              Jun 19, 2023    4 - Beta               pytest (>=7.3.2,<8.0.0)
   :pypi:`pytest-xfaillist`                         Maintain a xfaillist in an additional file to avoid merge-conflicts.                                                                                                                                      Sep 17, 2021    N/A                    pytest (>=6.2.2,<7.0.0)
   :pypi:`pytest-xfiles`                            Pytest fixtures providing data read from function, module or package related (x)files.                                                                                                                    Feb 27, 2018    N/A                    N/A
   :pypi:`pytest-xlog`                              Extended logging for test and decorators                                                                                                                                                                  May 31, 2020    4 - Beta               N/A
   :pypi:`pytest-xlsx`                              pytest plugin for generating test cases by xlsx(excel)                                                                                                                                                    Mar 01, 2023    N/A                    pytest>=7.2.0
   :pypi:`pytest-xpara`                             An extended parametrizing plugin of pytest.                                                                                                                                                               Oct 30, 2017    3 - Alpha              pytest
   :pypi:`pytest-xprocess`                          A pytest plugin for managing processes across test runs.                                                                                                                                                  Jan 05, 2023    4 - Beta               pytest (>=2.8)
   :pypi:`pytest-xray`                                                                                                                                                                                                                                        May 30, 2019    3 - Alpha              N/A
   :pypi:`pytest-xrayjira`                                                                                                                                                                                                                                    Mar 17, 2020    3 - Alpha              pytest (==4.3.1)
   :pypi:`pytest-xray-server`                                                                                                                                                                                                                                 May 03, 2022    3 - Alpha              pytest (>=5.3.1)
   :pypi:`pytest-xskynet`                           A package to prevent Dependency Confusion attacks against Yandex.                                                                                                                                         Feb 10, 2023    N/A                    N/A
   :pypi:`pytest-xvfb`                              A pytest plugin to run Xvfb (or Xephyr/Xvnc) for tests.                                                                                                                                                   May 29, 2023    4 - Beta               pytest (>=2.8.1)
   :pypi:`pytest-xvirt`                             A pytest plugin to virtualize test. For example to transparently running them on a remote box.                                                                                                            Jun 18, 2023    4 - Beta               pytest (>=7.1.0)
   :pypi:`pytest-yaml`                              This plugin is used to load yaml output to your test using pytest framework.                                                                                                                              Oct 05, 2018    N/A                    pytest
   :pypi:`pytest-yaml-sanmu`                        pytest plugin for generating test cases by yaml                                                                                                                                                           May 28, 2023    N/A                    pytest>=7.2.0
   :pypi:`pytest-yamltree`                          Create or check file/directory trees described by YAML                                                                                                                                                    Mar 02, 2020    4 - Beta               pytest (>=3.1.1)
   :pypi:`pytest-yamlwsgi`                          Run tests against wsgi apps defined in yaml                                                                                                                                                               May 11, 2010    N/A                    N/A
   :pypi:`pytest-yaml-yoyo`                         http/https API run by yaml                                                                                                                                                                                Jun 19, 2023    N/A                    pytest (>=7.2.0)
   :pypi:`pytest-yapf`                              Run yapf                                                                                                                                                                                                  Jul 06, 2017    4 - Beta               pytest (>=3.1.1)
   :pypi:`pytest-yapf3`                             Validate your Python file format with yapf                                                                                                                                                                Mar 29, 2023    5 - Production/Stable  pytest (>=7)
   :pypi:`pytest-yield`                             PyTest plugin to run tests concurrently, each \`yield\` switch context to other one                                                                                                                       Jan 23, 2019    N/A                    N/A
   :pypi:`pytest-yls`                               Pytest plugin to test the YLS as a whole.                                                                                                                                                                 Jun 21, 2023    N/A                    pytest (>=7.2.2,<8.0.0)
   :pypi:`pytest-yuk`                               Display tests you are uneasy with, using 🤢/🤮 for pass/fail of tests marked with yuk.                                                                                                                    Mar 26, 2021    N/A                    pytest>=5.0.0
   :pypi:`pytest-zafira`                            A Zafira plugin for pytest                                                                                                                                                                                Sep 18, 2019    5 - Production/Stable  pytest (==4.1.1)
   :pypi:`pytest-zap`                               OWASP ZAP plugin for py.test.                                                                                                                                                                             May 12, 2014    4 - Beta               N/A
   :pypi:`pytest-zebrunner`                         Pytest connector for Zebrunner reporting                                                                                                                                                                  Dec 12, 2022    5 - Production/Stable  pytest (>=4.5.0)
   :pypi:`pytest-zest`                              Zesty additions to pytest.                                                                                                                                                                                Nov 17, 2022    N/A                    N/A
   :pypi:`pytest-zigzag`                            Extend py.test for RPC OpenStack testing.                                                                                                                                                                 Feb 27, 2019    4 - Beta               pytest (~=3.6)
   :pypi:`pytest-zulip`                             Pytest report plugin for Zulip                                                                                                                                                                            May 07, 2022    5 - Production/Stable  pytest
   ===============================================  ========================================================================================================================================================================================================  ==============  =====================  ================================================

.. only:: latex


  :pypi:`logassert`
     *last release*: May 20, 2022,
     *status*: 5 - Production/Stable,
     *requires*: N/A

     Simple but powerful assertion and verification of logged lines.

  :pypi:`pytest-abq`
     *last release*: Apr 07, 2023,
     *status*: N/A,
     *requires*: N/A

     Pytest integration for the ABQ universal test runner.

  :pypi:`pytest-abstracts`
     *last release*: May 25, 2022,
     *status*: N/A,
     *requires*: N/A

     A contextmanager pytest fixture for handling multiple mock abstracts

  :pypi:`pytest-accept`
     *last release*: Dec 21, 2022,
     *status*: N/A,
     *requires*: pytest (>=6,<8)

     A pytest-plugin for updating doctest outputs

  :pypi:`pytest-adaptavist`
     *last release*: Oct 13, 2022,
     *status*: N/A,
     *requires*: pytest (>=5.4.0)

     pytest plugin for generating test execution results within Jira Test Management (tm4j)

  :pypi:`pytest-addons-test`
     *last release*: Aug 02, 2021,
     *status*: N/A,
     *requires*: pytest (>=6.2.4,<7.0.0)

     用于测试pytest的插件

  :pypi:`pytest-adf`
     *last release*: May 10, 2021,
     *status*: 4 - Beta,
     *requires*: pytest (>=3.5.0)

     Pytest plugin for writing Azure Data Factory integration tests

  :pypi:`pytest-adf-azure-identity`
     *last release*: Mar 06, 2021,
     *status*: 4 - Beta,
     *requires*: pytest (>=3.5.0)

     Pytest plugin for writing Azure Data Factory integration tests

  :pypi:`pytest-ads-testplan`
     *last release*: Sep 15, 2022,
     *status*: N/A,
     *requires*: N/A

     Azure DevOps Test Case reporting for pytest tests

  :pypi:`pytest-agent`
     *last release*: Nov 25, 2021,
     *status*: N/A,
     *requires*: N/A

     Service that exposes a REST API that can be used to interract remotely with Pytest. It is shipped with a dashboard that enables running tests in a more convenient way.

  :pypi:`pytest-aggreport`
     *last release*: Mar 07, 2021,
     *status*: 4 - Beta,
     *requires*: pytest (>=6.2.2)

     pytest plugin for pytest-repeat that generate aggregate report of the same test cases with additional statistics details.

  :pypi:`pytest-aio`
     *last release*: Feb 03, 2023,
     *status*: 4 - Beta,
     *requires*: pytest

     Pytest plugin for testing async python code

  :pypi:`pytest-aiofiles`
     *last release*: May 14, 2017,
     *status*: 5 - Production/Stable,
     *requires*: N/A

     pytest fixtures for writing aiofiles tests with pyfakefs

  :pypi:`pytest-aiogram`
     *last release*: May 06, 2023,
     *status*: N/A,
     *requires*: N/A



  :pypi:`pytest-aiohttp`
     *last release*: Feb 12, 2022,
     *status*: 4 - Beta,
     *requires*: pytest (>=6.1.0)

     Pytest plugin for aiohttp support

  :pypi:`pytest-aiohttp-client`
     *last release*: Jan 10, 2023,
     *status*: N/A,
     *requires*: pytest (>=7.2.0,<8.0.0)

     Pytest \`client\` fixture for the Aiohttp

  :pypi:`pytest-aiomoto`
     *last release*: Jun 24, 2023,
     *status*: N/A,
     *requires*: pytest (>=7.0,<8.0)

     pytest-aiomoto

  :pypi:`pytest-aioresponses`
     *last release*: Jul 29, 2021,
     *status*: 4 - Beta,
     *requires*: pytest (>=3.5.0)

     py.test integration for aioresponses

  :pypi:`pytest-aioworkers`
     *last release*: May 01, 2023,
     *status*: 5 - Production/Stable,
     *requires*: pytest>=6.1.0

     A plugin to test aioworkers project with pytest

  :pypi:`pytest-airflow`
     *last release*: Apr 03, 2019,
     *status*: 3 - Alpha,
     *requires*: pytest (>=4.4.0)

     pytest support for airflow.

  :pypi:`pytest-airflow-utils`
     *last release*: Nov 15, 2021,
     *status*: N/A,
     *requires*: N/A



  :pypi:`pytest-alembic`
     *last release*: Jun 27, 2023,
     *status*: N/A,
     *requires*: pytest (>=6.0)

     A pytest plugin for verifying alembic migrations.

  :pypi:`pytest-allclose`
     *last release*: Jul 30, 2019,
     *status*: 5 - Production/Stable,
     *requires*: pytest

     Pytest fixture extending Numpy's allclose function

  :pypi:`pytest-allure-adaptor`
     *last release*: Jan 10, 2018,
     *status*: N/A,
     *requires*: pytest (>=2.7.3)

     Plugin for py.test to generate allure xml reports

  :pypi:`pytest-allure-adaptor2`
     *last release*: Oct 14, 2020,
     *status*: N/A,
     *requires*: pytest (>=2.7.3)

     Plugin for py.test to generate allure xml reports

  :pypi:`pytest-allure-collection`
     *last release*: Apr 13, 2023,
     *status*: N/A,
     *requires*: pytest

     pytest plugin to collect allure markers without running any tests

  :pypi:`pytest-allure-dsl`
     *last release*: Oct 25, 2020,
     *status*: 4 - Beta,
     *requires*: pytest

     pytest plugin to test case doc string dls instructions

  :pypi:`pytest-allure-intersection`
     *last release*: Oct 27, 2022,
     *status*: N/A,
     *requires*: pytest (<5)



  :pypi:`pytest-allure-spec-coverage`
     *last release*: Oct 26, 2021,
     *status*: N/A,
     *requires*: pytest

     The pytest plugin aimed to display test coverage of the specs(requirements) in Allure

  :pypi:`pytest-alphamoon`
     *last release*: Dec 30, 2021,
     *status*: 5 - Production/Stable,
     *requires*: pytest (>=3.5.0)

     Static code checks used at Alphamoon

  :pypi:`pytest-android`
     *last release*: Feb 21, 2019,
     *status*: 3 - Alpha,
     *requires*: pytest

     This fixture provides a configured "driver" for Android Automated Testing, using uiautomator2.

  :pypi:`pytest-anki`
     *last release*: Jul 31, 2022,
     *status*: 4 - Beta,
     *requires*: pytest (>=3.5.0)

     A pytest plugin for testing Anki add-ons

  :pypi:`pytest-annotate`
     *last release*: Jun 07, 2022,
     *status*: 3 - Alpha,
     *requires*: pytest (<8.0.0,>=3.2.0)

     pytest-annotate: Generate PyAnnotate annotations from your pytest tests.

  :pypi:`pytest-ansible`
     *last release*: May 15, 2023,
     *status*: 5 - Production/Stable,
     *requires*: pytest (<8.0.0,>=6)

     Plugin for pytest to simplify calling ansible modules from tests or fixtures

  :pypi:`pytest-ansible-playbook`
     *last release*: Mar 08, 2019,
     *status*: 4 - Beta,
     *requires*: N/A

     Pytest fixture which runs given ansible playbook file.

  :pypi:`pytest-ansible-playbook-runner`
     *last release*: Dec 02, 2020,
     *status*: 4 - Beta,
     *requires*: pytest (>=3.1.0)

     Pytest fixture which runs given ansible playbook file.

  :pypi:`pytest-ansible-units`
     *last release*: Apr 14, 2022,
     *status*: N/A,
     *requires*: N/A

     A pytest plugin for running unit tests within an ansible collection

  :pypi:`pytest-antilru`
     *last release*: Jul 05, 2022,
     *status*: 5 - Production/Stable,
     *requires*: pytest

     Bust functools.lru_cache when running pytest to avoid test pollution

  :pypi:`pytest-anyio`
     *last release*: Jun 29, 2021,
     *status*: N/A,
     *requires*: pytest

     The pytest anyio plugin is built into anyio. You don't need this package.

  :pypi:`pytest-anything`
     *last release*: Oct 13, 2022,
     *status*: N/A,
     *requires*: pytest

     Pytest fixtures to assert anything and something

  :pypi:`pytest-aoc`
     *last release*: Dec 08, 2022,
     *status*: N/A,
     *requires*: pytest ; extra == 'test'

     Downloads puzzle inputs for Advent of Code and synthesizes PyTest fixtures

  :pypi:`pytest-aoreporter`
     *last release*: Jun 27, 2022,
     *status*: N/A,
     *requires*: N/A

     pytest report

  :pypi:`pytest-api`
     *last release*: May 12, 2022,
     *status*: N/A,
     *requires*: pytest (>=7.1.1,<8.0.0)

     An ASGI middleware to populate OpenAPI Specification examples from pytest functions

  :pypi:`pytest-api-soup`
     *last release*: Aug 27, 2022,
     *status*: N/A,
     *requires*: N/A

     Validate multiple endpoints with unit testing using a single source of truth.

  :pypi:`pytest-apistellar`
     *last release*: Jun 18, 2019,
     *status*: N/A,
     *requires*: N/A

     apistellar plugin for pytest.

  :pypi:`pytest-appengine`
     *last release*: Feb 27, 2017,
     *status*: N/A,
     *requires*: N/A

     AppEngine integration that works well with pytest-django

  :pypi:`pytest-appium`
     *last release*: Dec 05, 2019,
     *status*: N/A,
     *requires*: N/A

     Pytest plugin for appium

  :pypi:`pytest-approvaltests`
     *last release*: May 08, 2022,
     *status*: 4 - Beta,
     *requires*: pytest (>=7.0.1)

     A plugin to use approvaltests with pytest

  :pypi:`pytest-approvaltests-geo`
     *last release*: Mar 04, 2023,
     *status*: 5 - Production/Stable,
     *requires*: pytest

     Extension for ApprovalTests.Python specific to geo data verification

  :pypi:`pytest-archon`
     *last release*: Jan 31, 2023,
     *status*: 5 - Production/Stable,
     *requires*: pytest (>=7.2)

     Rule your architecture like a real developer

  :pypi:`pytest-argus`
     *last release*: Jun 24, 2021,
     *status*: 5 - Production/Stable,
     *requires*: pytest (>=6.2.4)

     pyest results colection plugin

  :pypi:`pytest-arraydiff`
     *last release*: Jan 13, 2022,
     *status*: 4 - Beta,
     *requires*: pytest (>=4.6)

     pytest plugin to help with comparing array output from tests

  :pypi:`pytest-asgi-server`
     *last release*: Dec 12, 2020,
     *status*: N/A,
     *requires*: pytest (>=5.4.1)

     Convenient ASGI client/server fixtures for Pytest

  :pypi:`pytest-asptest`
     *last release*: Apr 28, 2018,
     *status*: 4 - Beta,
     *requires*: N/A

     test Answer Set Programming programs

  :pypi:`pytest-assertcount`
     *last release*: Oct 23, 2022,
     *status*: N/A,
     *requires*: pytest (>=5.0.0)

     Plugin to count actual number of asserts in pytest

  :pypi:`pytest-assertions`
     *last release*: Apr 27, 2022,
     *status*: N/A,
     *requires*: N/A

     Pytest Assertions

  :pypi:`pytest-assertutil`
     *last release*: May 10, 2019,
     *status*: N/A,
     *requires*: N/A

     pytest-assertutil

  :pypi:`pytest-assert-utils`
     *last release*: Apr 14, 2022,
     *status*: 3 - Alpha,
     *requires*: N/A

     Useful assertion utilities for use with pytest

  :pypi:`pytest-assume`
     *last release*: Jun 24, 2021,
     *status*: N/A,
     *requires*: pytest (>=2.7)

     A pytest plugin that allows multiple failures per test

  :pypi:`pytest-assurka`
     *last release*: Aug 04, 2022,
     *status*: N/A,
     *requires*: N/A

     A pytest plugin for Assurka Studio

  :pypi:`pytest-ast-back-to-python`
     *last release*: Sep 29, 2019,
     *status*: 4 - Beta,
     *requires*: N/A

     A plugin for pytest devs to view how assertion rewriting recodes the AST

  :pypi:`pytest-asteroid`
     *last release*: Aug 15, 2022,
     *status*: N/A,
     *requires*: pytest (>=6.2.5,<8.0.0)

     PyTest plugin for docker-based testing on database images

  :pypi:`pytest-astropy`
     *last release*: Apr 12, 2022,
     *status*: 5 - Production/Stable,
     *requires*: pytest (>=4.6)

     Meta-package containing dependencies for testing

  :pypi:`pytest-astropy-header`
     *last release*: Sep 06, 2022,
     *status*: 3 - Alpha,
     *requires*: pytest (>=4.6)

     pytest plugin to add diagnostic information to the header of the test output

  :pypi:`pytest-ast-transformer`
     *last release*: May 04, 2019,
     *status*: 3 - Alpha,
     *requires*: pytest



  :pypi:`pytest-asyncio`
     *last release*: Mar 19, 2023,
     *status*: 4 - Beta,
     *requires*: pytest (>=7.0.0)

     Pytest support for asyncio

  :pypi:`pytest-asyncio-cooperative`
     *last release*: May 31, 2023,
     *status*: N/A,
     *requires*: N/A

     Run all your asynchronous tests cooperatively.

  :pypi:`pytest-asyncio-network-simulator`
     *last release*: Jul 31, 2018,
     *status*: 3 - Alpha,
     *requires*: pytest (<3.7.0,>=3.3.2)

     pytest-asyncio-network-simulator: Plugin for pytest for simulator the network in tests

  :pypi:`pytest-async-mongodb`
     *last release*: Oct 18, 2017,
     *status*: 5 - Production/Stable,
     *requires*: pytest (>=2.5.2)

     pytest plugin for async MongoDB

  :pypi:`pytest-async-sqlalchemy`
     *last release*: Oct 07, 2021,
     *status*: 4 - Beta,
     *requires*: pytest (>=6.0.0)

     Database testing fixtures using the SQLAlchemy asyncio API

  :pypi:`pytest-atomic`
     *last release*: Nov 24, 2018,
     *status*: 4 - Beta,
     *requires*: N/A

     Skip rest of tests if previous test failed.

  :pypi:`pytest-attrib`
     *last release*: May 24, 2016,
     *status*: 4 - Beta,
     *requires*: N/A

     pytest plugin to select tests based on attributes similar to the nose-attrib plugin

  :pypi:`pytest-austin`
     *last release*: Oct 11, 2020,
     *status*: 4 - Beta,
     *requires*: N/A

     Austin plugin for pytest

  :pypi:`pytest-autocap`
     *last release*: May 15, 2022,
     *status*: N/A,
     *requires*: pytest (<7.2,>=7.1.2)

     automatically capture test & fixture stdout/stderr to files

  :pypi:`pytest-autochecklog`
     *last release*: Apr 25, 2015,
     *status*: 4 - Beta,
     *requires*: N/A

     automatically check condition and log all the checks

  :pypi:`pytest-automation`
     *last release*: May 20, 2022,
     *status*: N/A,
     *requires*: pytest (>=7.0.0)

     pytest plugin for building a test suite, using YAML files to extend pytest parameterize functionality.

  :pypi:`pytest-automock`
     *last release*: May 16, 2023,
     *status*: N/A,
     *requires*: pytest ; extra == 'dev'

     Pytest plugin for automatical mocks creation

  :pypi:`pytest-auto-parametrize`
     *last release*: Oct 02, 2016,
     *status*: 3 - Alpha,
     *requires*: N/A

     pytest plugin: avoid repeating arguments in parametrize

  :pypi:`pytest-autotest`
     *last release*: Aug 25, 2021,
     *status*: N/A,
     *requires*: pytest

     This fixture provides a configured "driver" for Android Automated Testing, using uiautomator2.

  :pypi:`pytest-aviator`
     *last release*: Nov 04, 2022,
     *status*: 4 - Beta,
     *requires*: pytest

     Aviator's Flakybot pytest plugin that automatically reruns flaky tests.

  :pypi:`pytest-avoidance`
     *last release*: May 23, 2019,
     *status*: 4 - Beta,
     *requires*: pytest (>=3.5.0)

     Makes pytest skip tests that don not need rerunning

  :pypi:`pytest-aws`
     *last release*: Oct 04, 2017,
     *status*: 4 - Beta,
     *requires*: N/A

     pytest plugin for testing AWS resource configurations

  :pypi:`pytest-aws-config`
     *last release*: May 28, 2021,
     *status*: N/A,
     *requires*: N/A

     Protect your AWS credentials in unit tests

  :pypi:`pytest-axe`
     *last release*: Nov 12, 2018,
     *status*: N/A,
     *requires*: pytest (>=3.0.0)

     pytest plugin for axe-selenium-python

  :pypi:`pytest-azure`
     *last release*: Jan 18, 2023,
     *status*: 3 - Alpha,
     *requires*: pytest

     Pytest utilities and mocks for Azure

  :pypi:`pytest-azure-devops`
     *last release*: Jun 20, 2022,
     *status*: 4 - Beta,
     *requires*: pytest (>=3.5.0)

     Simplifies using azure devops parallel strategy (https://docs.microsoft.com/en-us/azure/devops/pipelines/test/parallel-testing-any-test-runner) with pytest.

  :pypi:`pytest-azurepipelines`
     *last release*: Oct 20, 2022,
     *status*: 5 - Production/Stable,
     *requires*: pytest (>=5.0.0)

     Formatting PyTest output for Azure Pipelines UI

  :pypi:`pytest-bandit`
     *last release*: Feb 23, 2021,
     *status*: 4 - Beta,
     *requires*: pytest (>=3.5.0)

     A bandit plugin for pytest

  :pypi:`pytest-bandit-xayon`
     *last release*: Oct 17, 2022,
     *status*: 4 - Beta,
     *requires*: pytest (>=3.5.0)

     A bandit plugin for pytest

  :pypi:`pytest-base-url`
     *last release*: Mar 27, 2022,
     *status*: 5 - Production/Stable,
     *requires*: pytest (>=3.0.0,<8.0.0)

     pytest plugin for URL based testing

  :pypi:`pytest-bdd`
     *last release*: Nov 08, 2022,
     *status*: 6 - Mature,
     *requires*: pytest (>=6.2.0)

     BDD for pytest

  :pypi:`pytest-bdd-html`
     *last release*: Nov 22, 2022,
     *status*: 3 - Alpha,
     *requires*: pytest (!=6.0.0,>=5.0)

     pytest plugin to display BDD info in HTML test report

  :pypi:`pytest-bdd-ng`
     *last release*: Jul 01, 2023,
     *status*: 4 - Beta,
     *requires*: pytest (>=5.0)

     BDD for pytest

  :pypi:`pytest-bdd-splinter`
     *last release*: Aug 12, 2019,
     *status*: 5 - Production/Stable,
     *requires*: pytest (>=4.0.0)

     Common steps for pytest bdd and splinter integration

  :pypi:`pytest-bdd-web`
     *last release*: Jan 02, 2020,
     *status*: 4 - Beta,
     *requires*: pytest (>=3.5.0)

     A simple plugin to use with pytest

  :pypi:`pytest-bdd-wrappers`
     *last release*: Feb 11, 2020,
     *status*: 2 - Pre-Alpha,
     *requires*: N/A



  :pypi:`pytest-beakerlib`
     *last release*: Mar 17, 2017,
     *status*: 5 - Production/Stable,
     *requires*: pytest

     A pytest plugin that reports test results to the BeakerLib framework

  :pypi:`pytest-beds`
     *last release*: Jun 07, 2016,
     *status*: 4 - Beta,
     *requires*: N/A

     Fixtures for testing Google Appengine (GAE) apps

  :pypi:`pytest-beeprint`
     *last release*: Jun 09, 2023,
     *status*: 4 - Beta,
     *requires*: N/A

     use icdiff for better error messages in pytest assertions

  :pypi:`pytest-bench`
     *last release*: Jul 21, 2014,
     *status*: 3 - Alpha,
     *requires*: N/A

     Benchmark utility that plugs into pytest.

  :pypi:`pytest-benchmark`
     *last release*: Oct 25, 2022,
     *status*: 5 - Production/Stable,
     *requires*: pytest (>=3.8)

     A \`\`pytest\`\` fixture for benchmarking code. It will group the tests into rounds that are calibrated to the chosen timer.

  :pypi:`pytest-better-datadir`
     *last release*: Mar 13, 2023,
     *status*: N/A,
     *requires*: N/A

     A small example package

  :pypi:`pytest-bg-process`
     *last release*: Jan 24, 2022,
     *status*: 4 - Beta,
     *requires*: pytest (>=3.5.0)

     Pytest plugin to initialize background process

  :pypi:`pytest-bigchaindb`
     *last release*: Jan 24, 2022,
     *status*: 4 - Beta,
     *requires*: N/A

     A BigchainDB plugin for pytest.

  :pypi:`pytest-bigquery-mock`
     *last release*: Dec 28, 2022,
     *status*: N/A,
     *requires*: pytest (>=5.0)

     Provides a mock fixture for python bigquery client

  :pypi:`pytest-black`
     *last release*: Oct 05, 2020,
     *status*: 4 - Beta,
     *requires*: N/A

     A pytest plugin to enable format checking with black

  :pypi:`pytest-black-multipy`
     *last release*: Jan 14, 2021,
     *status*: 5 - Production/Stable,
     *requires*: pytest (!=3.7.3,>=3.5) ; extra == 'testing'

     Allow '--black' on older Pythons

  :pypi:`pytest-black-ng`
     *last release*: Oct 20, 2022,
     *status*: 4 - Beta,
     *requires*: pytest (>=7.0.0)

     A pytest plugin to enable format checking with black

  :pypi:`pytest-blame`
     *last release*: May 04, 2019,
     *status*: N/A,
     *requires*: pytest (>=4.4.0)

     A pytest plugin helps developers to debug by providing useful commits history.

  :pypi:`pytest-blender`
     *last release*: Jan 04, 2023,
     *status*: N/A,
     *requires*: pytest ; extra == 'dev'

     Blender Pytest plugin.

  :pypi:`pytest-blink1`
     *last release*: Jan 07, 2018,
     *status*: 4 - Beta,
     *requires*: N/A

     Pytest plugin to emit notifications via the Blink(1) RGB LED

  :pypi:`pytest-blockage`
     *last release*: Dec 21, 2021,
     *status*: N/A,
     *requires*: pytest

     Disable network requests during a test run.

  :pypi:`pytest-blocker`
     *last release*: Sep 07, 2015,
     *status*: 4 - Beta,
     *requires*: N/A

     pytest plugin to mark a test as blocker and skip all other tests

  :pypi:`pytest-blue`
     *last release*: Sep 05, 2022,
     *status*: N/A,
     *requires*: N/A

     A pytest plugin that adds a \`blue\` fixture for printing stuff in blue.

  :pypi:`pytest-board`
     *last release*: Jan 20, 2019,
     *status*: N/A,
     *requires*: N/A

     Local continuous test runner with pytest and watchdog.

  :pypi:`pytest-boost-xml`
     *last release*: Nov 30, 2022,
     *status*: 4 - Beta,
     *requires*: N/A

     Plugin for pytest to generate boost xml reports

  :pypi:`pytest-bootstrap`
     *last release*: Mar 04, 2022,
     *status*: N/A,
     *requires*: N/A



  :pypi:`pytest-bpdb`
     *last release*: Jan 19, 2015,
     *status*: 2 - Pre-Alpha,
     *requires*: N/A

     A py.test plug-in to enable drop to bpdb debugger on test failure.

  :pypi:`pytest-bravado`
     *last release*: Feb 15, 2022,
     *status*: N/A,
     *requires*: N/A

     Pytest-bravado automatically generates from OpenAPI specification client fixtures.

  :pypi:`pytest-breakword`
     *last release*: Aug 04, 2021,
     *status*: N/A,
     *requires*: pytest (>=6.2.4,<7.0.0)

     Use breakword with pytest

  :pypi:`pytest-breed-adapter`
     *last release*: Nov 07, 2018,
     *status*: 4 - Beta,
     *requires*: pytest (>=3.5.0)

     A simple plugin to connect with breed-server

  :pypi:`pytest-briefcase`
     *last release*: Jun 14, 2020,
     *status*: 4 - Beta,
     *requires*: pytest (>=3.5.0)

     A pytest plugin for running tests on a Briefcase project.

  :pypi:`pytest-browser`
     *last release*: Dec 10, 2016,
     *status*: 3 - Alpha,
     *requires*: N/A

     A pytest plugin for console based browser test selection just after the collection phase

  :pypi:`pytest-browsermob-proxy`
     *last release*: Jun 11, 2013,
     *status*: 4 - Beta,
     *requires*: N/A

     BrowserMob proxy plugin for py.test.

  :pypi:`pytest-browserstack-local`
     *last release*: Feb 09, 2018,
     *status*: N/A,
     *requires*: N/A

     \`\`py.test\`\` plugin to run \`\`BrowserStackLocal\`\` in background.

  :pypi:`pytest-budosystems`
     *last release*: May 07, 2023,
     *status*: 3 - Alpha,
     *requires*: pytest

     Budo Systems is a martial arts school management system. This module is the Budo Systems Pytest Plugin.

  :pypi:`pytest-bug`
     *last release*: Jun 23, 2023,
     *status*: 5 - Production/Stable,
     *requires*: pytest (>=7.1.0)

     Pytest plugin for marking tests as a bug

  :pypi:`pytest-bugtong-tag`
     *last release*: Jan 16, 2022,
     *status*: N/A,
     *requires*: N/A

     pytest-bugtong-tag is a plugin for pytest

  :pypi:`pytest-bugzilla`
     *last release*: May 05, 2010,
     *status*: 4 - Beta,
     *requires*: N/A

     py.test bugzilla integration plugin

  :pypi:`pytest-bugzilla-notifier`
     *last release*: Jun 15, 2018,
     *status*: 4 - Beta,
     *requires*: pytest (>=2.9.2)

     A plugin that allows you to execute create, update, and read information from BugZilla bugs

  :pypi:`pytest-buildkite`
     *last release*: Jul 13, 2019,
     *status*: 4 - Beta,
     *requires*: pytest (>=3.5.0)

     Plugin for pytest that automatically publishes coverage and pytest report annotations to Buildkite.

  :pypi:`pytest-builtin-types`
     *last release*: Nov 17, 2021,
     *status*: N/A,
     *requires*: pytest



  :pypi:`pytest-bwrap`
     *last release*: Oct 26, 2018,
     *status*: 3 - Alpha,
     *requires*: N/A

     Run your tests in Bubblewrap sandboxes

  :pypi:`pytest-cache`
     *last release*: Jun 04, 2013,
     *status*: 3 - Alpha,
     *requires*: N/A

     pytest plugin with mechanisms for caching across test runs

  :pypi:`pytest-cache-assert`
     *last release*: Feb 26, 2023,
     *status*: 5 - Production/Stable,
     *requires*: pytest (>=5.0.0)

     Cache assertion data to simplify regression testing of complex serializable data

  :pypi:`pytest-cagoule`
     *last release*: Jan 01, 2020,
     *status*: 3 - Alpha,
     *requires*: N/A

     Pytest plugin to only run tests affected by changes

  :pypi:`pytest-cairo`
     *last release*: Apr 17, 2022,
     *status*: N/A,
     *requires*: pytest

     Pytest support for cairo-lang and starknet

  :pypi:`pytest-call-checker`
     *last release*: Oct 16, 2022,
     *status*: 4 - Beta,
     *requires*: pytest (>=7.1.3,<8.0.0)

     Small pytest utility to easily create test doubles

  :pypi:`pytest-camel-collect`
     *last release*: Aug 02, 2020,
     *status*: N/A,
     *requires*: pytest (>=2.9)

     Enable CamelCase-aware pytest class collection

  :pypi:`pytest-canonical-data`
     *last release*: May 08, 2020,
     *status*: 2 - Pre-Alpha,
     *requires*: pytest (>=3.5.0)

     A plugin which allows to compare results with canonical results, based on previous runs

  :pypi:`pytest-caprng`
     *last release*: May 02, 2018,
     *status*: 4 - Beta,
     *requires*: N/A

     A plugin that replays pRNG state on failure.

  :pypi:`pytest-capture-deprecatedwarnings`
     *last release*: Apr 30, 2019,
     *status*: N/A,
     *requires*: N/A

     pytest plugin to capture all deprecatedwarnings and put them in one file

  :pypi:`pytest-capture-warnings`
     *last release*: May 03, 2022,
     *status*: N/A,
     *requires*: pytest

     pytest plugin to capture all warnings and put them in one file of your choice

  :pypi:`pytest-cases`
     *last release*: Feb 23, 2023,
     *status*: 5 - Production/Stable,
     *requires*: N/A

     Separate test code from test cases in pytest.

  :pypi:`pytest-cassandra`
     *last release*: Nov 04, 2017,
     *status*: 1 - Planning,
     *requires*: N/A

     Cassandra CCM Test Fixtures for pytest

  :pypi:`pytest-catchlog`
     *last release*: Jan 24, 2016,
     *status*: 4 - Beta,
     *requires*: pytest (>=2.6)

     py.test plugin to catch log messages. This is a fork of pytest-capturelog.

  :pypi:`pytest-catch-server`
     *last release*: Dec 12, 2019,
     *status*: 5 - Production/Stable,
     *requires*: N/A

     Pytest plugin with server for catching HTTP requests.

  :pypi:`pytest-celery`
     *last release*: May 06, 2021,
     *status*: N/A,
     *requires*: N/A

     pytest-celery a shim pytest plugin to enable celery.contrib.pytest

  :pypi:`pytest-chainmaker`
     *last release*: Oct 15, 2021,
     *status*: N/A,
     *requires*: N/A

     pytest plugin for chainmaker

  :pypi:`pytest-chalice`
     *last release*: Jul 01, 2020,
     *status*: 4 - Beta,
     *requires*: N/A

     A set of py.test fixtures for AWS Chalice

  :pypi:`pytest-change-assert`
     *last release*: Oct 19, 2022,
     *status*: N/A,
     *requires*: N/A

     修改报错中文为英文

  :pypi:`pytest-change-demo`
     *last release*: Mar 02, 2022,
     *status*: N/A,
     *requires*: pytest

     turn . into √，turn F into x

  :pypi:`pytest-change-report`
     *last release*: Sep 14, 2020,
     *status*: N/A,
     *requires*: pytest

     turn . into √，turn F into x

  :pypi:`pytest-change-xds`
     *last release*: Apr 16, 2022,
     *status*: N/A,
     *requires*: pytest

     turn . into √，turn F into x

  :pypi:`pytest-chdir`
     *last release*: Jan 28, 2020,
     *status*: N/A,
     *requires*: pytest (>=5.0.0,<6.0.0)

     A pytest fixture for changing current working directory

  :pypi:`pytest-check`
     *last release*: Jun 06, 2023,
     *status*: N/A,
     *requires*: pytest

     A pytest plugin that allows multiple failures per test.

  :pypi:`pytest-checkdocs`
     *last release*: Oct 09, 2022,
     *status*: 5 - Production/Stable,
     *requires*: pytest (>=6) ; extra == 'testing'

     check the README when running tests

  :pypi:`pytest-checkipdb`
     *last release*: Jul 22, 2020,
     *status*: 5 - Production/Stable,
     *requires*: pytest (>=2.9.2)

     plugin to check if there are ipdb debugs left

  :pypi:`pytest-check-library`
     *last release*: Jul 17, 2022,
     *status*: N/A,
     *requires*: N/A

     check your missing library

  :pypi:`pytest-check-libs`
     *last release*: Jul 17, 2022,
     *status*: N/A,
     *requires*: N/A

     check your missing library

  :pypi:`pytest-check-links`
     *last release*: Jul 29, 2020,
     *status*: N/A,
     *requires*: pytest>=7.0

     Check links in files

  :pypi:`pytest-check-mk`
     *last release*: Nov 19, 2015,
     *status*: 4 - Beta,
     *requires*: pytest

     pytest plugin to test Check_MK checks

  :pypi:`pytest-check-requirements`
     *last release*: Feb 10, 2023,
     *status*: N/A,
     *requires*: N/A

     A package to prevent Dependency Confusion attacks against Yandex.

  :pypi:`pytest-chic-report`
     *last release*: Jan 31, 2023,
     *status*: 5 - Production/Stable,
     *requires*: N/A

     A pytest plugin to send a report and printing summary of tests.

  :pypi:`pytest-chunks`
     *last release*: Jul 05, 2022,
     *status*: N/A,
     *requires*: pytest (>=6.0.0)

     Run only a chunk of your test suite

  :pypi:`pytest-circleci`
     *last release*: May 03, 2019,
     *status*: N/A,
     *requires*: N/A

     py.test plugin for CircleCI

  :pypi:`pytest-circleci-parallelized`
     *last release*: Oct 20, 2022,
     *status*: N/A,
     *requires*: N/A

     Parallelize pytest across CircleCI workers.

  :pypi:`pytest-circleci-parallelized-rjp`
     *last release*: Jun 21, 2022,
     *status*: N/A,
     *requires*: pytest

     Parallelize pytest across CircleCI workers.

  :pypi:`pytest-ckan`
     *last release*: Apr 28, 2020,
     *status*: 4 - Beta,
     *requires*: pytest

     Backport of CKAN 2.9 pytest plugin and fixtures to CAKN 2.8

  :pypi:`pytest-clarity`
     *last release*: Jun 11, 2021,
     *status*: N/A,
     *requires*: N/A

     A plugin providing an alternative, colourful diff output for failing assertions.

  :pypi:`pytest-cldf`
     *last release*: Nov 07, 2022,
     *status*: N/A,
     *requires*: pytest (>=3.6)

     Easy quality control for CLDF datasets using pytest

  :pypi:`pytest-click`
     *last release*: Feb 11, 2022,
     *status*: 5 - Production/Stable,
     *requires*: pytest (>=5.0)

     Pytest plugin for Click

  :pypi:`pytest-cli-fixtures`
     *last release*: Jul 28, 2022,
     *status*: N/A,
     *requires*: pytest (~=7.0)

     Automatically register fixtures for custom CLI arguments

  :pypi:`pytest-clld`
     *last release*: Jul 06, 2022,
     *status*: N/A,
     *requires*: pytest (>=3.6)



  :pypi:`pytest-cloud`
     *last release*: Oct 05, 2020,
     *status*: 6 - Mature,
     *requires*: N/A

     Distributed tests planner plugin for pytest testing framework.

  :pypi:`pytest-cloudflare-worker`
     *last release*: Mar 30, 2021,
     *status*: 4 - Beta,
     *requires*: pytest (>=6.0.0)

     pytest plugin for testing cloudflare workers

  :pypi:`pytest-cloudist`
     *last release*: Sep 02, 2022,
     *status*: 4 - Beta,
     *requires*: pytest (>=7.1.2,<8.0.0)

     Distribute tests to cloud machines without fuss

  :pypi:`pytest-cmake`
     *last release*: Jan 21, 2023,
     *status*: N/A,
     *requires*: pytest<8,>=4

     Provide CMake module for Pytest

  :pypi:`pytest-cmake-presets`
     *last release*: Dec 26, 2022,
     *status*: N/A,
     *requires*: pytest (>=7.2.0,<8.0.0)

     Execute CMake Presets via pytest

  :pypi:`pytest-cobra`
     *last release*: Jun 29, 2019,
     *status*: 3 - Alpha,
     *requires*: pytest (<4.0.0,>=3.7.1)

     PyTest plugin for testing Smart Contracts for Ethereum blockchain.

  :pypi:`pytest-codecarbon`
     *last release*: Jun 15, 2022,
     *status*: N/A,
     *requires*: pytest

     Pytest plugin for measuring carbon emissions

  :pypi:`pytest-codecheckers`
     *last release*: Feb 13, 2010,
     *status*: N/A,
     *requires*: N/A

     pytest plugin to add source code sanity checks (pep8 and friends)

  :pypi:`pytest-codecov`
     *last release*: Nov 29, 2022,
     *status*: 4 - Beta,
     *requires*: pytest (>=4.6.0)

     Pytest plugin for uploading pytest-cov results to codecov.io

  :pypi:`pytest-codegen`
     *last release*: Aug 23, 2020,
     *status*: 2 - Pre-Alpha,
     *requires*: N/A

     Automatically create pytest test signatures

  :pypi:`pytest-codeowners`
     *last release*: Mar 30, 2022,
     *status*: 4 - Beta,
     *requires*: pytest (>=6.0.0)

     Pytest plugin for selecting tests by GitHub CODEOWNERS.

  :pypi:`pytest-codestyle`
     *last release*: Mar 23, 2020,
     *status*: 3 - Alpha,
     *requires*: N/A

     pytest plugin to run pycodestyle

  :pypi:`pytest-codspeed`
     *last release*: Dec 02, 2022,
     *status*: 5 - Production/Stable,
     *requires*: pytest>=3.8

     Pytest plugin to create CodSpeed benchmarks

  :pypi:`pytest-collect-formatter`
     *last release*: Mar 29, 2021,
     *status*: 5 - Production/Stable,
     *requires*: N/A

     Formatter for pytest collect output

  :pypi:`pytest-collect-formatter2`
     *last release*: May 31, 2021,
     *status*: 5 - Production/Stable,
     *requires*: N/A

     Formatter for pytest collect output

  :pypi:`pytest-collector`
     *last release*: Aug 02, 2022,
     *status*: N/A,
     *requires*: pytest (>=7.0,<8.0)

     Python package for collecting pytest.

  :pypi:`pytest-colordots`
     *last release*: Oct 06, 2017,
     *status*: 5 - Production/Stable,
     *requires*: N/A

     Colorizes the progress indicators

  :pypi:`pytest-commander`
     *last release*: Aug 17, 2021,
     *status*: N/A,
     *requires*: pytest (<7.0.0,>=6.2.4)

     An interactive GUI test runner for PyTest

  :pypi:`pytest-common-subject`
     *last release*: May 15, 2022,
     *status*: N/A,
     *requires*: pytest (>=3.6,<8)

     pytest framework for testing different aspects of a common method

  :pypi:`pytest-compare`
     *last release*: Jun 22, 2023,
     *status*: 5 - Production/Stable,
     *requires*: N/A

     pytest plugin for comparing call arguments.

  :pypi:`pytest-concurrent`
     *last release*: Jan 12, 2019,
     *status*: 4 - Beta,
     *requires*: pytest (>=3.1.1)

     Concurrently execute test cases with multithread, multiprocess and gevent

  :pypi:`pytest-config`
     *last release*: Nov 07, 2014,
     *status*: 5 - Production/Stable,
     *requires*: N/A

     Base configurations and utilities for developing    your Python project test suite with pytest.

  :pypi:`pytest-confluence-report`
     *last release*: Apr 17, 2022,
     *status*: N/A,
     *requires*: N/A

     Package stands for pytest plugin to upload results into Confluence page.

  :pypi:`pytest-console-scripts`
     *last release*: May 31, 2023,
     *status*: 4 - Beta,
     *requires*: pytest (>=4.0.0)

     Pytest plugin for testing console scripts

  :pypi:`pytest-consul`
     *last release*: Nov 24, 2018,
     *status*: 3 - Alpha,
     *requires*: pytest

     pytest plugin with fixtures for testing consul aware apps

  :pypi:`pytest-container`
     *last release*: Jun 19, 2023,
     *status*: 4 - Beta,
     *requires*: pytest (>=3.10)

     Pytest fixtures for writing container based tests

  :pypi:`pytest-contextfixture`
     *last release*: Mar 12, 2013,
     *status*: 4 - Beta,
     *requires*: N/A

     Define pytest fixtures as context managers.

  :pypi:`pytest-contexts`
     *last release*: May 19, 2021,
     *status*: 4 - Beta,
     *requires*: N/A

     A plugin to run tests written with the Contexts framework using pytest

  :pypi:`pytest-cookies`
     *last release*: Mar 22, 2023,
     *status*: 5 - Production/Stable,
     *requires*: pytest (>=3.9.0)

     The pytest plugin for your Cookiecutter templates. 🍪

  :pypi:`pytest-copier`
     *last release*: Jun 23, 2023,
     *status*: 4 - Beta,
     *requires*: pytest>=7.1.2

     A pytest plugin to help testing Copier templates

  :pypi:`pytest-couchdbkit`
     *last release*: Apr 17, 2012,
     *status*: N/A,
     *requires*: N/A

     py.test extension for per-test couchdb databases using couchdbkit

  :pypi:`pytest-count`
     *last release*: Jan 12, 2018,
     *status*: 4 - Beta,
     *requires*: N/A

     count erros and send email

  :pypi:`pytest-cov`
     *last release*: May 24, 2023,
     *status*: 5 - Production/Stable,
     *requires*: pytest (>=4.6)

     Pytest plugin for measuring coverage.

  :pypi:`pytest-cover`
     *last release*: Aug 01, 2015,
     *status*: 5 - Production/Stable,
     *requires*: N/A

     Pytest plugin for measuring coverage. Forked from \`pytest-cov\`.

  :pypi:`pytest-coverage`
     *last release*: Jun 17, 2015,
     *status*: N/A,
     *requires*: N/A



  :pypi:`pytest-coverage-context`
     *last release*: Jun 28, 2023,
     *status*: 4 - Beta,
     *requires*: N/A

     Coverage dynamic context support for PyTest, including sub-processes

  :pypi:`pytest-coveragemarkers`
     *last release*: Nov 29, 2022,
     *status*: N/A,
     *requires*: pytest (>=7.1.2,<8.0.0)

     Using pytest markers to track functional coverage and filtering of tests

  :pypi:`pytest-cov-exclude`
     *last release*: Apr 29, 2016,
     *status*: 4 - Beta,
     *requires*: pytest (>=2.8.0,<2.9.0); extra == 'dev'

     Pytest plugin for excluding tests based on coverage data

  :pypi:`pytest-cpp`
     *last release*: Jan 30, 2023,
     *status*: 5 - Production/Stable,
     *requires*: pytest (>=7.0)

     Use pytest's runner to discover and execute C++ tests

  :pypi:`pytest-cppython`
     *last release*: Jun 19, 2023,
     *status*: N/A,
     *requires*: N/A

     A pytest plugin that imports CPPython testing types

  :pypi:`pytest-cqase`
     *last release*: Aug 22, 2022,
     *status*: N/A,
     *requires*: pytest (>=7.1.2,<8.0.0)

     Custom qase pytest plugin

  :pypi:`pytest-cram`
     *last release*: Aug 08, 2020,
     *status*: N/A,
     *requires*: N/A

     Run cram tests with pytest.

  :pypi:`pytest-crate`
     *last release*: May 28, 2019,
     *status*: 3 - Alpha,
     *requires*: pytest (>=4.0)

     Manages CrateDB instances during your integration tests

  :pypi:`pytest-crayons`
     *last release*: Mar 19, 2023,
     *status*: N/A,
     *requires*: pytest

     A pytest plugin for colorful print statements

  :pypi:`pytest-create`
     *last release*: Feb 15, 2023,
     *status*: 1 - Planning,
     *requires*: N/A

     pytest-create

  :pypi:`pytest-cricri`
     *last release*: Jan 27, 2018,
     *status*: N/A,
     *requires*: pytest

     A Cricri plugin for pytest.

  :pypi:`pytest-crontab`
     *last release*: Dec 09, 2019,
     *status*: N/A,
     *requires*: N/A

     add crontab task in crontab

  :pypi:`pytest-csv`
     *last release*: Apr 22, 2021,
     *status*: N/A,
     *requires*: pytest (>=6.0)

     CSV output for pytest.

  :pypi:`pytest-csv-params`
     *last release*: Jul 01, 2023,
     *status*: 5 - Production/Stable,
     *requires*: pytest (>=7.4.0,<8.0.0)

     Pytest plugin for Test Case Parametrization with CSV files

  :pypi:`pytest-curio`
     *last release*: Oct 07, 2020,
     *status*: N/A,
     *requires*: N/A

     Pytest support for curio.

  :pypi:`pytest-curl-report`
     *last release*: Dec 11, 2016,
     *status*: 4 - Beta,
     *requires*: N/A

     pytest plugin to generate curl command line report

  :pypi:`pytest-custom-concurrency`
     *last release*: Feb 08, 2021,
     *status*: N/A,
     *requires*: N/A

     Custom grouping concurrence for pytest

  :pypi:`pytest-custom-exit-code`
     *last release*: Aug 07, 2019,
     *status*: 4 - Beta,
     *requires*: pytest (>=4.0.2)

     Exit pytest test session with custom exit code in different scenarios

  :pypi:`pytest-custom-nodeid`
     *last release*: Mar 07, 2021,
     *status*: N/A,
     *requires*: N/A

     Custom grouping for pytest-xdist, rename test cases name and test cases nodeid, support allure report

  :pypi:`pytest-custom-report`
     *last release*: Jan 30, 2019,
     *status*: N/A,
     *requires*: pytest

     Configure the symbols displayed for test outcomes

  :pypi:`pytest-custom-scheduling`
     *last release*: Mar 01, 2021,
     *status*: N/A,
     *requires*: N/A

     Custom grouping for pytest-xdist, rename test cases name and test cases nodeid, support allure report

  :pypi:`pytest-cython`
     *last release*: Feb 16, 2023,
     *status*: 5 - Production/Stable,
     *requires*: pytest (>=4.6.0)

     A plugin for testing Cython extension modules

  :pypi:`pytest-cython-collect`
     *last release*: Jun 17, 2022,
     *status*: N/A,
     *requires*: pytest



  :pypi:`pytest-darker`
     *last release*: Aug 16, 2020,
     *status*: N/A,
     *requires*: pytest (>=6.0.1) ; extra == 'test'

     A pytest plugin for checking of modified code using Darker

  :pypi:`pytest-dash`
     *last release*: Mar 18, 2019,
     *status*: N/A,
     *requires*: N/A

     pytest fixtures to run dash applications.

  :pypi:`pytest-data`
     *last release*: Nov 01, 2016,
     *status*: 5 - Production/Stable,
     *requires*: N/A

     Useful functions for managing data for pytest fixtures

  :pypi:`pytest-databricks`
     *last release*: Jul 29, 2020,
     *status*: N/A,
     *requires*: pytest

     Pytest plugin for remote Databricks notebooks testing

  :pypi:`pytest-datadir`
     *last release*: Oct 25, 2022,
     *status*: 5 - Production/Stable,
     *requires*: pytest (>=5.0)

     pytest plugin for test data directories and files

  :pypi:`pytest-datadir-mgr`
     *last release*: Apr 06, 2023,
     *status*: 5 - Production/Stable,
     *requires*: pytest (>=7.1)

     Manager for test data: downloads, artifact caching, and a tmpdir context.

  :pypi:`pytest-datadir-ng`
     *last release*: Dec 25, 2019,
     *status*: 5 - Production/Stable,
     *requires*: pytest

     Fixtures for pytest allowing test functions/methods to easily retrieve test resources from the local filesystem.

  :pypi:`pytest-datadir-nng`
     *last release*: Nov 09, 2022,
     *status*: 5 - Production/Stable,
     *requires*: pytest (>=7.0.0,<8.0.0)

     Fixtures for pytest allowing test functions/methods to easily retrieve test resources from the local filesystem.

  :pypi:`pytest-data-extractor`
     *last release*: Jul 19, 2022,
     *status*: N/A,
     *requires*: pytest (>=7.0.1)

     A pytest plugin to extract relevant metadata about tests into an external file (currently only json support)

  :pypi:`pytest-data-file`
     *last release*: Dec 04, 2019,
     *status*: N/A,
     *requires*: N/A

     Fixture "data" and "case_data" for test from yaml file

  :pypi:`pytest-datafiles`
     *last release*: Feb 24, 2023,
     *status*: 5 - Production/Stable,
     *requires*: pytest (>=3.6)

     py.test plugin to create a 'tmp_path' containing predefined files/directories.

  :pypi:`pytest-datafixtures`
     *last release*: Dec 05, 2020,
     *status*: 5 - Production/Stable,
     *requires*: N/A

     Data fixtures for pytest made simple

  :pypi:`pytest-data-from-files`
     *last release*: Oct 13, 2021,
     *status*: 4 - Beta,
     *requires*: pytest

     pytest plugin to provide data from files loaded automatically

  :pypi:`pytest-dataplugin`
     *last release*: Sep 16, 2017,
     *status*: 1 - Planning,
     *requires*: N/A

     A pytest plugin for managing an archive of test data.

  :pypi:`pytest-datarecorder`
     *last release*: Jan 08, 2023,
     *status*: 5 - Production/Stable,
     *requires*: pytest

     A py.test plugin recording and comparing test output.

  :pypi:`pytest-dataset`
     *last release*: May 01, 2023,
     *status*: 5 - Production/Stable,
     *requires*: N/A

     Plugin for loading different datasets for pytest by prefix from json or yaml files

  :pypi:`pytest-data-suites`
     *last release*: Jul 24, 2022,
     *status*: N/A,
     *requires*: pytest (>=6.0,<8.0)

     Class-based pytest parametrization

  :pypi:`pytest-datatest`
     *last release*: Oct 15, 2020,
     *status*: 4 - Beta,
     *requires*: pytest (>=3.3)

     A pytest plugin for test driven data-wrangling (this is the development version of datatest's pytest integration).

  :pypi:`pytest-db`
     *last release*: Dec 04, 2019,
     *status*: N/A,
     *requires*: N/A

     Session scope fixture "db" for mysql query or change

  :pypi:`pytest-dbfixtures`
     *last release*: Dec 07, 2016,
     *status*: 4 - Beta,
     *requires*: N/A

     Databases fixtures plugin for py.test.

  :pypi:`pytest-db-plugin`
     *last release*: Nov 27, 2021,
     *status*: N/A,
     *requires*: pytest (>=5.0)



  :pypi:`pytest-dbt`
     *last release*: Jun 08, 2023,
     *status*: 2 - Pre-Alpha,
     *requires*: pytest (>=7.0.0,<8.0.0)

     Unit test dbt models with standard python tooling

  :pypi:`pytest-dbt-adapter`
     *last release*: Nov 24, 2021,
     *status*: N/A,
     *requires*: pytest (<7,>=6)

     A pytest plugin for testing dbt adapter plugins

  :pypi:`pytest-dbt-conventions`
     *last release*: Mar 02, 2022,
     *status*: N/A,
     *requires*: pytest (>=6.2.5,<7.0.0)

     A pytest plugin for linting a dbt project's conventions

  :pypi:`pytest-dbt-core`
     *last release*: May 03, 2023,
     *status*: N/A,
     *requires*: pytest (>=6.2.5) ; extra == 'test'

     Pytest extension for dbt.

  :pypi:`pytest-dbus-notification`
     *last release*: Mar 05, 2014,
     *status*: 5 - Production/Stable,
     *requires*: N/A

     D-BUS notifications for pytest results.

  :pypi:`pytest-dbx`
     *last release*: Nov 29, 2022,
     *status*: N/A,
     *requires*: pytest (>=7.1.3,<8.0.0)

     Pytest plugin to run unit tests for dbx (Databricks CLI extensions) related code

  :pypi:`pytest-deadfixtures`
     *last release*: Jul 23, 2020,
     *status*: 5 - Production/Stable,
     *requires*: N/A

     A simple plugin to list unused fixtures in pytest

  :pypi:`pytest-deepcov`
     *last release*: Mar 30, 2021,
     *status*: N/A,
     *requires*: N/A

     deepcov

  :pypi:`pytest-defer`
     *last release*: Aug 24, 2021,
     *status*: N/A,
     *requires*: N/A



  :pypi:`pytest-demo-plugin`
     *last release*: May 15, 2021,
     *status*: N/A,
     *requires*: N/A

     pytest示例插件

  :pypi:`pytest-dependency`
     *last release*: Feb 14, 2020,
     *status*: 4 - Beta,
     *requires*: N/A

     Manage dependencies of tests

  :pypi:`pytest-depends`
     *last release*: Apr 05, 2020,
     *status*: 5 - Production/Stable,
     *requires*: pytest (>=3)

     Tests that depend on other tests

  :pypi:`pytest-deprecate`
     *last release*: Jul 01, 2019,
     *status*: N/A,
     *requires*: N/A

     Mark tests as testing a deprecated feature with a warning note.

  :pypi:`pytest-describe`
     *last release*: Apr 09, 2023,
     *status*: 5 - Production/Stable,
     *requires*: pytest (<8,>=4.6)

     Describe-style plugin for pytest

  :pypi:`pytest-describe-it`
     *last release*: Jul 19, 2019,
     *status*: 4 - Beta,
     *requires*: pytest

     plugin for rich text descriptions

  :pypi:`pytest-devpi-server`
     *last release*: May 28, 2019,
     *status*: 5 - Production/Stable,
     *requires*: pytest

     DevPI server fixture for py.test

  :pypi:`pytest-dhos`
     *last release*: Sep 07, 2022,
     *status*: N/A,
     *requires*: N/A

     Common fixtures for pytest in DHOS services and libraries

  :pypi:`pytest-diamond`
     *last release*: Aug 31, 2015,
     *status*: 4 - Beta,
     *requires*: N/A

     pytest plugin for diamond

  :pypi:`pytest-dicom`
     *last release*: Dec 19, 2018,
     *status*: 3 - Alpha,
     *requires*: pytest

     pytest plugin to provide DICOM fixtures

  :pypi:`pytest-dictsdiff`
     *last release*: Jul 26, 2019,
     *status*: N/A,
     *requires*: N/A



  :pypi:`pytest-diff`
     *last release*: Mar 30, 2019,
     *status*: 4 - Beta,
     *requires*: pytest (>=3.5.0)

     A simple plugin to use with pytest

  :pypi:`pytest-diffeo`
     *last release*: Feb 10, 2023,
     *status*: N/A,
     *requires*: N/A

     A package to prevent Dependency Confusion attacks against Yandex.

  :pypi:`pytest-diff-selector`
     *last release*: Feb 24, 2022,
     *status*: 4 - Beta,
     *requires*: pytest (>=6.2.2) ; extra == 'all'

     Get tests affected by code changes (using git)

  :pypi:`pytest-difido`
     *last release*: Oct 23, 2022,
     *status*: 4 - Beta,
     *requires*: pytest (>=4.0.0)

     PyTest plugin for generating Difido reports

  :pypi:`pytest-dir-equal`
     *last release*: Jun 23, 2023,
     *status*: 4 - Beta,
     *requires*: pytest>=7.1.2

     pytest-dir-equals is a pytest plugin providing helpers to assert directories equality allowing golden testing

  :pypi:`pytest-disable`
     *last release*: Sep 10, 2015,
     *status*: 4 - Beta,
     *requires*: N/A

     pytest plugin to disable a test and skip it from testrun

  :pypi:`pytest-disable-plugin`
     *last release*: Feb 28, 2019,
     *status*: 4 - Beta,
     *requires*: pytest (>=3.5.0)

     Disable plugins per test

  :pypi:`pytest-discord`
     *last release*: Feb 05, 2023,
     *status*: 4 - Beta,
     *requires*: pytest (!=6.0.0,<8,>=3.3.2)

     A pytest plugin to notify test results to a Discord channel.

  :pypi:`pytest-django`
     *last release*: Dec 07, 2021,
     *status*: 5 - Production/Stable,
     *requires*: pytest (>=5.4.0)

     A Django plugin for pytest.

  :pypi:`pytest-django-ahead`
     *last release*: Oct 27, 2016,
     *status*: 5 - Production/Stable,
     *requires*: pytest (>=2.9)

     A Django plugin for pytest.

  :pypi:`pytest-djangoapp`
     *last release*: May 19, 2023,
     *status*: 4 - Beta,
     *requires*: pytest

     Nice pytest plugin to help you with Django pluggable application testing.

  :pypi:`pytest-django-cache-xdist`
     *last release*: May 12, 2020,
     *status*: 4 - Beta,
     *requires*: N/A

     A djangocachexdist plugin for pytest

  :pypi:`pytest-django-casperjs`
     *last release*: Mar 15, 2015,
     *status*: 2 - Pre-Alpha,
     *requires*: N/A

     Integrate CasperJS with your django tests as a pytest fixture.

  :pypi:`pytest-django-dotenv`
     *last release*: Nov 26, 2019,
     *status*: 4 - Beta,
     *requires*: pytest (>=2.6.0)

     Pytest plugin used to setup environment variables with django-dotenv

  :pypi:`pytest-django-factories`
     *last release*: Nov 12, 2020,
     *status*: 4 - Beta,
     *requires*: N/A

     Factories for your Django models that can be used as Pytest fixtures.

  :pypi:`pytest-django-filefield`
     *last release*: May 09, 2022,
     *status*: 5 - Production/Stable,
     *requires*: pytest >= 5.2

     Replaces FileField.storage with something you can patch globally.

  :pypi:`pytest-django-gcir`
     *last release*: Mar 06, 2018,
     *status*: 5 - Production/Stable,
     *requires*: N/A

     A Django plugin for pytest.

  :pypi:`pytest-django-haystack`
     *last release*: Sep 03, 2017,
     *status*: 5 - Production/Stable,
     *requires*: pytest (>=2.3.4)

     Cleanup your Haystack indexes between tests

  :pypi:`pytest-django-ifactory`
     *last release*: Jun 06, 2023,
     *status*: 5 - Production/Stable,
     *requires*: N/A

     A model instance factory for pytest-django

  :pypi:`pytest-django-lite`
     *last release*: Jan 30, 2014,
     *status*: N/A,
     *requires*: N/A

     The bare minimum to integrate py.test with Django.

  :pypi:`pytest-django-liveserver-ssl`
     *last release*: Jan 20, 2022,
     *status*: 3 - Alpha,
     *requires*: N/A



  :pypi:`pytest-django-model`
     *last release*: Feb 14, 2019,
     *status*: 4 - Beta,
     *requires*: N/A

     A Simple Way to Test your Django Models

  :pypi:`pytest-django-ordering`
     *last release*: Jul 25, 2019,
     *status*: 5 - Production/Stable,
     *requires*: pytest (>=2.3.0)

     A pytest plugin for preserving the order in which Django runs tests.

  :pypi:`pytest-django-queries`
     *last release*: Mar 01, 2021,
     *status*: N/A,
     *requires*: N/A

     Generate performance reports from your django database performance tests.

  :pypi:`pytest-djangorestframework`
     *last release*: Aug 11, 2019,
     *status*: 4 - Beta,
     *requires*: N/A

     A djangorestframework plugin for pytest

  :pypi:`pytest-django-rq`
     *last release*: Apr 13, 2020,
     *status*: 4 - Beta,
     *requires*: N/A

     A pytest plugin to help writing unit test for django-rq

  :pypi:`pytest-django-sqlcounts`
     *last release*: Jun 16, 2015,
     *status*: 4 - Beta,
     *requires*: N/A

     py.test plugin for reporting the number of SQLs executed per django testcase.

  :pypi:`pytest-django-testing-postgresql`
     *last release*: Jan 31, 2022,
     *status*: 4 - Beta,
     *requires*: N/A

     Use a temporary PostgreSQL database with pytest-django

  :pypi:`pytest-doc`
     *last release*: Jun 28, 2015,
     *status*: 5 - Production/Stable,
     *requires*: N/A

     A documentation plugin for py.test.

  :pypi:`pytest-docfiles`
     *last release*: Dec 22, 2021,
     *status*: 4 - Beta,
     *requires*: pytest (>=3.7.0)

     pytest plugin to test codeblocks in your documentation.

  :pypi:`pytest-docgen`
     *last release*: Apr 17, 2020,
     *status*: N/A,
     *requires*: N/A

     An RST Documentation Generator for pytest-based test suites

  :pypi:`pytest-docker`
     *last release*: Sep 14, 2022,
     *status*: N/A,
     *requires*: pytest (<8.0,>=4.0)

     Simple pytest fixtures for Docker and docker-compose based tests

  :pypi:`pytest-docker-apache-fixtures`
     *last release*: Feb 16, 2022,
     *status*: 4 - Beta,
     *requires*: pytest

     Pytest fixtures for testing with apache2 (httpd).

  :pypi:`pytest-docker-butla`
     *last release*: Jun 16, 2019,
     *status*: 3 - Alpha,
     *requires*: N/A



  :pypi:`pytest-dockerc`
     *last release*: Oct 09, 2020,
     *status*: 5 - Production/Stable,
     *requires*: pytest (>=3.0)

     Run, manage and stop Docker Compose project from Docker API

  :pypi:`pytest-docker-compose`
     *last release*: Jan 26, 2021,
     *status*: 5 - Production/Stable,
     *requires*: pytest (>=3.3)

     Manages Docker containers during your integration tests

  :pypi:`pytest-docker-db`
     *last release*: Mar 20, 2021,
     *status*: 5 - Production/Stable,
     *requires*: pytest (>=3.1.1)

     A plugin to use docker databases for pytests

  :pypi:`pytest-docker-fixtures`
     *last release*: May 02, 2023,
     *status*: 3 - Alpha,
     *requires*: pytest

     pytest docker fixtures

  :pypi:`pytest-docker-git-fixtures`
     *last release*: Feb 09, 2022,
     *status*: 4 - Beta,
     *requires*: pytest

     Pytest fixtures for testing with git scm.

  :pypi:`pytest-docker-haproxy-fixtures`
     *last release*: Feb 09, 2022,
     *status*: 4 - Beta,
     *requires*: pytest

     Pytest fixtures for testing with haproxy.

  :pypi:`pytest-docker-pexpect`
     *last release*: Jan 14, 2019,
     *status*: N/A,
     *requires*: pytest

     pytest plugin for writing functional tests with pexpect and docker

  :pypi:`pytest-docker-postgresql`
     *last release*: Sep 24, 2019,
     *status*: 4 - Beta,
     *requires*: pytest (>=3.5.0)

     A simple plugin to use with pytest

  :pypi:`pytest-docker-py`
     *last release*: Nov 27, 2018,
     *status*: N/A,
     *requires*: pytest (==4.0.0)

     Easy to use, simple to extend, pytest plugin that minimally leverages docker-py.

  :pypi:`pytest-docker-registry-fixtures`
     *last release*: Apr 08, 2022,
     *status*: 4 - Beta,
     *requires*: pytest

     Pytest fixtures for testing with docker registries.

  :pypi:`pytest-docker-service`
     *last release*: Feb 22, 2023,
     *status*: 3 - Alpha,
     *requires*: pytest (>=7.1.3)

     pytest plugin to start docker container

  :pypi:`pytest-docker-squid-fixtures`
     *last release*: Feb 09, 2022,
     *status*: 4 - Beta,
     *requires*: pytest

     Pytest fixtures for testing with squid.

  :pypi:`pytest-docker-tools`
     *last release*: Feb 17, 2022,
     *status*: 4 - Beta,
     *requires*: pytest (>=6.0.1)

     Docker integration tests for pytest

  :pypi:`pytest-docs`
     *last release*: Nov 11, 2018,
     *status*: 4 - Beta,
     *requires*: pytest (>=3.5.0)

     Documentation tool for pytest

  :pypi:`pytest-docstyle`
     *last release*: Mar 23, 2020,
     *status*: 3 - Alpha,
     *requires*: N/A

     pytest plugin to run pydocstyle

  :pypi:`pytest-doctest-custom`
     *last release*: Jul 25, 2016,
     *status*: 4 - Beta,
     *requires*: N/A

     A py.test plugin for customizing string representations of doctest results.

  :pypi:`pytest-doctest-ellipsis-markers`
     *last release*: Jan 12, 2018,
     *status*: 4 - Beta,
     *requires*: N/A

     Setup additional values for ELLIPSIS_MARKER for doctests

  :pypi:`pytest-doctest-import`
     *last release*: Nov 13, 2018,
     *status*: 4 - Beta,
     *requires*: pytest (>=3.3.0)

     A simple pytest plugin to import names and add them to the doctest namespace.

  :pypi:`pytest-doctestplus`
     *last release*: Jun 08, 2023,
     *status*: 3 - Alpha,
     *requires*: pytest (>=4.6)

     Pytest plugin with advanced doctest features.

  :pypi:`pytest-dolphin`
     *last release*: Nov 30, 2016,
     *status*: 4 - Beta,
     *requires*: pytest (==3.0.4)

     Some extra stuff that we use ininternally

  :pypi:`pytest-doorstop`
     *last release*: Jun 09, 2020,
     *status*: 4 - Beta,
     *requires*: pytest (>=3.5.0)

     A pytest plugin for adding test results into doorstop items.

  :pypi:`pytest-dotenv`
     *last release*: Jun 16, 2020,
     *status*: 4 - Beta,
     *requires*: pytest (>=5.0.0)

     A py.test plugin that parses environment files before running tests

  :pypi:`pytest-draw`
     *last release*: Mar 21, 2023,
     *status*: 3 - Alpha,
     *requires*: pytest

     Pytest plugin for randomly selecting a specific number of tests

  :pypi:`pytest-drf`
     *last release*: Jul 12, 2022,
     *status*: 5 - Production/Stable,
     *requires*: pytest (>=3.7)

     A Django REST framework plugin for pytest.

  :pypi:`pytest-drivings`
     *last release*: Jan 13, 2021,
     *status*: N/A,
     *requires*: N/A

     Tool to allow webdriver automation to be ran locally or remotely

  :pypi:`pytest-drop-dup-tests`
     *last release*: May 23, 2020,
     *status*: 4 - Beta,
     *requires*: pytest (>=2.7)

     A Pytest plugin to drop duplicated tests during collection

  :pypi:`pytest-dummynet`
     *last release*: Dec 15, 2021,
     *status*: 5 - Production/Stable,
     *requires*: pytest

     A py.test plugin providing access to a dummynet.

  :pypi:`pytest-dump2json`
     *last release*: Jun 29, 2015,
     *status*: N/A,
     *requires*: N/A

     A pytest plugin for dumping test results to json.

  :pypi:`pytest-duration-insights`
     *last release*: Jun 25, 2021,
     *status*: N/A,
     *requires*: N/A



  :pypi:`pytest-durations`
     *last release*: Apr 22, 2022,
     *status*: 5 - Production/Stable,
     *requires*: pytest (>=4.6)

     Pytest plugin reporting fixtures and test functions execution time.

  :pypi:`pytest-dynamicrerun`
     *last release*: Aug 15, 2020,
     *status*: 4 - Beta,
     *requires*: N/A

     A pytest plugin to rerun tests dynamically based off of test outcome and output.

  :pypi:`pytest-dynamodb`
     *last release*: Jun 12, 2023,
     *status*: 5 - Production/Stable,
     *requires*: pytest

     DynamoDB fixtures for pytest

  :pypi:`pytest-easy-addoption`
     *last release*: Jan 22, 2020,
     *status*: N/A,
     *requires*: N/A

     pytest-easy-addoption: Easy way to work with pytest addoption

  :pypi:`pytest-easy-api`
     *last release*: Mar 26, 2018,
     *status*: N/A,
     *requires*: N/A

     Simple API testing with pytest

  :pypi:`pytest-easyMPI`
     *last release*: Oct 21, 2020,
     *status*: N/A,
     *requires*: N/A

     Package that supports mpi tests in pytest

  :pypi:`pytest-easyread`
     *last release*: Nov 17, 2017,
     *status*: N/A,
     *requires*: N/A

     pytest plugin that makes terminal printouts of the reports easier to read

  :pypi:`pytest-easy-server`
     *last release*: May 01, 2021,
     *status*: 4 - Beta,
     *requires*: pytest (<5.0.0,>=4.3.1) ; python_version < "3.5"

     Pytest plugin for easy testing against servers

  :pypi:`pytest-ebics-sandbox`
     *last release*: Aug 15, 2022,
     *status*: N/A,
     *requires*: N/A

     A pytest plugin for testing against an EBICS sandbox server. Requires docker.

  :pypi:`pytest-ec2`
     *last release*: Oct 22, 2019,
     *status*: 3 - Alpha,
     *requires*: N/A

     Pytest execution on EC2 instance

  :pypi:`pytest-echo`
     *last release*: Jan 08, 2020,
     *status*: 5 - Production/Stable,
     *requires*: N/A

     pytest plugin with mechanisms for echoing environment variables, package version and generic attributes

  :pypi:`pytest-ekstazi`
     *last release*: Sep 10, 2022,
     *status*: N/A,
     *requires*: pytest

     Pytest plugin to select test using Ekstazi algorithm

  :pypi:`pytest-elasticsearch`
     *last release*: Mar 01, 2022,
     *status*: 5 - Production/Stable,
     *requires*: pytest (>=6.2.0)

     Elasticsearch fixtures and fixture factories for Pytest.

  :pypi:`pytest-elements`
     *last release*: Jan 13, 2021,
     *status*: N/A,
     *requires*: pytest (>=5.4,<6.0)

     Tool to help automate user interfaces

  :pypi:`pytest-eliot`
     *last release*: Aug 31, 2022,
     *status*: 1 - Planning,
     *requires*: pytest (>=5.4.0)

     An eliot plugin for pytest.

  :pypi:`pytest-elk-reporter`
     *last release*: Jan 24, 2021,
     *status*: 4 - Beta,
     *requires*: pytest (>=3.5.0)

     A simple plugin to use with pytest

  :pypi:`pytest-email`
     *last release*: Jul 08, 2020,
     *status*: N/A,
     *requires*: pytest

     Send execution result email

  :pypi:`pytest-embedded`
     *last release*: Jun 14, 2023,
     *status*: 5 - Production/Stable,
     *requires*: pytest>=7.0

     A pytest plugin that designed for embedded testing.

  :pypi:`pytest-embedded-arduino`
     *last release*: Jun 14, 2023,
     *status*: 5 - Production/Stable,
     *requires*: N/A

     Make pytest-embedded plugin work with Arduino.

  :pypi:`pytest-embedded-idf`
     *last release*: Jun 14, 2023,
     *status*: 5 - Production/Stable,
     *requires*: N/A

     Make pytest-embedded plugin work with ESP-IDF.

  :pypi:`pytest-embedded-jtag`
     *last release*: Jun 14, 2023,
     *status*: 5 - Production/Stable,
     *requires*: N/A

     Make pytest-embedded plugin work with JTAG.

  :pypi:`pytest-embedded-qemu`
     *last release*: Jun 14, 2023,
     *status*: 5 - Production/Stable,
     *requires*: N/A

     Make pytest-embedded plugin work with QEMU.

  :pypi:`pytest-embedded-serial`
     *last release*: Jun 14, 2023,
     *status*: 5 - Production/Stable,
     *requires*: N/A

     Make pytest-embedded plugin work with Serial.

  :pypi:`pytest-embedded-serial-esp`
     *last release*: Jun 14, 2023,
     *status*: 5 - Production/Stable,
     *requires*: N/A

     Make pytest-embedded plugin work with Espressif target boards.

  :pypi:`pytest-embrace`
     *last release*: Mar 25, 2023,
     *status*: N/A,
     *requires*: pytest (>=7.0,<8.0)

     💝  Dataclasses-as-tests. Describe the runtime once and multiply coverage with no boilerplate.

  :pypi:`pytest-emoji`
     *last release*: Feb 19, 2019,
     *status*: 4 - Beta,
     *requires*: pytest (>=4.2.1)

     A pytest plugin that adds emojis to your test result report

  :pypi:`pytest-emoji-output`
     *last release*: Apr 09, 2023,
     *status*: 4 - Beta,
     *requires*: pytest (==7.0.1)

     Pytest plugin to represent test output with emoji support

  :pypi:`pytest-enabler`
     *last release*: Jun 26, 2023,
     *status*: 5 - Production/Stable,
     *requires*: pytest (>=6) ; extra == 'testing'

     Enable installed pytest plugins

  :pypi:`pytest-encode`
     *last release*: Nov 06, 2021,
     *status*: N/A,
     *requires*: N/A

     set your encoding and logger

  :pypi:`pytest-encode-kane`
     *last release*: Nov 16, 2021,
     *status*: N/A,
     *requires*: pytest

     set your encoding and logger

  :pypi:`pytest-enhanced-reports`
     *last release*: Dec 15, 2022,
     *status*: N/A,
     *requires*: N/A

     Enhanced test reports for pytest

  :pypi:`pytest-enhancements`
     *last release*: Oct 30, 2019,
     *status*: 4 - Beta,
     *requires*: N/A

     Improvements for pytest (rejected upstream)

  :pypi:`pytest-env`
     *last release*: Jun 15, 2023,
     *status*: 5 - Production/Stable,
     *requires*: pytest>=7.3.1

     py.test plugin that allows you to add environment variables.

  :pypi:`pytest-envfiles`
     *last release*: Oct 08, 2015,
     *status*: 3 - Alpha,
     *requires*: N/A

     A py.test plugin that parses environment files before running tests

  :pypi:`pytest-env-info`
     *last release*: Nov 25, 2017,
     *status*: 4 - Beta,
     *requires*: pytest (>=3.1.1)

     Push information about the running pytest into envvars

  :pypi:`pytest-envraw`
     *last release*: Aug 27, 2020,
     *status*: 4 - Beta,
     *requires*: pytest (>=2.6.0)

     py.test plugin that allows you to add environment variables.

  :pypi:`pytest-envvars`
     *last release*: Jun 13, 2020,
     *status*: 5 - Production/Stable,
     *requires*: pytest (>=3.0.0)

     Pytest plugin to validate use of envvars on your tests

  :pypi:`pytest-env-yaml`
     *last release*: Apr 02, 2019,
     *status*: N/A,
     *requires*: N/A



  :pypi:`pytest-eradicate`
     *last release*: Sep 08, 2020,
     *status*: N/A,
     *requires*: pytest (>=2.4.2)

     pytest plugin to check for commented out code

  :pypi:`pytest-error-for-skips`
     *last release*: Dec 19, 2019,
     *status*: 4 - Beta,
     *requires*: pytest (>=4.6)

     Pytest plugin to treat skipped tests a test failure

  :pypi:`pytest-eth`
     *last release*: Aug 14, 2020,
     *status*: 1 - Planning,
     *requires*: N/A

     PyTest plugin for testing Smart Contracts for Ethereum Virtual Machine (EVM).

  :pypi:`pytest-ethereum`
     *last release*: Jun 24, 2019,
     *status*: 3 - Alpha,
     *requires*: pytest (==3.3.2); extra == 'dev'

     pytest-ethereum: Pytest library for ethereum projects.

  :pypi:`pytest-eucalyptus`
     *last release*: Jun 28, 2022,
     *status*: N/A,
     *requires*: pytest (>=4.2.0)

     Pytest Plugin for BDD

  :pypi:`pytest-eventlet`
     *last release*: Oct 04, 2021,
     *status*: N/A,
     *requires*: pytest ; extra == 'dev'

     Applies eventlet monkey-patch as a pytest plugin.

  :pypi:`pytest-examples`
     *last release*: May 05, 2023,
     *status*: 4 - Beta,
     *requires*: pytest>=7

     Pytest plugin for testing examples in docstrings and markdown files.

  :pypi:`pytest-excel`
     *last release*: Jan 31, 2022,
     *status*: 5 - Production/Stable,
     *requires*: N/A

     pytest plugin for generating excel reports

  :pypi:`pytest-exceptional`
     *last release*: Mar 16, 2017,
     *status*: 4 - Beta,
     *requires*: N/A

     Better exceptions

  :pypi:`pytest-exception-script`
     *last release*: Aug 04, 2020,
     *status*: 3 - Alpha,
     *requires*: pytest

     Walk your code through exception script to check it's resiliency to failures.

  :pypi:`pytest-executable`
     *last release*: Mar 25, 2023,
     *status*: N/A,
     *requires*: pytest (<8,>=4.3)

     pytest plugin for testing executables

  :pypi:`pytest-execution-timer`
     *last release*: Dec 24, 2021,
     *status*: 4 - Beta,
     *requires*: N/A

     A timer for the phases of Pytest's execution.

  :pypi:`pytest-expect`
     *last release*: Apr 21, 2016,
     *status*: 4 - Beta,
     *requires*: N/A

     py.test plugin to store test expectations and mark tests based on them

  :pypi:`pytest-expectdir`
     *last release*: Mar 19, 2023,
     *status*: 5 - Production/Stable,
     *requires*: pytest (>=5.0)

     A pytest plugin to provide initial/expected directories, and check a test transforms the initial directory to the expected one

  :pypi:`pytest-expecter`
     *last release*: Sep 18, 2022,
     *status*: 5 - Production/Stable,
     *requires*: N/A

     Better testing with expecter and pytest.

  :pypi:`pytest-expectr`
     *last release*: Oct 05, 2018,
     *status*: N/A,
     *requires*: pytest (>=2.4.2)

     This plugin is used to expect multiple assert using pytest framework.

  :pypi:`pytest-expect-test`
     *last release*: Apr 10, 2023,
     *status*: 4 - Beta,
     *requires*: pytest (>=3.5.0)

     A fixture to support expect tests in pytest

  :pypi:`pytest-experiments`
     *last release*: Dec 13, 2021,
     *status*: 4 - Beta,
     *requires*: pytest (>=6.2.5,<7.0.0)

     A pytest plugin to help developers of research-oriented software projects keep track of the results of their numerical experiments.

  :pypi:`pytest-explicit`
     *last release*: Jun 15, 2021,
     *status*: 5 - Production/Stable,
     *requires*: pytest

     A Pytest plugin to ignore certain marked tests by default

  :pypi:`pytest-exploratory`
     *last release*: Feb 21, 2022,
     *status*: N/A,
     *requires*: pytest (>=6.2)

     Interactive console for pytest.

  :pypi:`pytest-extensions`
     *last release*: Aug 17, 2022,
     *status*: 4 - Beta,
     *requires*: pytest ; extra == 'testing'

     A collection of helpers for pytest to ease testing

  :pypi:`pytest-external-blockers`
     *last release*: Oct 05, 2021,
     *status*: N/A,
     *requires*: pytest

     a special outcome for tests that are blocked for external reasons

  :pypi:`pytest-extra-durations`
     *last release*: Apr 21, 2020,
     *status*: 4 - Beta,
     *requires*: pytest (>=3.5.0)

     A pytest plugin to get durations on a per-function basis and per module basis.

  :pypi:`pytest-extra-markers`
     *last release*: Mar 05, 2023,
     *status*: 4 - Beta,
     *requires*: pytest

     Additional pytest markers to dynamically enable/disable tests viia CLI flags

  :pypi:`pytest-fabric`
     *last release*: Sep 12, 2018,
     *status*: 5 - Production/Stable,
     *requires*: N/A

     Provides test utilities to run fabric task tests by using docker containers

  :pypi:`pytest-factor`
     *last release*: Feb 10, 2023,
     *status*: N/A,
     *requires*: N/A

     A package to prevent Dependency Confusion attacks against Yandex.

  :pypi:`pytest-factory`
     *last release*: Sep 06, 2020,
     *status*: 3 - Alpha,
     *requires*: pytest (>4.3)

     Use factories for test setup with py.test

  :pypi:`pytest-factoryboy`
     *last release*: Dec 01, 2022,
     *status*: 6 - Mature,
     *requires*: pytest (>=5.0.0)

     Factory Boy support for pytest.

  :pypi:`pytest-factoryboy-fixtures`
     *last release*: Jun 25, 2020,
     *status*: N/A,
     *requires*: N/A

     Generates pytest fixtures that allow the use of type hinting

  :pypi:`pytest-factoryboy-state`
     *last release*: Mar 22, 2022,
     *status*: 5 - Production/Stable,
     *requires*: pytest (>=5.0)

     Simple factoryboy random state management

  :pypi:`pytest-failed-screen-record`
     *last release*: Jan 05, 2023,
     *status*: 4 - Beta,
     *requires*: pytest (>=7.1.2d,<8.0.0)

     Create a video of the screen when pytest fails

  :pypi:`pytest-failed-screenshot`
     *last release*: Apr 21, 2021,
     *status*: N/A,
     *requires*: N/A

     Test case fails,take a screenshot,save it,attach it to the allure

  :pypi:`pytest-failed-to-verify`
     *last release*: Aug 08, 2019,
     *status*: 5 - Production/Stable,
     *requires*: pytest (>=4.1.0)

     A pytest plugin that helps better distinguishing real test failures from setup flakiness.

  :pypi:`pytest-fail-slow`
     *last release*: Aug 13, 2022,
     *status*: 4 - Beta,
     *requires*: pytest (>=6.0)

     Fail tests that take too long to run

  :pypi:`pytest-faker`
     *last release*: Dec 19, 2016,
     *status*: 6 - Mature,
     *requires*: N/A

     Faker integration with the pytest framework.

  :pypi:`pytest-falcon`
     *last release*: Sep 07, 2016,
     *status*: 4 - Beta,
     *requires*: N/A

     Pytest helpers for Falcon.

  :pypi:`pytest-falcon-client`
     *last release*: Mar 19, 2019,
     *status*: N/A,
     *requires*: N/A

     Pytest \`client\` fixture for the Falcon Framework

  :pypi:`pytest-fantasy`
     *last release*: Mar 14, 2019,
     *status*: N/A,
     *requires*: N/A

     Pytest plugin for Flask Fantasy Framework

  :pypi:`pytest-fastapi`
     *last release*: Dec 27, 2020,
     *status*: N/A,
     *requires*: N/A



  :pypi:`pytest-fastapi-deps`
     *last release*: Jul 20, 2022,
     *status*: 5 - Production/Stable,
     *requires*: pytest

     A fixture which allows easy replacement of fastapi dependencies for testing

  :pypi:`pytest-fastest`
     *last release*: Jun 15, 2023,
     *status*: 4 - Beta,
     *requires*: pytest (>=4.4)

     Use SCM and coverage to run only needed tests

  :pypi:`pytest-fast-first`
     *last release*: Jan 19, 2023,
     *status*: 3 - Alpha,
     *requires*: pytest

     Pytest plugin that runs fast tests first

  :pypi:`pytest-faulthandler`
     *last release*: Jul 04, 2019,
     *status*: 6 - Mature,
     *requires*: pytest (>=5.0)

     py.test plugin that activates the fault handler module for tests (dummy package)

  :pypi:`pytest-fauxfactory`
     *last release*: Dec 06, 2017,
     *status*: 5 - Production/Stable,
     *requires*: pytest (>=3.2)

     Integration of fauxfactory into pytest.

  :pypi:`pytest-figleaf`
     *last release*: Jan 18, 2010,
     *status*: 5 - Production/Stable,
     *requires*: N/A

     py.test figleaf coverage plugin

  :pypi:`pytest-filecov`
     *last release*: Jun 27, 2021,
     *status*: 4 - Beta,
     *requires*: pytest

     A pytest plugin to detect unused files

  :pypi:`pytest-filedata`
     *last release*: Jan 17, 2019,
     *status*: 4 - Beta,
     *requires*: N/A

     easily load data from files

  :pypi:`pytest-filemarker`
     *last release*: Dec 01, 2020,
     *status*: N/A,
     *requires*: pytest

     A pytest plugin that runs marked tests when files change.

  :pypi:`pytest-file-watcher`
     *last release*: Mar 23, 2023,
     *status*: N/A,
     *requires*: pytest

     Pytest-File-Watcher is a CLI tool that watches for changes in your code and runs pytest on the changed files.

  :pypi:`pytest-filter-case`
     *last release*: Nov 05, 2020,
     *status*: N/A,
     *requires*: N/A

     run test cases filter by mark

  :pypi:`pytest-filter-subpackage`
     *last release*: Dec 12, 2022,
     *status*: 3 - Alpha,
     *requires*: pytest (>=3.0)

     Pytest plugin for filtering based on sub-packages

  :pypi:`pytest-find-dependencies`
     *last release*: Apr 09, 2022,
     *status*: 4 - Beta,
     *requires*: pytest (>=4.3.0)

     A pytest plugin to find dependencies between tests

  :pypi:`pytest-finer-verdicts`
     *last release*: Jun 18, 2020,
     *status*: N/A,
     *requires*: pytest (>=5.4.3)

     A pytest plugin to treat non-assertion failures as test errors.

  :pypi:`pytest-firefox`
     *last release*: Aug 08, 2017,
     *status*: 3 - Alpha,
     *requires*: pytest (>=3.0.2)

     pytest plugin to manipulate firefox

  :pypi:`pytest-fixture-classes`
     *last release*: Jan 20, 2023,
     *status*: 4 - Beta,
     *requires*: pytest

     Fixtures as classes that work well with dependency injection, autocompletetion, type checkers, and language servers

  :pypi:`pytest-fixture-config`
     *last release*: May 28, 2019,
     *status*: 5 - Production/Stable,
     *requires*: pytest

     Fixture configuration utils for py.test

  :pypi:`pytest-fixture-maker`
     *last release*: Sep 21, 2021,
     *status*: N/A,
     *requires*: N/A

     Pytest plugin to load fixtures from YAML files

  :pypi:`pytest-fixture-marker`
     *last release*: Oct 11, 2020,
     *status*: 5 - Production/Stable,
     *requires*: N/A

     A pytest plugin to add markers based on fixtures used.

  :pypi:`pytest-fixture-order`
     *last release*: May 16, 2022,
     *status*: 5 - Production/Stable,
     *requires*: pytest (>=3.0)

     pytest plugin to control fixture evaluation order

  :pypi:`pytest-fixture-ref`
     *last release*: Nov 17, 2022,
     *status*: 4 - Beta,
     *requires*: N/A

     Lets users reference fixtures without name matching magic.

  :pypi:`pytest-fixture-rtttg`
     *last release*: Feb 23, 2022,
     *status*: N/A,
     *requires*: pytest (>=7.0.1,<8.0.0)

     Warn or fail on fixture name clash

  :pypi:`pytest-fixtures`
     *last release*: May 01, 2019,
     *status*: 5 - Production/Stable,
     *requires*: N/A

     Common fixtures for pytest

  :pypi:`pytest-fixture-tools`
     *last release*: Aug 18, 2020,
     *status*: 6 - Mature,
     *requires*: pytest

     Plugin for pytest which provides tools for fixtures

  :pypi:`pytest-fixture-typecheck`
     *last release*: Aug 24, 2021,
     *status*: N/A,
     *requires*: pytest

     A pytest plugin to assert type annotations at runtime.

  :pypi:`pytest-flake8`
     *last release*: Mar 18, 2022,
     *status*: 4 - Beta,
     *requires*: pytest (>=7.0)

     pytest plugin to check FLAKE8 requirements

  :pypi:`pytest-flake8-path`
     *last release*: Jun 16, 2023,
     *status*: 5 - Production/Stable,
     *requires*: pytest

     A pytest fixture for testing flake8 plugins.

  :pypi:`pytest-flake8-v2`
     *last release*: Mar 01, 2022,
     *status*: 5 - Production/Stable,
     *requires*: pytest (>=7.0)

     pytest plugin to check FLAKE8 requirements

  :pypi:`pytest-flakefinder`
     *last release*: Oct 26, 2022,
     *status*: 4 - Beta,
     *requires*: pytest (>=2.7.1)

     Runs tests multiple times to expose flakiness.

  :pypi:`pytest-flakes`
     *last release*: Dec 02, 2021,
     *status*: 5 - Production/Stable,
     *requires*: pytest (>=5)

     pytest plugin to check source code with pyflakes

  :pypi:`pytest-flaptastic`
     *last release*: Mar 17, 2019,
     *status*: N/A,
     *requires*: N/A

     Flaptastic py.test plugin

  :pypi:`pytest-flask`
     *last release*: Feb 27, 2021,
     *status*: 5 - Production/Stable,
     *requires*: pytest (>=5.2)

     A set of py.test fixtures to test Flask applications.

  :pypi:`pytest-flask-ligand`
     *last release*: Apr 25, 2023,
     *status*: 4 - Beta,
     *requires*: pytest (~=7.3)

     Pytest fixtures and helper functions to use for testing flask-ligand microservices.

  :pypi:`pytest-flask-sqlalchemy`
     *last release*: Apr 30, 2022,
     *status*: 4 - Beta,
     *requires*: pytest (>=3.2.1)

     A pytest plugin for preserving test isolation in Flask-SQlAlchemy using database transactions.

  :pypi:`pytest-flask-sqlalchemy-transactions`
     *last release*: Aug 02, 2018,
     *status*: 4 - Beta,
     *requires*: pytest (>=3.2.1)

     Run tests in transactions using pytest, Flask, and SQLalchemy.

  :pypi:`pytest-flexreport`
     *last release*: Apr 15, 2023,
     *status*: 4 - Beta,
     *requires*: pytest



  :pypi:`pytest-fluent`
     *last release*: Jun 26, 2023,
     *status*: 4 - Beta,
     *requires*: pytest (>=7.0.0)

     A pytest plugin in order to provide logs via fluentd

  :pypi:`pytest-fluentbit`
     *last release*: Jun 16, 2023,
     *status*: 4 - Beta,
     *requires*: pytest (>=7.0.0)

     A pytest plugin in order to provide logs via fluentbit

  :pypi:`pytest-flyte`
     *last release*: May 03, 2021,
     *status*: N/A,
     *requires*: pytest

     Pytest fixtures for simplifying Flyte integration testing

  :pypi:`pytest-focus`
     *last release*: May 04, 2019,
     *status*: 4 - Beta,
     *requires*: pytest

     A pytest plugin that alerts user of failed test cases with screen notifications

  :pypi:`pytest-forbid`
     *last release*: Mar 07, 2023,
     *status*: N/A,
     *requires*: pytest (>=7.2.2,<8.0.0)



  :pypi:`pytest-forcefail`
     *last release*: May 15, 2018,
     *status*: 4 - Beta,
     *requires*: N/A

     py.test plugin to make the test failing regardless of pytest.mark.xfail

  :pypi:`pytest-forward-compatability`
     *last release*: Sep 06, 2020,
     *status*: N/A,
     *requires*: N/A

     A name to avoid typosquating pytest-foward-compatibility

  :pypi:`pytest-forward-compatibility`
     *last release*: Sep 29, 2020,
     *status*: N/A,
     *requires*: N/A

     A pytest plugin to shim pytest commandline options for fowards compatibility

  :pypi:`pytest-frappe`
     *last release*: May 03, 2023,
     *status*: 4 - Beta,
     *requires*: pytest>=7.0.0

     Pytest Frappe Plugin - A set of pytest fixtures to test Frappe applications

  :pypi:`pytest-freezegun`
     *last release*: Jul 19, 2020,
     *status*: 4 - Beta,
     *requires*: pytest (>=3.0.0)

     Wrap tests with fixtures in freeze_time

  :pypi:`pytest-freezer`
     *last release*: Jun 21, 2023,
     *status*: N/A,
     *requires*: pytest >= 3.6

     Pytest plugin providing a fixture interface for spulec/freezegun

  :pypi:`pytest-freeze-reqs`
     *last release*: Apr 29, 2021,
     *status*: N/A,
     *requires*: N/A

     Check if requirement files are frozen

  :pypi:`pytest-frozen-uuids`
     *last release*: Apr 17, 2022,
     *status*: N/A,
     *requires*: pytest (>=3.0)

     Deterministically frozen UUID's for your tests

  :pypi:`pytest-func-cov`
     *last release*: Apr 15, 2021,
     *status*: 3 - Alpha,
     *requires*: pytest (>=5)

     Pytest plugin for measuring function coverage

  :pypi:`pytest-funparam`
     *last release*: Dec 02, 2021,
     *status*: 4 - Beta,
     *requires*: pytest >=4.6.0

     An alternative way to parametrize test cases.

  :pypi:`pytest-fxa`
     *last release*: Aug 28, 2018,
     *status*: 5 - Production/Stable,
     *requires*: N/A

     pytest plugin for Firefox Accounts

  :pypi:`pytest-fxtest`
     *last release*: Oct 27, 2020,
     *status*: N/A,
     *requires*: N/A



  :pypi:`pytest-fzf`
     *last release*: Aug 17, 2022,
     *status*: 1 - Planning,
     *requires*: pytest (>=7.1.2)

     fzf-based test selector for pytest

  :pypi:`pytest-gather-fixtures`
     *last release*: Apr 12, 2022,
     *status*: N/A,
     *requires*: pytest (>=6.0.0)

     set up asynchronous pytest fixtures concurrently

  :pypi:`pytest-gc`
     *last release*: Feb 01, 2018,
     *status*: N/A,
     *requires*: N/A

     The garbage collector plugin for py.test

  :pypi:`pytest-gcov`
     *last release*: Feb 01, 2018,
     *status*: 3 - Alpha,
     *requires*: N/A

     Uses gcov to measure test coverage of a C library

  :pypi:`pytest-gevent`
     *last release*: Feb 25, 2020,
     *status*: N/A,
     *requires*: pytest

     Ensure that gevent is properly patched when invoking pytest

  :pypi:`pytest-gherkin`
     *last release*: Jul 27, 2019,
     *status*: 3 - Alpha,
     *requires*: pytest (>=5.0.0)

     A flexible framework for executing BDD gherkin tests

  :pypi:`pytest-gh-log-group`
     *last release*: Jan 11, 2022,
     *status*: 3 - Alpha,
     *requires*: pytest

     pytest plugin for gh actions

  :pypi:`pytest-ghostinspector`
     *last release*: May 17, 2016,
     *status*: 3 - Alpha,
     *requires*: N/A

     For finding/executing Ghost Inspector tests

  :pypi:`pytest-girder`
     *last release*: Jun 28, 2023,
     *status*: N/A,
     *requires*: N/A

     A set of pytest fixtures for testing Girder applications.

  :pypi:`pytest-git`
     *last release*: May 28, 2019,
     *status*: 5 - Production/Stable,
     *requires*: pytest

     Git repository fixture for py.test

  :pypi:`pytest-gitconfig`
     *last release*: Jun 22, 2023,
     *status*: 4 - Beta,
     *requires*: pytest>=7.1.2

     Provide a gitconfig sandbox for testing

  :pypi:`pytest-gitcov`
     *last release*: Jan 11, 2020,
     *status*: 2 - Pre-Alpha,
     *requires*: N/A

     Pytest plugin for reporting on coverage of the last git commit.

  :pypi:`pytest-git-fixtures`
     *last release*: Mar 11, 2021,
     *status*: 4 - Beta,
     *requires*: pytest

     Pytest fixtures for testing with git.

  :pypi:`pytest-github`
     *last release*: Mar 07, 2019,
     *status*: 5 - Production/Stable,
     *requires*: N/A

     Plugin for py.test that associates tests with github issues using a marker.

  :pypi:`pytest-github-actions-annotate-failures`
     *last release*: May 04, 2023,
     *status*: 5 - Production/Stable,
     *requires*: pytest (>=4.0.0)

     pytest plugin to annotate failed tests with a workflow command for GitHub Actions

  :pypi:`pytest-github-report`
     *last release*: Jun 03, 2022,
     *status*: 4 - Beta,
     *requires*: N/A

     Generate a GitHub report using pytest in GitHub Workflows

  :pypi:`pytest-gitignore`
     *last release*: Jul 17, 2015,
     *status*: 4 - Beta,
     *requires*: N/A

     py.test plugin to ignore the same files as git

  :pypi:`pytest-gitlabci-parallelized`
     *last release*: Mar 08, 2023,
     *status*: N/A,
     *requires*: N/A

     Parallelize pytest across GitLab CI workers.

  :pypi:`pytest-git-selector`
     *last release*: Nov 17, 2022,
     *status*: N/A,
     *requires*: N/A

     Utility to select tests that have had its dependencies modified (as identified by git diff)

  :pypi:`pytest-glamor-allure`
     *last release*: Jul 22, 2022,
     *status*: 4 - Beta,
     *requires*: pytest

     Extends allure-pytest functionality

  :pypi:`pytest-gnupg-fixtures`
     *last release*: Mar 04, 2021,
     *status*: 4 - Beta,
     *requires*: pytest

     Pytest fixtures for testing with gnupg.

  :pypi:`pytest-golden`
     *last release*: Jul 18, 2022,
     *status*: N/A,
     *requires*: pytest (>=6.1.2)

     Plugin for pytest that offloads expected outputs to data files

  :pypi:`pytest-goldie`
     *last release*: May 23, 2023,
     *status*: 4 - Beta,
     *requires*: pytest (>=3.5.0)

     A plugin to support golden tests with pytest.

  :pypi:`pytest-google-chat`
     *last release*: Mar 27, 2022,
     *status*: 4 - Beta,
     *requires*: pytest

     Notify google chat channel for test results

  :pypi:`pytest-graphql-schema`
     *last release*: Oct 18, 2019,
     *status*: N/A,
     *requires*: N/A

     Get graphql schema as fixture for pytest

  :pypi:`pytest-greendots`
     *last release*: Feb 08, 2014,
     *status*: 3 - Alpha,
     *requires*: N/A

     Green progress dots

  :pypi:`pytest-group-by-class`
     *last release*: Jun 27, 2023,
     *status*: 5 - Production/Stable,
     *requires*: pytest (>=2.5)

     A Pytest plugin for running a subset of your tests by splitting them in to groups of classes.

  :pypi:`pytest-growl`
     *last release*: Jan 13, 2014,
     *status*: 5 - Production/Stable,
     *requires*: N/A

     Growl notifications for pytest results.

  :pypi:`pytest-grpc`
     *last release*: May 01, 2020,
     *status*: N/A,
     *requires*: pytest (>=3.6.0)

     pytest plugin for grpc

  :pypi:`pytest-grunnur`
     *last release*: Feb 05, 2023,
     *status*: N/A,
     *requires*: N/A

     Py.Test plugin for Grunnur-based packages.

  :pypi:`pytest-hammertime`
     *last release*: Jul 28, 2018,
     *status*: N/A,
     *requires*: pytest

     Display "🔨 " instead of "." for passed pytest tests.

  :pypi:`pytest-harmony`
     *last release*: Jan 17, 2023,
     *status*: N/A,
     *requires*: pytest (>=7.2.1,<8.0.0)

     Chain tests and data with pytest

  :pypi:`pytest-harvest`
     *last release*: Jun 10, 2022,
     *status*: 5 - Production/Stable,
     *requires*: N/A

     Store data created during your pytest tests execution, and retrieve it at the end of the session, e.g. for applicative benchmarking purposes.

  :pypi:`pytest-helm-chart`
     *last release*: Jun 15, 2020,
     *status*: 4 - Beta,
     *requires*: pytest (>=5.4.2,<6.0.0)

     A plugin to provide different types and configs of Kubernetes clusters that can be used for testing.

  :pypi:`pytest-helm-charts`
     *last release*: Mar 08, 2023,
     *status*: 4 - Beta,
     *requires*: pytest (>=7.1.2,<8.0.0)

     A plugin to provide different types and configs of Kubernetes clusters that can be used for testing.

  :pypi:`pytest-helper`
     *last release*: May 31, 2019,
     *status*: 5 - Production/Stable,
     *requires*: N/A

     Functions to help in using the pytest testing framework

  :pypi:`pytest-helpers`
     *last release*: May 17, 2020,
     *status*: N/A,
     *requires*: pytest

     pytest helpers

  :pypi:`pytest-helpers-namespace`
     *last release*: Dec 29, 2021,
     *status*: 5 - Production/Stable,
     *requires*: pytest (>=6.0.0)

     Pytest Helpers Namespace Plugin

  :pypi:`pytest-hidecaptured`
     *last release*: May 04, 2018,
     *status*: 4 - Beta,
     *requires*: pytest (>=2.8.5)

     Hide captured output

  :pypi:`pytest-historic`
     *last release*: Apr 08, 2020,
     *status*: N/A,
     *requires*: pytest

     Custom report to display pytest historical execution records

  :pypi:`pytest-historic-hook`
     *last release*: Apr 08, 2020,
     *status*: N/A,
     *requires*: pytest

     Custom listener to store execution results into MYSQL DB, which is used for pytest-historic report

  :pypi:`pytest-homeassistant`
     *last release*: Aug 12, 2020,
     *status*: 4 - Beta,
     *requires*: N/A

     A pytest plugin for use with homeassistant custom components.

  :pypi:`pytest-homeassistant-custom-component`
     *last release*: Jun 24, 2023,
     *status*: 3 - Alpha,
     *requires*: pytest (==7.3.1)

     Experimental package to automatically extract test plugins for Home Assistant custom components

  :pypi:`pytest-honey`
     *last release*: Jan 07, 2022,
     *status*: 4 - Beta,
     *requires*: pytest (>=3.5.0)

     A simple plugin to use with pytest

  :pypi:`pytest-honors`
     *last release*: Mar 06, 2020,
     *status*: 4 - Beta,
     *requires*: N/A

     Report on tests that honor constraints, and guard against regressions

  :pypi:`pytest-hot-reloading`
     *last release*: Jun 23, 2023,
     *status*: N/A,
     *requires*: N/A



  :pypi:`pytest-hot-test`
     *last release*: Dec 10, 2022,
     *status*: 4 - Beta,
     *requires*: pytest (>=3.5.0)

     A plugin that tracks test changes

  :pypi:`pytest-hoverfly`
     *last release*: Jan 30, 2023,
     *status*: N/A,
     *requires*: pytest (>=5.0)

     Simplify working with Hoverfly from pytest

  :pypi:`pytest-hoverfly-wrapper`
     *last release*: Feb 27, 2023,
     *status*: 5 - Production/Stable,
     *requires*: pytest (>=3.7.0)

     Integrates the Hoverfly HTTP proxy into Pytest

  :pypi:`pytest-hpfeeds`
     *last release*: Feb 28, 2023,
     *status*: 4 - Beta,
     *requires*: pytest (>=6.2.4,<7.0.0)

     Helpers for testing hpfeeds in your python project

  :pypi:`pytest-html`
     *last release*: Apr 08, 2023,
     *status*: 5 - Production/Stable,
     *requires*: pytest (!=6.0.0,>=5.0)

     pytest plugin for generating HTML reports

  :pypi:`pytest-html-lee`
     *last release*: Jun 30, 2020,
     *status*: 5 - Production/Stable,
     *requires*: pytest (>=5.0)

     optimized pytest plugin for generating HTML reports

  :pypi:`pytest-html-merger`
     *last release*: Apr 03, 2022,
     *status*: N/A,
     *requires*: N/A

     Pytest HTML reports merging utility

  :pypi:`pytest-html-object-storage`
     *last release*: Mar 04, 2022,
     *status*: 5 - Production/Stable,
     *requires*: N/A

     Pytest report plugin for send HTML report on object-storage

  :pypi:`pytest-html-profiling`
     *last release*: Feb 11, 2020,
     *status*: 5 - Production/Stable,
     *requires*: pytest (>=3.0)

     Pytest plugin for generating HTML reports with per-test profiling and optionally call graph visualizations. Based on pytest-html by Dave Hunt.

  :pypi:`pytest-html-reporter`
     *last release*: Feb 13, 2022,
     *status*: N/A,
     *requires*: N/A

     Generates a static html report based on pytest framework

  :pypi:`pytest-html-report-merger`
     *last release*: Aug 31, 2022,
     *status*: N/A,
     *requires*: N/A



  :pypi:`pytest-html-thread`
     *last release*: Dec 29, 2020,
     *status*: 5 - Production/Stable,
     *requires*: N/A

     pytest plugin for generating HTML reports

  :pypi:`pytest-http`
     *last release*: Dec 05, 2019,
     *status*: N/A,
     *requires*: N/A

     Fixture "http" for http requests

  :pypi:`pytest-httpbin`
     *last release*: May 08, 2023,
     *status*: 5 - Production/Stable,
     *requires*: pytest ; extra == 'test'

     Easily test your HTTP library against a local copy of httpbin

  :pypi:`pytest-httpdbg`
     *last release*: May 09, 2023,
     *status*: 3 - Alpha,
     *requires*: pytest (>=7.0.0)

     A pytest plugin to record HTTP(S) requests with stack trace

  :pypi:`pytest-http-mocker`
     *last release*: Oct 20, 2019,
     *status*: N/A,
     *requires*: N/A

     Pytest plugin for http mocking (via https://github.com/vilus/mocker)

  :pypi:`pytest-httpretty`
     *last release*: Feb 16, 2014,
     *status*: 3 - Alpha,
     *requires*: N/A

     A thin wrapper of HTTPretty for pytest

  :pypi:`pytest-httpserver`
     *last release*: May 22, 2023,
     *status*: 3 - Alpha,
     *requires*: N/A

     pytest-httpserver is a httpserver for pytest

  :pypi:`pytest-httptesting`
     *last release*: Jun 03, 2023,
     *status*: N/A,
     *requires*: pytest (>=7.2.0,<8.0.0)

     http_testing framework on top of pytest

  :pypi:`pytest-httpx`
     *last release*: Apr 12, 2023,
     *status*: 5 - Production/Stable,
     *requires*: pytest (<8.0,>=6.0)

     Send responses to httpx.

  :pypi:`pytest-httpx-blockage`
     *last release*: Feb 16, 2023,
     *status*: N/A,
     *requires*: pytest (>=7.2.1)

     Disable httpx requests during a test run

  :pypi:`pytest-hue`
     *last release*: May 09, 2019,
     *status*: N/A,
     *requires*: N/A

     Visualise PyTest status via your Phillips Hue lights

  :pypi:`pytest-hylang`
     *last release*: Mar 28, 2021,
     *status*: N/A,
     *requires*: pytest

     Pytest plugin to allow running tests written in hylang

  :pypi:`pytest-hypo-25`
     *last release*: Jan 12, 2020,
     *status*: 3 - Alpha,
     *requires*: N/A

     help hypo module for pytest

  :pypi:`pytest-ibutsu`
     *last release*: Aug 05, 2022,
     *status*: 4 - Beta,
     *requires*: pytest>=7.1

     A plugin to sent pytest results to an Ibutsu server

  :pypi:`pytest-icdiff`
     *last release*: Aug 09, 2022,
     *status*: 4 - Beta,
     *requires*: N/A

     use icdiff for better error messages in pytest assertions

  :pypi:`pytest-idapro`
     *last release*: Nov 03, 2018,
     *status*: N/A,
     *requires*: N/A

     A pytest plugin for idapython. Allows a pytest setup to run tests outside and inside IDA in an automated manner by runnig pytest inside IDA and by mocking idapython api

  :pypi:`pytest-idem`
     *last release*: Jun 23, 2023,
     *status*: 5 - Production/Stable,
     *requires*: N/A

     A pytest plugin to help with testing idem projects

  :pypi:`pytest-idempotent`
     *last release*: Jul 25, 2022,
     *status*: N/A,
     *requires*: N/A

     Pytest plugin for testing function idempotence.

  :pypi:`pytest-ignore-flaky`
     *last release*: Apr 23, 2021,
     *status*: 5 - Production/Stable,
     *requires*: N/A

     ignore failures from flaky tests (pytest plugin)

  :pypi:`pytest-image-diff`
     *last release*: Mar 09, 2023,
     *status*: 3 - Alpha,
     *requires*: pytest



  :pypi:`pytest-incremental`
     *last release*: Apr 24, 2021,
     *status*: 5 - Production/Stable,
     *requires*: N/A

     an incremental test runner (pytest plugin)

  :pypi:`pytest-influxdb`
     *last release*: Apr 20, 2021,
     *status*: N/A,
     *requires*: N/A

     Plugin for influxdb and pytest integration.

  :pypi:`pytest-info-collector`
     *last release*: May 26, 2019,
     *status*: 3 - Alpha,
     *requires*: N/A

     pytest plugin to collect information from tests

  :pypi:`pytest-informative-node`
     *last release*: Apr 25, 2019,
     *status*: 4 - Beta,
     *requires*: N/A

     display more node ininformation.

  :pypi:`pytest-infrastructure`
     *last release*: Apr 12, 2020,
     *status*: 4 - Beta,
     *requires*: N/A

     pytest stack validation prior to testing executing

  :pypi:`pytest-ini`
     *last release*: Apr 26, 2022,
     *status*: N/A,
     *requires*: N/A

     Reuse pytest.ini to store env variables

  :pypi:`pytest-inline`
     *last release*: Feb 08, 2023,
     *status*: 4 - Beta,
     *requires*: pytest (>=7.0.0)

     A pytest plugin for writing inline tests.

  :pypi:`pytest-inmanta`
     *last release*: Feb 23, 2023,
     *status*: 5 - Production/Stable,
     *requires*: N/A

     A py.test plugin providing fixtures to simplify inmanta modules testing.

  :pypi:`pytest-inmanta-extensions`
     *last release*: Apr 12, 2023,
     *status*: 5 - Production/Stable,
     *requires*: N/A

     Inmanta tests package

  :pypi:`pytest-inmanta-lsm`
     *last release*: May 17, 2023,
     *status*: 5 - Production/Stable,
     *requires*: N/A

     Common fixtures for inmanta LSM related modules

  :pypi:`pytest-inmanta-yang`
     *last release*: Jun 16, 2022,
     *status*: 4 - Beta,
     *requires*: N/A

     Common fixtures used in inmanta yang related modules

  :pypi:`pytest-Inomaly`
     *last release*: Feb 13, 2018,
     *status*: 4 - Beta,
     *requires*: N/A

     A simple image diff plugin for pytest

  :pypi:`pytest-insta`
     *last release*: Nov 02, 2022,
     *status*: N/A,
     *requires*: pytest (>=7.2.0,<8.0.0)

     A practical snapshot testing plugin for pytest

  :pypi:`pytest-instafail`
     *last release*: Mar 31, 2023,
     *status*: 4 - Beta,
     *requires*: pytest (>=5)

     pytest plugin to show failures instantly

  :pypi:`pytest-instrument`
     *last release*: Apr 05, 2020,
     *status*: 5 - Production/Stable,
     *requires*: pytest (>=5.1.0)

     pytest plugin to instrument tests

  :pypi:`pytest-integration`
     *last release*: Nov 17, 2022,
     *status*: N/A,
     *requires*: N/A

     Organizing pytests by integration or not

  :pypi:`pytest-integration-mark`
     *last release*: May 22, 2023,
     *status*: N/A,
     *requires*: pytest (>=5.2)

     Automatic integration test marking and excluding plugin for pytest

  :pypi:`pytest-interactive`
     *last release*: Nov 30, 2017,
     *status*: 3 - Alpha,
     *requires*: N/A

     A pytest plugin for console based interactive test selection just after the collection phase

  :pypi:`pytest-intercept-remote`
     *last release*: May 24, 2021,
     *status*: 4 - Beta,
     *requires*: pytest (>=4.6)

     Pytest plugin for intercepting outgoing connection requests during pytest run.

  :pypi:`pytest-interface-tester`
     *last release*: Jun 29, 2023,
     *status*: 4 - Beta,
     *requires*: pytest

     Pytest plugin for checking charm relation interface protocol compliance.

  :pypi:`pytest-invenio`
     *last release*: Jun 02, 2023,
     *status*: 5 - Production/Stable,
     *requires*: pytest (<7.2.0,>=6)

     Pytest fixtures for Invenio.

  :pypi:`pytest-involve`
     *last release*: Feb 02, 2020,
     *status*: 4 - Beta,
     *requires*: pytest (>=3.5.0)

     Run tests covering a specific file or changeset

  :pypi:`pytest-ipdb`
     *last release*: Mar 20, 2013,
     *status*: 2 - Pre-Alpha,
     *requires*: N/A

     A py.test plug-in to enable drop to ipdb debugger on test failure.

  :pypi:`pytest-ipynb`
     *last release*: Jan 29, 2019,
     *status*: 3 - Alpha,
     *requires*: N/A

     THIS PROJECT IS ABANDONED

  :pypi:`pytest-isolate`
     *last release*: Feb 20, 2023,
     *status*: 4 - Beta,
     *requires*: pytest



  :pypi:`pytest-isort`
     *last release*: Oct 31, 2022,
     *status*: 5 - Production/Stable,
     *requires*: pytest (>=5.0)

     py.test plugin to check import ordering using isort

  :pypi:`pytest-is-running`
     *last release*: Jun 16, 2023,
     *status*: 5 - Production/Stable,
     *requires*: N/A

     pytest plugin providing a function to check if pytest is running.

  :pypi:`pytest-it`
     *last release*: Jan 22, 2020,
     *status*: 4 - Beta,
     *requires*: N/A

     Pytest plugin to display test reports as a plaintext spec, inspired by Rspec: https://github.com/mattduck/pytest-it.

  :pypi:`pytest-iterassert`
     *last release*: May 11, 2020,
     *status*: 3 - Alpha,
     *requires*: N/A

     Nicer list and iterable assertion messages for pytest

  :pypi:`pytest-iters`
     *last release*: May 24, 2022,
     *status*: N/A,
     *requires*: N/A

     A contextmanager pytest fixture for handling multiple mock iters

  :pypi:`pytest-jasmine`
     *last release*: Nov 04, 2017,
     *status*: 1 - Planning,
     *requires*: N/A

     Run jasmine tests from your pytest test suite

  :pypi:`pytest-jelastic`
     *last release*: Nov 16, 2022,
     *status*: N/A,
     *requires*: pytest (>=7.2.0,<8.0.0)

     Pytest plugin defining the necessary command-line options to pass to pytests testing a Jelastic environment.

  :pypi:`pytest-jest`
     *last release*: May 22, 2018,
     *status*: 4 - Beta,
     *requires*: pytest (>=3.3.2)

     A custom jest-pytest oriented Pytest reporter

  :pypi:`pytest-jinja`
     *last release*: Oct 04, 2022,
     *status*: 3 - Alpha,
     *requires*: pytest (>=6.2.5,<7.0.0)

     A plugin to generate customizable jinja-based HTML reports in pytest

  :pypi:`pytest-jira`
     *last release*: Jun 12, 2023,
     *status*: 3 - Alpha,
     *requires*: N/A

     py.test JIRA integration plugin, using markers

  :pypi:`pytest-jira-xfail`
     *last release*: Jun 19, 2023,
     *status*: N/A,
     *requires*: pytest (>=7.2.0)

     Plugin skips (xfail) tests if unresolved Jira issue(s) linked

  :pypi:`pytest-jira-xray`
     *last release*: Jun 06, 2023,
     *status*: 4 - Beta,
     *requires*: pytest

     pytest plugin to integrate tests with JIRA XRAY

  :pypi:`pytest-job-selection`
     *last release*: Jan 30, 2023,
     *status*: 4 - Beta,
     *requires*: pytest (>=3.5.0)

     A pytest plugin for load balancing test suites

  :pypi:`pytest-jobserver`
     *last release*: May 15, 2019,
     *status*: 5 - Production/Stable,
     *requires*: pytest

     Limit parallel tests with posix jobserver.

  :pypi:`pytest-joke`
     *last release*: Oct 08, 2019,
     *status*: 4 - Beta,
     *requires*: pytest (>=4.2.1)

     Test failures are better served with humor.

  :pypi:`pytest-json`
     *last release*: Jan 18, 2016,
     *status*: 4 - Beta,
     *requires*: N/A

     Generate JSON test reports

  :pypi:`pytest-json-fixtures`
     *last release*: Mar 14, 2023,
     *status*: 4 - Beta,
     *requires*: N/A

     JSON output for the --fixtures flag

  :pypi:`pytest-jsonlint`
     *last release*: Aug 04, 2016,
     *status*: N/A,
     *requires*: N/A

     UNKNOWN

  :pypi:`pytest-json-report`
     *last release*: Mar 15, 2022,
     *status*: 4 - Beta,
     *requires*: pytest (>=3.8.0)

     A pytest plugin to report test results as JSON files

  :pypi:`pytest-jtr`
     *last release*: Nov 29, 2022,
     *status*: N/A,
     *requires*: pytest (>=7.1.2,<8.0.0)

     pytest plugin supporting json test report output

  :pypi:`pytest-jupyter`
     *last release*: Mar 30, 2023,
     *status*: 4 - Beta,
     *requires*: pytest

     A pytest plugin for testing Jupyter libraries and extensions.

  :pypi:`pytest-jupyterhub`
     *last release*: Apr 25, 2023,
     *status*: 5 - Production/Stable,
     *requires*: pytest

     A reusable JupyterHub pytest plugin

  :pypi:`pytest-kafka`
     *last release*: Jun 14, 2023,
     *status*: N/A,
     *requires*: pytest

     Zookeeper, Kafka server, and Kafka consumer fixtures for Pytest

  :pypi:`pytest-kafkavents`
     *last release*: Sep 08, 2021,
     *status*: 4 - Beta,
     *requires*: pytest

     A plugin to send pytest events to Kafka

  :pypi:`pytest-kasima`
     *last release*: Jan 26, 2023,
     *status*: 5 - Production/Stable,
     *requires*: pytest (>=7.2.1,<8.0.0)

     Display horizontal lines above and below the captured standard output for easy viewing.

  :pypi:`pytest-keep-together`
     *last release*: Dec 07, 2022,
     *status*: 5 - Production/Stable,
     *requires*: pytest

     Pytest plugin to customize test ordering by running all 'related' tests together

  :pypi:`pytest-kexi`
     *last release*: Apr 29, 2022,
     *status*: N/A,
     *requires*: pytest (>=7.1.2,<8.0.0)



  :pypi:`pytest-kind`
     *last release*: Nov 30, 2022,
     *status*: 5 - Production/Stable,
     *requires*: N/A

     Kubernetes test support with KIND for pytest

  :pypi:`pytest-kivy`
     *last release*: Jul 06, 2021,
     *status*: 4 - Beta,
     *requires*: pytest (>=3.6)

     Kivy GUI tests fixtures using pytest

  :pypi:`pytest-knows`
     *last release*: Aug 22, 2014,
     *status*: N/A,
     *requires*: N/A

     A pytest plugin that can automaticly skip test case based on dependence info calculated by trace

  :pypi:`pytest-konira`
     *last release*: Oct 09, 2011,
     *status*: N/A,
     *requires*: N/A

     Run Konira DSL tests with py.test

  :pypi:`pytest-koopmans`
     *last release*: Nov 21, 2022,
     *status*: 4 - Beta,
     *requires*: pytest (>=3.5.0)

     A plugin for testing the koopmans package

  :pypi:`pytest-krtech-common`
     *last release*: Nov 28, 2016,
     *status*: 4 - Beta,
     *requires*: N/A

     pytest krtech common library

  :pypi:`pytest-kubernetes`
     *last release*: May 17, 2023,
     *status*: N/A,
     *requires*: pytest (>=7.2.1,<8.0.0)



  :pypi:`pytest-kwparametrize`
     *last release*: Jan 22, 2021,
     *status*: N/A,
     *requires*: pytest (>=6)

     Alternate syntax for @pytest.mark.parametrize with test cases as dictionaries and default value fallbacks

  :pypi:`pytest-lambda`
     *last release*: Aug 20, 2022,
     *status*: 3 - Alpha,
     *requires*: pytest (>=3.6,<8)

     Define pytest fixtures with lambda functions.

  :pypi:`pytest-lamp`
     *last release*: Jan 06, 2017,
     *status*: 3 - Alpha,
     *requires*: N/A



  :pypi:`pytest-langchain`
     *last release*: Feb 26, 2023,
     *status*: N/A,
     *requires*: pytest

     Pytest-style test runner for langchain agents

  :pypi:`pytest-lark`
     *last release*: Nov 20, 2022,
     *status*: N/A,
     *requires*: N/A

     A package for enhancing pytest

  :pypi:`pytest-launchable`
     *last release*: Apr 05, 2023,
     *status*: N/A,
     *requires*: pytest (>=4.2.0)

     Launchable Pytest Plugin

  :pypi:`pytest-layab`
     *last release*: Oct 05, 2020,
     *status*: 5 - Production/Stable,
     *requires*: N/A

     Pytest fixtures for layab.

  :pypi:`pytest-lazy-fixture`
     *last release*: Feb 01, 2020,
     *status*: 4 - Beta,
     *requires*: pytest (>=3.2.5)

     It helps to use fixtures in pytest.mark.parametrize

  :pypi:`pytest-lazy-fixtures`
     *last release*: May 28, 2023,
     *status*: N/A,
     *requires*: pytest (>=7.2.1,<8.0.0)

     Allows you to use fixtures in @pytest.mark.parametrize.

  :pypi:`pytest-ldap`
     *last release*: Aug 18, 2020,
     *status*: N/A,
     *requires*: pytest

     python-ldap fixtures for pytest

  :pypi:`pytest-leak-finder`
     *last release*: Feb 15, 2023,
     *status*: 4 - Beta,
     *requires*: pytest (>=3.5.0)

     Find the test that's leaking before the one that fails

  :pypi:`pytest-leaks`
     *last release*: Nov 27, 2019,
     *status*: 1 - Planning,
     *requires*: N/A

     A pytest plugin to trace resource leaks.

  :pypi:`pytest-level`
     *last release*: Oct 21, 2019,
     *status*: N/A,
     *requires*: pytest

     Select tests of a given level or lower

  :pypi:`pytest-libfaketime`
     *last release*: Dec 22, 2018,
     *status*: 4 - Beta,
     *requires*: pytest (>=3.0.0)

     A python-libfaketime plugin for pytest.

  :pypi:`pytest-libiio`
     *last release*: Jul 11, 2022,
     *status*: 4 - Beta,
     *requires*: N/A

     A pytest plugin to manage interfacing with libiio contexts

  :pypi:`pytest-libnotify`
     *last release*: Apr 02, 2021,
     *status*: 3 - Alpha,
     *requires*: pytest

     Pytest plugin that shows notifications about the test run

  :pypi:`pytest-ligo`
     *last release*: Jan 16, 2020,
     *status*: 4 - Beta,
     *requires*: N/A



  :pypi:`pytest-lineno`
     *last release*: Dec 04, 2020,
     *status*: N/A,
     *requires*: pytest

     A pytest plugin to show the line numbers of test functions

  :pypi:`pytest-line-profiler`
     *last release*: May 03, 2021,
     *status*: 4 - Beta,
     *requires*: pytest (>=3.5.0)

     Profile code executed by pytest

  :pypi:`pytest-line-profiler-apn`
     *last release*: Dec 05, 2022,
     *status*: N/A,
     *requires*: pytest (>=3.5.0)

     Profile code executed by pytest

  :pypi:`pytest-lisa`
     *last release*: Jan 21, 2021,
     *status*: 3 - Alpha,
     *requires*: pytest (>=6.1.2,<7.0.0)

     Pytest plugin for organizing tests.

  :pypi:`pytest-listener`
     *last release*: May 28, 2019,
     *status*: 5 - Production/Stable,
     *requires*: pytest

     A simple network listener

  :pypi:`pytest-litf`
     *last release*: Jan 18, 2021,
     *status*: 4 - Beta,
     *requires*: pytest (>=3.1.1)

     A pytest plugin that stream output in LITF format

  :pypi:`pytest-live`
     *last release*: Mar 08, 2020,
     *status*: N/A,
     *requires*: pytest

     Live results for pytest

  :pypi:`pytest-local-badge`
     *last release*: Jan 15, 2023,
     *status*: N/A,
     *requires*: pytest (>=6.1.0)

     Generate local badges (shields) reporting your test suite status.

  :pypi:`pytest-localftpserver`
     *last release*: Oct 04, 2022,
     *status*: 5 - Production/Stable,
     *requires*: pytest

     A PyTest plugin which provides an FTP fixture for your tests

  :pypi:`pytest-localserver`
     *last release*: Jan 30, 2023,
     *status*: 4 - Beta,
     *requires*: N/A

     pytest plugin to test server connections locally.

  :pypi:`pytest-localstack`
     *last release*: Jun 07, 2023,
     *status*: 4 - Beta,
     *requires*: pytest (>=6.0.0,<7.0.0)

     Pytest plugin for AWS integration tests

  :pypi:`pytest-lockable`
     *last release*: Jul 20, 2022,
     *status*: 5 - Production/Stable,
     *requires*: pytest

     lockable resource plugin for pytest

  :pypi:`pytest-locker`
     *last release*: Oct 29, 2021,
     *status*: N/A,
     *requires*: pytest (>=5.4)

     Used to lock object during testing. Essentially changing assertions from being hard coded to asserting that nothing changed

  :pypi:`pytest-log`
     *last release*: Aug 15, 2021,
     *status*: N/A,
     *requires*: pytest (>=3.8)

     print log

  :pypi:`pytest-logbook`
     *last release*: Nov 23, 2015,
     *status*: 5 - Production/Stable,
     *requires*: pytest (>=2.8)

     py.test plugin to capture logbook log messages

  :pypi:`pytest-logdog`
     *last release*: Jun 15, 2021,
     *status*: 1 - Planning,
     *requires*: pytest (>=6.2.0)

     Pytest plugin to test logging

  :pypi:`pytest-logfest`
     *last release*: Jul 21, 2019,
     *status*: 4 - Beta,
     *requires*: pytest (>=3.5.0)

     Pytest plugin providing three logger fixtures with basic or full writing to log files

  :pypi:`pytest-logger`
     *last release*: Jul 25, 2019,
     *status*: 4 - Beta,
     *requires*: pytest (>=3.2)

     Plugin configuring handlers for loggers from Python logging module.

  :pypi:`pytest-logging`
     *last release*: Nov 04, 2015,
     *status*: 4 - Beta,
     *requires*: N/A

     Configures logging and allows tweaking the log level with a py.test flag

  :pypi:`pytest-logging-end-to-end-test-tool`
     *last release*: Sep 23, 2022,
     *status*: N/A,
     *requires*: pytest (>=7.1.2,<8.0.0)



  :pypi:`pytest-logikal`
     *last release*: Jun 22, 2023,
     *status*: 5 - Production/Stable,
     *requires*: pytest (==7.3.1)

     Common testing environment

  :pypi:`pytest-log-report`
     *last release*: Dec 26, 2019,
     *status*: N/A,
     *requires*: N/A

     Package for creating a pytest test run reprot

  :pypi:`pytest-loguru`
     *last release*: Apr 12, 2022,
     *status*: 5 - Production/Stable,
     *requires*: N/A

     Pytest Loguru

  :pypi:`pytest-loop`
     *last release*: Jul 22, 2022,
     *status*: 5 - Production/Stable,
     *requires*: pytest (>=6)

     pytest plugin for looping tests

  :pypi:`pytest-lsp`
     *last release*: May 19, 2023,
     *status*: 3 - Alpha,
     *requires*: pytest

     pytest plugin for end-to-end testing of language servers

  :pypi:`pytest-manual-marker`
     *last release*: Aug 04, 2022,
     *status*: 3 - Alpha,
     *requires*: pytest>=7

     pytest marker for marking manual tests

  :pypi:`pytest-markdoctest`
     *last release*: Jul 22, 2022,
     *status*: 4 - Beta,
     *requires*: pytest (>=6)

     A pytest plugin to doctest your markdown files

  :pypi:`pytest-markdown`
     *last release*: Jan 15, 2021,
     *status*: 4 - Beta,
     *requires*: pytest (>=6.0.1,<7.0.0)

     Test your markdown docs with pytest

  :pypi:`pytest-markdown-docs`
     *last release*: Mar 09, 2023,
     *status*: N/A,
     *requires*: N/A

     Run markdown code fences through pytest

  :pypi:`pytest-marker-bugzilla`
     *last release*: Jan 09, 2020,
     *status*: N/A,
     *requires*: N/A

     py.test bugzilla integration plugin, using markers

  :pypi:`pytest-markers-presence`
     *last release*: Feb 04, 2021,
     *status*: 4 - Beta,
     *requires*: pytest (>=6.0)

     A simple plugin to detect missed pytest tags and markers"

  :pypi:`pytest-markfiltration`
     *last release*: Nov 08, 2011,
     *status*: 3 - Alpha,
     *requires*: N/A

     UNKNOWN

  :pypi:`pytest-mark-no-py3`
     *last release*: May 17, 2019,
     *status*: N/A,
     *requires*: pytest

     pytest plugin and bowler codemod to help migrate tests to Python 3

  :pypi:`pytest-marks`
     *last release*: Nov 23, 2012,
     *status*: 3 - Alpha,
     *requires*: N/A

     UNKNOWN

  :pypi:`pytest-matcher`
     *last release*: Dec 10, 2021,
     *status*: 5 - Production/Stable,
     *requires*: N/A

     Match test output against patterns stored in files

  :pypi:`pytest-match-skip`
     *last release*: May 15, 2019,
     *status*: 4 - Beta,
     *requires*: pytest (>=4.4.1)

     Skip matching marks. Matches partial marks using wildcards.

  :pypi:`pytest-mat-report`
     *last release*: Jan 20, 2021,
     *status*: N/A,
     *requires*: N/A

     this is report

  :pypi:`pytest-matrix`
     *last release*: Jun 24, 2020,
     *status*: 5 - Production/Stable,
     *requires*: pytest (>=5.4.3,<6.0.0)

     Provide tools for generating tests from combinations of fixtures.

  :pypi:`pytest-maybe-context`
     *last release*: Apr 16, 2023,
     *status*: N/A,
     *requires*: pytest (>=7,<8)

     Simplify tests with warning and exception cases.

  :pypi:`pytest-maybe-raises`
     *last release*: May 27, 2022,
     *status*: N/A,
     *requires*: pytest ; extra == 'dev'

     Pytest fixture for optional exception testing.

  :pypi:`pytest-mccabe`
     *last release*: Jul 22, 2020,
     *status*: 3 - Alpha,
     *requires*: pytest (>=5.4.0)

     pytest plugin to run the mccabe code complexity checker.

  :pypi:`pytest-md`
     *last release*: Jul 11, 2019,
     *status*: 3 - Alpha,
     *requires*: pytest (>=4.2.1)

     Plugin for generating Markdown reports for pytest results

  :pypi:`pytest-md-report`
     *last release*: Jun 25, 2023,
     *status*: 4 - Beta,
     *requires*: pytest (!=6.0.0,<8,>=3.3.2)

     A pytest plugin to make a test results report with Markdown table format.

  :pypi:`pytest-memlog`
     *last release*: May 03, 2023,
     *status*: N/A,
     *requires*: pytest (>=7.3.0,<8.0.0)

     Log memory usage during tests

  :pypi:`pytest-memprof`
     *last release*: Mar 29, 2019,
     *status*: 4 - Beta,
     *requires*: N/A

     Estimates memory consumption of test functions

  :pypi:`pytest-memray`
     *last release*: Jun 06, 2023,
     *status*: N/A,
     *requires*: pytest>=7.2

     A simple plugin to use with pytest

  :pypi:`pytest-menu`
     *last release*: Oct 04, 2017,
     *status*: 3 - Alpha,
     *requires*: pytest (>=2.4.2)

     A pytest plugin for console based interactive test selection just after the collection phase

  :pypi:`pytest-mercurial`
     *last release*: Nov 21, 2020,
     *status*: 1 - Planning,
     *requires*: N/A

     pytest plugin to write integration tests for projects using Mercurial Python internals

  :pypi:`pytest-mesh`
     *last release*: Aug 05, 2022,
     *status*: N/A,
     *requires*: pytest (==7.1.2)

     pytest_mesh插件

  :pypi:`pytest-message`
     *last release*: Aug 04, 2022,
     *status*: N/A,
     *requires*: pytest (>=6.2.5)

     Pytest plugin for sending report message of marked tests execution

  :pypi:`pytest-messenger`
     *last release*: Nov 24, 2022,
     *status*: 5 - Production/Stable,
     *requires*: N/A

     Pytest to Slack reporting plugin

  :pypi:`pytest-metadata`
     *last release*: May 27, 2023,
     *status*: 5 - Production/Stable,
     *requires*: pytest>=7.0.0

     pytest plugin for test session metadata

  :pypi:`pytest-metrics`
     *last release*: Apr 04, 2020,
     *status*: N/A,
     *requires*: pytest

     Custom metrics report for pytest

  :pypi:`pytest-mh`
     *last release*: Jun 08, 2023,
     *status*: N/A,
     *requires*: pytest

     Pytest multihost plugin

  :pypi:`pytest-mimesis`
     *last release*: Mar 21, 2020,
     *status*: 5 - Production/Stable,
     *requires*: pytest (>=4.2)

     Mimesis integration with the pytest test runner

  :pypi:`pytest-minecraft`
     *last release*: Apr 06, 2022,
     *status*: N/A,
     *requires*: pytest (>=6.0.1)

     A pytest plugin for running tests against Minecraft releases

  :pypi:`pytest-mini`
     *last release*: Feb 06, 2023,
     *status*: N/A,
     *requires*: pytest (>=7.2.0,<8.0.0)

     A plugin to test mp

  :pypi:`pytest-missing-fixtures`
     *last release*: Oct 14, 2020,
     *status*: 4 - Beta,
     *requires*: pytest (>=3.5.0)

     Pytest plugin that creates missing fixtures

  :pypi:`pytest-ml`
     *last release*: May 04, 2019,
     *status*: 4 - Beta,
     *requires*: N/A

     Test your machine learning!

  :pypi:`pytest-mocha`
     *last release*: Apr 02, 2020,
     *status*: 4 - Beta,
     *requires*: pytest (>=5.4.0)

     pytest plugin to display test execution output like a mochajs

  :pypi:`pytest-mock`
     *last release*: Jun 15, 2023,
     *status*: 5 - Production/Stable,
     *requires*: pytest (>=5.0)

     Thin-wrapper around the mock package for easier use with pytest

  :pypi:`pytest-mock-api`
     *last release*: Feb 13, 2019,
     *status*: 1 - Planning,
     *requires*: pytest (>=4.0.0)

     A mock API server with configurable routes and responses available as a fixture.

  :pypi:`pytest-mock-generator`
     *last release*: May 16, 2022,
     *status*: 5 - Production/Stable,
     *requires*: N/A

     A pytest fixture wrapper for https://pypi.org/project/mock-generator

  :pypi:`pytest-mock-helper`
     *last release*: Jan 24, 2018,
     *status*: N/A,
     *requires*: pytest

     Help you mock HTTP call and generate mock code

  :pypi:`pytest-mockito`
     *last release*: Jul 11, 2018,
     *status*: 4 - Beta,
     *requires*: N/A

     Base fixtures for mockito

  :pypi:`pytest-mockredis`
     *last release*: Jan 02, 2018,
     *status*: 2 - Pre-Alpha,
     *requires*: N/A

     An in-memory mock of a Redis server that runs in a separate thread. This is to be used for unit-tests that require a Redis database.

  :pypi:`pytest-mock-resources`
     *last release*: Jun 09, 2023,
     *status*: N/A,
     *requires*: pytest (>=1.0)

     A pytest plugin for easily instantiating reproducible mock resources.

  :pypi:`pytest-mock-server`
     *last release*: Jan 09, 2022,
     *status*: 4 - Beta,
     *requires*: pytest (>=3.5.0)

     Mock server plugin for pytest

  :pypi:`pytest-mockservers`
     *last release*: Mar 31, 2020,
     *status*: N/A,
     *requires*: pytest (>=4.3.0)

     A set of fixtures to test your requests to HTTP/UDP servers

  :pypi:`pytest-mocktcp`
     *last release*: Oct 11, 2022,
     *status*: N/A,
     *requires*: pytest

     A pytest plugin for testing TCP clients

  :pypi:`pytest-modified-env`
     *last release*: Jan 29, 2022,
     *status*: 4 - Beta,
     *requires*: N/A

     Pytest plugin to fail a test if it leaves modified \`os.environ\` afterwards.

  :pypi:`pytest-modifyjunit`
     *last release*: Jan 10, 2019,
     *status*: N/A,
     *requires*: N/A

     Utility for adding additional properties to junit xml for IDM QE

  :pypi:`pytest-modifyscope`
     *last release*: Apr 12, 2020,
     *status*: N/A,
     *requires*: pytest

     pytest plugin to modify fixture scope

  :pypi:`pytest-molecule`
     *last release*: Mar 29, 2022,
     *status*: 5 - Production/Stable,
     *requires*: pytest (>=7.0.0)

     PyTest Molecule Plugin :: discover and run molecule tests

  :pypi:`pytest-mongo`
     *last release*: Jun 07, 2021,
     *status*: 5 - Production/Stable,
     *requires*: pytest

     MongoDB process and client fixtures plugin for Pytest.

  :pypi:`pytest-mongodb`
     *last release*: May 16, 2023,
     *status*: 5 - Production/Stable,
     *requires*: N/A

     pytest plugin for MongoDB fixtures

  :pypi:`pytest-monitor`
     *last release*: Jun 25, 2023,
     *status*: 5 - Production/Stable,
     *requires*: pytest

     Pytest plugin for analyzing resource usage.

  :pypi:`pytest-monkeyplus`
     *last release*: Sep 18, 2012,
     *status*: 5 - Production/Stable,
     *requires*: N/A

     pytest's monkeypatch subclass with extra functionalities

  :pypi:`pytest-monkeytype`
     *last release*: Jul 29, 2020,
     *status*: 4 - Beta,
     *requires*: N/A

     pytest-monkeytype: Generate Monkeytype annotations from your pytest tests.

  :pypi:`pytest-moto`
     *last release*: Aug 28, 2015,
     *status*: 1 - Planning,
     *requires*: N/A

     Fixtures for integration tests of AWS services,uses moto mocking library.

  :pypi:`pytest-motor`
     *last release*: Jul 21, 2021,
     *status*: 3 - Alpha,
     *requires*: pytest

     A pytest plugin for motor, the non-blocking MongoDB driver.

  :pypi:`pytest-mp`
     *last release*: May 23, 2018,
     *status*: 4 - Beta,
     *requires*: pytest

     A test batcher for multiprocessed Pytest runs

  :pypi:`pytest-mpi`
     *last release*: Jan 08, 2022,
     *status*: 3 - Alpha,
     *requires*: pytest

     pytest plugin to collect information from tests

  :pypi:`pytest-mpiexec`
     *last release*: Apr 13, 2023,
     *status*: 3 - Alpha,
     *requires*: pytest

     pytest plugin for running individual tests with mpiexec

  :pypi:`pytest-mpl`
     *last release*: Jul 23, 2022,
     *status*: 4 - Beta,
     *requires*: pytest

     pytest plugin to help with testing figures output from Matplotlib

  :pypi:`pytest-mproc`
     *last release*: Nov 15, 2022,
     *status*: 4 - Beta,
     *requires*: pytest (>=6)

     low-startup-overhead, scalable, distributed-testing pytest plugin

  :pypi:`pytest-mqtt`
     *last release*: Mar 15, 2023,
     *status*: 4 - Beta,
     *requires*: pytest (<8) ; extra == 'test'

     pytest-mqtt supports testing systems based on MQTT

  :pypi:`pytest-multihost`
     *last release*: Apr 07, 2020,
     *status*: 4 - Beta,
     *requires*: N/A

     Utility for writing multi-host tests for pytest

  :pypi:`pytest-multilog`
     *last release*: Jan 17, 2023,
     *status*: N/A,
     *requires*: pytest

     Multi-process logs handling and other helpers for pytest

  :pypi:`pytest-multithreading`
     *last release*: Dec 07, 2022,
     *status*: N/A,
     *requires*: N/A

     a pytest plugin for th and concurrent testing

  :pypi:`pytest-multithreading-allure`
     *last release*: Nov 25, 2022,
     *status*: N/A,
     *requires*: N/A

     pytest_multithreading_allure

  :pypi:`pytest-mutagen`
     *last release*: Jul 24, 2020,
     *status*: N/A,
     *requires*: pytest (>=5.4)

     Add the mutation testing feature to pytest

  :pypi:`pytest-mypy`
     *last release*: Dec 18, 2022,
     *status*: 4 - Beta,
     *requires*: pytest (>=6.2) ; python_version >= "3.10"

     Mypy static type checker plugin for Pytest

  :pypi:`pytest-mypyd`
     *last release*: Aug 20, 2019,
     *status*: 4 - Beta,
     *requires*: pytest (<4.7,>=2.8) ; python_version < "3.5"

     Mypy static type checker plugin for Pytest

  :pypi:`pytest-mypy-plugins`
     *last release*: Jun 29, 2023,
     *status*: 4 - Beta,
     *requires*: pytest (>=7.0.0)

     pytest plugin for writing tests for mypy plugins

  :pypi:`pytest-mypy-plugins-shim`
     *last release*: Apr 12, 2021,
     *status*: N/A,
     *requires*: pytest>=6.0.0

     Substitute for "pytest-mypy-plugins" for Python implementations which aren't supported by mypy.

  :pypi:`pytest-mypy-testing`
     *last release*: Feb 25, 2023,
     *status*: N/A,
     *requires*: pytest>=7,<8

     Pytest plugin to check mypy output.

  :pypi:`pytest-mysql`
     *last release*: Mar 27, 2023,
     *status*: 5 - Production/Stable,
     *requires*: pytest (>=6.2)

     MySQL process and client fixtures for pytest

  :pypi:`pytest-needle`
     *last release*: Dec 10, 2018,
     *status*: 4 - Beta,
     *requires*: pytest (<5.0.0,>=3.0.0)

     pytest plugin for visual testing websites using selenium

  :pypi:`pytest-neo`
     *last release*: Jan 08, 2022,
     *status*: 3 - Alpha,
     *requires*: pytest (>=6.2.0)

     pytest-neo is a plugin for pytest that shows tests like screen of Matrix.

  :pypi:`pytest-netdut`
     *last release*: Jun 19, 2023,
     *status*: N/A,
     *requires*: pytest (>=3.5.0)

     "Automated software testing for switches using pytest"

  :pypi:`pytest-network`
     *last release*: May 07, 2020,
     *status*: N/A,
     *requires*: N/A

     A simple plugin to disable network on socket level.

  :pypi:`pytest-network-endpoints`
     *last release*: Mar 06, 2022,
     *status*: N/A,
     *requires*: pytest

     Network endpoints plugin for pytest

  :pypi:`pytest-never-sleep`
     *last release*: May 05, 2021,
     *status*: 3 - Alpha,
     *requires*: pytest (>=3.5.1)

     pytest plugin helps to avoid adding tests without mock \`time.sleep\`

  :pypi:`pytest-nginx`
     *last release*: Aug 12, 2017,
     *status*: 5 - Production/Stable,
     *requires*: N/A

     nginx fixture for pytest

  :pypi:`pytest-nginx-iplweb`
     *last release*: Mar 01, 2019,
     *status*: 5 - Production/Stable,
     *requires*: N/A

     nginx fixture for pytest - iplweb temporary fork

  :pypi:`pytest-ngrok`
     *last release*: Jan 20, 2022,
     *status*: 3 - Alpha,
     *requires*: pytest



  :pypi:`pytest-ngsfixtures`
     *last release*: Sep 06, 2019,
     *status*: 2 - Pre-Alpha,
     *requires*: pytest (>=5.0.0)

     pytest ngs fixtures

  :pypi:`pytest-nhsd-apim`
     *last release*: Jun 07, 2023,
     *status*: N/A,
     *requires*: pytest (==6.2.5)

     Pytest plugin accessing NHSDigital's APIM proxies

  :pypi:`pytest-nice`
     *last release*: May 04, 2019,
     *status*: 4 - Beta,
     *requires*: pytest

     A pytest plugin that alerts user of failed test cases with screen notifications

  :pypi:`pytest-nice-parametrize`
     *last release*: Apr 17, 2021,
     *status*: 5 - Production/Stable,
     *requires*: N/A

     A small snippet for nicer PyTest's Parametrize

  :pypi:`pytest-nlcov`
     *last release*: Jul 07, 2021,
     *status*: N/A,
     *requires*: N/A

     Pytest plugin to get the coverage of the new lines (based on git diff) only

  :pypi:`pytest-nocustom`
     *last release*: Jul 07, 2021,
     *status*: 5 - Production/Stable,
     *requires*: N/A

     Run all tests without custom markers

  :pypi:`pytest-nodev`
     *last release*: Jul 21, 2016,
     *status*: 4 - Beta,
     *requires*: pytest (>=2.8.1)

     Test-driven source code search for Python.

  :pypi:`pytest-nogarbage`
     *last release*: Aug 29, 2021,
     *status*: 5 - Production/Stable,
     *requires*: pytest (>=4.6.0)

     Ensure a test produces no garbage

  :pypi:`pytest-notice`
     *last release*: Nov 05, 2020,
     *status*: N/A,
     *requires*: N/A

     Send pytest execution result email

  :pypi:`pytest-notification`
     *last release*: Jun 19, 2020,
     *status*: N/A,
     *requires*: pytest (>=4)

     A pytest plugin for sending a desktop notification and playing a sound upon completion of tests

  :pypi:`pytest-notifier`
     *last release*: Jun 12, 2020,
     *status*: 3 - Alpha,
     *requires*: pytest

     A pytest plugin to notify test result

  :pypi:`pytest-notimplemented`
     *last release*: Aug 27, 2019,
     *status*: N/A,
     *requires*: pytest (>=5.1,<6.0)

     Pytest markers for not implemented features and tests.

  :pypi:`pytest-notion`
     *last release*: Aug 07, 2019,
     *status*: N/A,
     *requires*: N/A

     A PyTest Reporter to send test runs to Notion.so

  :pypi:`pytest-nunit`
     *last release*: Oct 20, 2022,
     *status*: 5 - Production/Stable,
     *requires*: pytest (>=4.6.0)

     A pytest plugin for generating NUnit3 test result XML output

  :pypi:`pytest-oar`
     *last release*: May 02, 2023,
     *status*: N/A,
     *requires*: pytest>=6.0.1

     PyTest plugin for the OAR testing framework

  :pypi:`pytest-object-getter`
     *last release*: Jul 31, 2022,
     *status*: 5 - Production/Stable,
     *requires*: pytest

     Import any object from a 3rd party module while mocking its namespace on demand.

  :pypi:`pytest-ochrus`
     *last release*: Feb 21, 2018,
     *status*: 4 - Beta,
     *requires*: N/A

     pytest results data-base and HTML reporter

  :pypi:`pytest-odoo`
     *last release*: Nov 17, 2022,
     *status*: 4 - Beta,
     *requires*: pytest (>=7.2.0)

     py.test plugin to run Odoo tests

  :pypi:`pytest-odoo-fixtures`
     *last release*: Jun 25, 2019,
     *status*: N/A,
     *requires*: N/A

     Project description

  :pypi:`pytest-oerp`
     *last release*: Feb 28, 2012,
     *status*: 3 - Alpha,
     *requires*: N/A

     pytest plugin to test OpenERP modules

  :pypi:`pytest-offline`
     *last release*: Mar 09, 2023,
     *status*: 1 - Planning,
     *requires*: pytest (>=7.0.0,<8.0.0)



  :pypi:`pytest-ogsm-plugin`
     *last release*: May 16, 2023,
     *status*: N/A,
     *requires*: N/A

     针对特定项目定制化插件，优化了pytest报告展示方式,并添加了项目所需特定参数

  :pypi:`pytest-ok`
     *last release*: Apr 01, 2019,
     *status*: 4 - Beta,
     *requires*: N/A

     The ultimate pytest output plugin

  :pypi:`pytest-only`
     *last release*: Jun 14, 2022,
     *status*: 5 - Production/Stable,
     *requires*: pytest (<7.1); python_version <= "3.6"

     Use @pytest.mark.only to run a single test

  :pypi:`pytest-oot`
     *last release*: Sep 18, 2016,
     *status*: 4 - Beta,
     *requires*: N/A

     Run object-oriented tests in a simple format

  :pypi:`pytest-openfiles`
     *last release*: Apr 16, 2020,
     *status*: 3 - Alpha,
     *requires*: pytest (>=4.6)

     Pytest plugin for detecting inadvertent open file handles

  :pypi:`pytest-opentelemetry`
     *last release*: Mar 15, 2023,
     *status*: N/A,
     *requires*: pytest

     A pytest plugin for instrumenting test runs via OpenTelemetry

  :pypi:`pytest-opentmi`
     *last release*: Jun 02, 2022,
     *status*: 5 - Production/Stable,
     *requires*: pytest (>=5.0)

     pytest plugin for publish results to opentmi

  :pypi:`pytest-operator`
     *last release*: Sep 28, 2022,
     *status*: N/A,
     *requires*: pytest

     Fixtures for Operators

  :pypi:`pytest-optional`
     *last release*: Oct 07, 2015,
     *status*: N/A,
     *requires*: N/A

     include/exclude values of fixtures in pytest

  :pypi:`pytest-optional-tests`
     *last release*: Jul 09, 2019,
     *status*: 4 - Beta,
     *requires*: pytest (>=4.5.0)

     Easy declaration of optional tests (i.e., that are not run by default)

  :pypi:`pytest-orchestration`
     *last release*: Jul 18, 2019,
     *status*: N/A,
     *requires*: N/A

     A pytest plugin for orchestrating tests

  :pypi:`pytest-order`
     *last release*: Mar 10, 2023,
     *status*: 4 - Beta,
     *requires*: pytest (>=5.0) ; python_version < "3.10"

     pytest plugin to run your tests in a specific order

  :pypi:`pytest-ordering`
     *last release*: Nov 14, 2018,
     *status*: 4 - Beta,
     *requires*: pytest

     pytest plugin to run your tests in a specific order

  :pypi:`pytest-order-modify`
     *last release*: Nov 04, 2022,
     *status*: N/A,
     *requires*: N/A

     新增run_marker 来自定义用例的执行顺序

  :pypi:`pytest-osxnotify`
     *last release*: May 15, 2015,
     *status*: N/A,
     *requires*: N/A

     OS X notifications for py.test results.

  :pypi:`pytest-otel`
     *last release*: Jan 18, 2023,
     *status*: N/A,
     *requires*: N/A

     pytest-otel report OpenTelemetry traces about test executed

  :pypi:`pytest-override-env-var`
     *last release*: Feb 25, 2023,
     *status*: N/A,
     *requires*: N/A

     Pytest mark to override a value of an environment variable.

  :pypi:`pytest-owner`
     *last release*: Apr 25, 2022,
     *status*: N/A,
     *requires*: N/A

     Add owner mark for tests

  :pypi:`pytest-pact`
     *last release*: Jan 07, 2019,
     *status*: 4 - Beta,
     *requires*: N/A

     A simple plugin to use with pytest

  :pypi:`pytest-pahrametahrize`
     *last release*: Nov 24, 2021,
     *status*: 4 - Beta,
     *requires*: pytest (>=6.0,<7.0)

     Parametrize your tests with a Boston accent.

  :pypi:`pytest-parallel`
     *last release*: Oct 10, 2021,
     *status*: 3 - Alpha,
     *requires*: pytest (>=3.0.0)

     a pytest plugin for parallel and concurrent testing

  :pypi:`pytest-parallel-39`
     *last release*: Jul 12, 2021,
     *status*: 3 - Alpha,
     *requires*: pytest (>=3.0.0)

     a pytest plugin for parallel and concurrent testing

  :pypi:`pytest-parallelize-tests`
     *last release*: Jan 27, 2023,
     *status*: 4 - Beta,
     *requires*: N/A

     pytest plugin that parallelizes test execution across multiple hosts

  :pypi:`pytest-param`
     *last release*: Sep 11, 2016,
     *status*: 4 - Beta,
     *requires*: pytest (>=2.6.0)

     pytest plugin to test all, first, last or random params

  :pypi:`pytest-paramark`
     *last release*: Jan 10, 2020,
     *status*: 4 - Beta,
     *requires*: pytest (>=4.5.0)

     Configure pytest fixtures using a combination of"parametrize" and markers

  :pypi:`pytest-parametrization`
     *last release*: May 22, 2022,
     *status*: 5 - Production/Stable,
     *requires*: N/A

     Simpler PyTest parametrization

  :pypi:`pytest-parametrize-cases`
     *last release*: Mar 13, 2022,
     *status*: N/A,
     *requires*: pytest (>=6.1.2)

     A more user-friendly way to write parametrized tests.

  :pypi:`pytest-parametrized`
     *last release*: Sep 13, 2022,
     *status*: 5 - Production/Stable,
     *requires*: pytest

     Pytest decorator for parametrizing tests with default iterables.

  :pypi:`pytest-parametrize-suite`
     *last release*: Jan 19, 2023,
     *status*: 5 - Production/Stable,
     *requires*: pytest

     A simple pytest extension for creating a named test suite.

  :pypi:`pytest-parawtf`
     *last release*: Dec 03, 2018,
     *status*: 4 - Beta,
     *requires*: pytest (>=3.6.0)

     Finally spell paramete?ri[sz]e correctly

  :pypi:`pytest-pass`
     *last release*: Dec 04, 2019,
     *status*: N/A,
     *requires*: N/A

     Check out https://github.com/elilutsky/pytest-pass

  :pypi:`pytest-passrunner`
     *last release*: Feb 10, 2021,
     *status*: 5 - Production/Stable,
     *requires*: pytest (>=4.6.0)

     Pytest plugin providing the 'run_on_pass' marker

  :pypi:`pytest-paste-config`
     *last release*: Sep 18, 2013,
     *status*: 3 - Alpha,
     *requires*: N/A

     Allow setting the path to a paste config file

  :pypi:`pytest-patch`
     *last release*: Apr 29, 2023,
     *status*: 3 - Alpha,
     *requires*: pytest (>=7.0.0)

     An automagic \`patch\` fixture that can patch objects directly or by name.

  :pypi:`pytest-patches`
     *last release*: Aug 30, 2021,
     *status*: 4 - Beta,
     *requires*: pytest (>=3.5.0)

     A contextmanager pytest fixture for handling multiple mock patches

  :pypi:`pytest-pdb`
     *last release*: Jul 31, 2018,
     *status*: N/A,
     *requires*: N/A

     pytest plugin which adds pdb helper commands related to pytest.

  :pypi:`pytest-peach`
     *last release*: Apr 12, 2019,
     *status*: 4 - Beta,
     *requires*: pytest (>=2.8.7)

     pytest plugin for fuzzing with Peach API Security

  :pypi:`pytest-pep257`
     *last release*: Jul 09, 2016,
     *status*: N/A,
     *requires*: N/A

     py.test plugin for pep257

  :pypi:`pytest-pep8`
     *last release*: Apr 27, 2014,
     *status*: N/A,
     *requires*: N/A

     pytest plugin to check PEP8 requirements

  :pypi:`pytest-percent`
     *last release*: May 21, 2020,
     *status*: N/A,
     *requires*: pytest (>=5.2.0)

     Change the exit code of pytest test sessions when a required percent of tests pass.

  :pypi:`pytest-perf`
     *last release*: Jun 02, 2023,
     *status*: 5 - Production/Stable,
     *requires*: pytest (>=6) ; extra == 'testing'

     Run performance tests against the mainline code.

  :pypi:`pytest-performance`
     *last release*: Sep 11, 2020,
     *status*: 5 - Production/Stable,
     *requires*: pytest (>=3.7.0)

     A simple plugin to ensure the execution of critical sections of code has not been impacted

  :pypi:`pytest-persistence`
     *last release*: Jun 14, 2023,
     *status*: N/A,
     *requires*: N/A

     Pytest tool for persistent objects

  :pypi:`pytest-pg`
     *last release*: May 04, 2023,
     *status*: 5 - Production/Stable,
     *requires*: pytest (>=6.0.0)

     A tiny plugin for pytest which runs PostgreSQL in Docker

  :pypi:`pytest-pgsql`
     *last release*: May 13, 2020,
     *status*: 5 - Production/Stable,
     *requires*: pytest (>=3.0.0)

     Pytest plugins and helpers for tests using a Postgres database.

  :pypi:`pytest-phmdoctest`
     *last release*: Apr 15, 2022,
     *status*: 4 - Beta,
     *requires*: pytest (>=5.4.3)

     pytest plugin to test Python examples in Markdown using phmdoctest.

  :pypi:`pytest-picked`
     *last release*: Dec 23, 2020,
     *status*: N/A,
     *requires*: pytest (>=3.5.0)

     Run the tests related to the changed files

  :pypi:`pytest-pigeonhole`
     *last release*: Jun 25, 2018,
     *status*: 5 - Production/Stable,
     *requires*: pytest (>=3.4)



  :pypi:`pytest-pikachu`
     *last release*: Aug 05, 2021,
     *status*: 5 - Production/Stable,
     *requires*: pytest

     Show surprise when tests are passing

  :pypi:`pytest-pilot`
     *last release*: Oct 09, 2020,
     *status*: 5 - Production/Stable,
     *requires*: N/A

     Slice in your test base thanks to powerful markers.

  :pypi:`pytest-pingguo-pytest-plugin`
     *last release*: Oct 26, 2022,
     *status*: 4 - Beta,
     *requires*: N/A

     pingguo test

  :pypi:`pytest-pings`
     *last release*: Jun 29, 2019,
     *status*: 3 - Alpha,
     *requires*: pytest (>=5.0.0)

     🦊 The pytest plugin for Firefox Telemetry 📊

  :pypi:`pytest-pinned`
     *last release*: Sep 17, 2021,
     *status*: 4 - Beta,
     *requires*: pytest (>=3.5.0)

     A simple pytest plugin for pinning tests

  :pypi:`pytest-pinpoint`
     *last release*: Sep 25, 2020,
     *status*: N/A,
     *requires*: pytest (>=4.4.0)

     A pytest plugin which runs SBFL algorithms to detect faults.

  :pypi:`pytest-pipeline`
     *last release*: Jan 24, 2017,
     *status*: 3 - Alpha,
     *requires*: N/A

     Pytest plugin for functional testing of data analysispipelines

  :pypi:`pytest-platform-markers`
     *last release*: Sep 09, 2019,
     *status*: 4 - Beta,
     *requires*: pytest (>=3.6.0)

     Markers for pytest to skip tests on specific platforms

  :pypi:`pytest-play`
     *last release*: Jun 12, 2019,
     *status*: 5 - Production/Stable,
     *requires*: N/A

     pytest plugin that let you automate actions and assertions with test metrics reporting executing plain YAML files

  :pypi:`pytest-playbook`
     *last release*: Jan 21, 2021,
     *status*: 3 - Alpha,
     *requires*: pytest (>=6.1.2,<7.0.0)

     Pytest plugin for reading playbooks.

  :pypi:`pytest-playwright`
     *last release*: Apr 24, 2023,
     *status*: N/A,
     *requires*: pytest (<8.0.0,>=6.2.4)

     A pytest wrapper with fixtures for Playwright to automate web browsers

  :pypi:`pytest-playwright-async`
     *last release*: Jun 26, 2023,
     *status*: N/A,
     *requires*: N/A

     ASYNC Pytest plugin for Playwright

  :pypi:`pytest-playwrights`
     *last release*: Dec 02, 2021,
     *status*: N/A,
     *requires*: N/A

     A pytest wrapper with fixtures for Playwright to automate web browsers

  :pypi:`pytest-playwright-snapshot`
     *last release*: Aug 19, 2021,
     *status*: N/A,
     *requires*: N/A

     A pytest wrapper for snapshot testing with playwright

  :pypi:`pytest-playwright-visual`
     *last release*: Apr 28, 2022,
     *status*: N/A,
     *requires*: N/A

     A pytest fixture for visual testing with Playwright

  :pypi:`pytest-plone`
     *last release*: Jan 05, 2023,
     *status*: 3 - Alpha,
     *requires*: pytest

     Pytest plugin to test Plone addons

  :pypi:`pytest-plt`
     *last release*: Aug 17, 2020,
     *status*: 5 - Production/Stable,
     *requires*: pytest

     Fixtures for quickly making Matplotlib plots in tests

  :pypi:`pytest-plugin-helpers`
     *last release*: Nov 23, 2019,
     *status*: 4 - Beta,
     *requires*: pytest (>=3.5.0)

     A plugin to help developing and testing other plugins

  :pypi:`pytest-plus`
     *last release*: Dec 24, 2022,
     *status*: 5 - Production/Stable,
     *requires*: pytest (>=6.0.1)

     PyTest Plus Plugin :: extends pytest functionality

  :pypi:`pytest-pmisc`
     *last release*: Mar 21, 2019,
     *status*: 5 - Production/Stable,
     *requires*: N/A



  :pypi:`pytest-pointers`
     *last release*: Dec 26, 2022,
     *status*: N/A,
     *requires*: N/A

     Pytest plugin to define functions you test with special marks for better navigation and reports

  :pypi:`pytest-pokie`
     *last release*: May 22, 2023,
     *status*: 5 - Production/Stable,
     *requires*: N/A

     Pokie plugin for pytest

  :pypi:`pytest-polarion-cfme`
     *last release*: Nov 13, 2017,
     *status*: 3 - Alpha,
     *requires*: N/A

     pytest plugin for collecting test cases and recording test results

  :pypi:`pytest-polarion-collect`
     *last release*: Jun 18, 2020,
     *status*: 3 - Alpha,
     *requires*: pytest

     pytest plugin for collecting polarion test cases data

  :pypi:`pytest-polecat`
     *last release*: Aug 12, 2019,
     *status*: 4 - Beta,
     *requires*: N/A

     Provides Polecat pytest fixtures

  :pypi:`pytest-ponyorm`
     *last release*: Oct 31, 2018,
     *status*: N/A,
     *requires*: pytest (>=3.1.1)

     PonyORM in Pytest

  :pypi:`pytest-poo`
     *last release*: Mar 25, 2021,
     *status*: 5 - Production/Stable,
     *requires*: pytest (>=2.3.4)

     Visualize your crappy tests

  :pypi:`pytest-poo-fail`
     *last release*: Feb 12, 2015,
     *status*: 5 - Production/Stable,
     *requires*: N/A

     Visualize your failed tests with poo

  :pypi:`pytest-pop`
     *last release*: May 09, 2023,
     *status*: 5 - Production/Stable,
     *requires*: pytest

     A pytest plugin to help with testing pop projects

  :pypi:`pytest-porringer`
     *last release*: Jun 24, 2023,
     *status*: N/A,
     *requires*: pytest>=7.1.2



  :pypi:`pytest-portion`
     *last release*: Jan 28, 2021,
     *status*: 4 - Beta,
     *requires*: pytest (>=3.5.0)

     Select a portion of the collected tests

  :pypi:`pytest-postgres`
     *last release*: Mar 22, 2020,
     *status*: N/A,
     *requires*: pytest

     Run PostgreSQL in Docker container in Pytest.

  :pypi:`pytest-postgresql`
     *last release*: May 20, 2023,
     *status*: 5 - Production/Stable,
     *requires*: pytest (>=6.2)

     Postgresql fixtures and fixture factories for Pytest.

  :pypi:`pytest-pot`
     *last release*: Nov 20, 2022,
     *status*: N/A,
     *requires*: N/A

     A package for enhancing pytest

  :pypi:`pytest-power`
     *last release*: Dec 31, 2020,
     *status*: N/A,
     *requires*: pytest (>=5.4)

     pytest plugin with powerful fixtures

  :pypi:`pytest-prefer-nested-dup-tests`
     *last release*: Apr 27, 2022,
     *status*: 4 - Beta,
     *requires*: pytest (>=7.1.1,<8.0.0)

     A Pytest plugin to drop duplicated tests during collection, but will prefer keeping nested packages.

  :pypi:`pytest-pretty`
     *last release*: Apr 05, 2023,
     *status*: 5 - Production/Stable,
     *requires*: pytest>=7

     pytest plugin for printing summary data as I want it

  :pypi:`pytest-pretty-terminal`
     *last release*: Jan 31, 2022,
     *status*: N/A,
     *requires*: pytest (>=3.4.1)

     pytest plugin for generating prettier terminal output

  :pypi:`pytest-pride`
     *last release*: Apr 02, 2016,
     *status*: 3 - Alpha,
     *requires*: N/A

     Minitest-style test colors

  :pypi:`pytest-print`
     *last release*: Jun 28, 2023,
     *status*: 5 - Production/Stable,
     *requires*: pytest>=7.3.2

     pytest-print adds the printer fixture you can use to print messages to the user (directly to the pytest runner, not stdout)

  :pypi:`pytest-profiles`
     *last release*: Dec 09, 2021,
     *status*: 4 - Beta,
     *requires*: pytest (>=3.7.0)

     pytest plugin for configuration profiles

  :pypi:`pytest-profiling`
     *last release*: May 28, 2019,
     *status*: 5 - Production/Stable,
     *requires*: pytest

     Profiling plugin for py.test

  :pypi:`pytest-progress`
     *last release*: Jan 31, 2022,
     *status*: 5 - Production/Stable,
     *requires*: N/A

     pytest plugin for instant test progress status

  :pypi:`pytest-prometheus`
     *last release*: Oct 03, 2017,
     *status*: N/A,
     *requires*: N/A

     Report test pass / failures to a Prometheus PushGateway

  :pypi:`pytest-prometheus-pushgateway`
     *last release*: Sep 27, 2022,
     *status*: 5 - Production/Stable,
     *requires*: pytest

     Pytest report plugin for Zulip

  :pypi:`pytest-prosper`
     *last release*: Sep 24, 2018,
     *status*: N/A,
     *requires*: N/A

     Test helpers for Prosper projects

  :pypi:`pytest-pspec`
     *last release*: Jun 02, 2020,
     *status*: 4 - Beta,
     *requires*: pytest (>=3.0.0)

     A rspec format reporter for Python ptest

  :pypi:`pytest-psqlgraph`
     *last release*: Oct 19, 2021,
     *status*: 4 - Beta,
     *requires*: pytest (>=6.0)

     pytest plugin for testing applications that use psqlgraph

  :pypi:`pytest-ptera`
     *last release*: Mar 01, 2022,
     *status*: N/A,
     *requires*: pytest (>=6.2.4,<7.0.0)

     Use ptera probes in tests

  :pypi:`pytest-pudb`
     *last release*: Oct 25, 2018,
     *status*: 3 - Alpha,
     *requires*: pytest (>=2.0)

     Pytest PuDB debugger integration

  :pypi:`pytest-pumpkin-spice`
     *last release*: Sep 18, 2022,
     *status*: 4 - Beta,
     *requires*: N/A

     A pytest plugin that makes your test reporting pumpkin-spiced

  :pypi:`pytest-purkinje`
     *last release*: Oct 28, 2017,
     *status*: 2 - Pre-Alpha,
     *requires*: N/A

     py.test plugin for purkinje test runner

  :pypi:`pytest-pusher`
     *last release*: Jan 06, 2023,
     *status*: 5 - Production/Stable,
     *requires*: pytest (>=3.6)

     pytest plugin for push report to minio

  :pypi:`pytest-py125`
     *last release*: Dec 03, 2022,
     *status*: N/A,
     *requires*: N/A



  :pypi:`pytest-pycharm`
     *last release*: Aug 13, 2020,
     *status*: 5 - Production/Stable,
     *requires*: pytest (>=2.3)

     Plugin for py.test to enter PyCharm debugger on uncaught exceptions

  :pypi:`pytest-pycodestyle`
     *last release*: Oct 28, 2022,
     *status*: 3 - Alpha,
     *requires*: N/A

     pytest plugin to run pycodestyle

  :pypi:`pytest-pydev`
     *last release*: Nov 15, 2017,
     *status*: 3 - Alpha,
     *requires*: N/A

     py.test plugin to connect to a remote debug server with PyDev or PyCharm.

  :pypi:`pytest-pydocstyle`
     *last release*: Jan 05, 2023,
     *status*: 3 - Alpha,
     *requires*: N/A

     pytest plugin to run pydocstyle

  :pypi:`pytest-pylint`
     *last release*: Sep 10, 2022,
     *status*: 5 - Production/Stable,
     *requires*: pytest (>=5.4)

     pytest plugin to check source code with pylint

  :pypi:`pytest-pymysql-autorecord`
     *last release*: Sep 02, 2022,
     *status*: N/A,
     *requires*: N/A

     Record PyMySQL queries and mock with the stored data.

  :pypi:`pytest-pyodide`
     *last release*: Jun 19, 2023,
     *status*: N/A,
     *requires*: pytest

     "Pytest plugin for testing applications that use Pyodide"

  :pypi:`pytest-pypi`
     *last release*: Mar 04, 2018,
     *status*: 3 - Alpha,
     *requires*: N/A

     Easily test your HTTP library against a local copy of pypi

  :pypi:`pytest-pypom-navigation`
     *last release*: Feb 18, 2019,
     *status*: 4 - Beta,
     *requires*: pytest (>=3.0.7)

     Core engine for cookiecutter-qa and pytest-play packages

  :pypi:`pytest-pyppeteer`
     *last release*: Apr 28, 2022,
     *status*: N/A,
     *requires*: pytest (>=6.2.5,<7.0.0)

     A plugin to run pyppeteer in pytest

  :pypi:`pytest-pyq`
     *last release*: Mar 10, 2020,
     *status*: 5 - Production/Stable,
     *requires*: N/A

     Pytest fixture "q" for pyq

  :pypi:`pytest-pyramid`
     *last release*: Dec 13, 2022,
     *status*: 5 - Production/Stable,
     *requires*: pytest

     pytest_pyramid - provides fixtures for testing pyramid applications with pytest test suite

  :pypi:`pytest-pyramid-server`
     *last release*: May 28, 2019,
     *status*: 5 - Production/Stable,
     *requires*: pytest

     Pyramid server fixture for py.test

  :pypi:`pytest-pyreport`
     *last release*: May 08, 2023,
     *status*: N/A,
     *requires*: pytest (>=7.3.1)

     PyReport is a lightweight reporting plugin for Pytest that provides concise HTML report

  :pypi:`pytest-pyright`
     *last release*: Nov 20, 2022,
     *status*: 4 - Beta,
     *requires*: pytest (>=7.0.0)

     Pytest plugin for type checking code with Pyright

  :pypi:`pytest-pyspec`
     *last release*: Mar 12, 2023,
     *status*: 5 - Production/Stable,
     *requires*: pytest (>=7.2.1,<8.0.0)

     A plugin that transforms the pytest output into a result similar to the RSpec. It enables the use of docstrings to display results and also enables the use of the prefixes "describe", "with" and "it".

  :pypi:`pytest-pystack`
     *last release*: May 07, 2023,
     *status*: N/A,
     *requires*: pytest (>=3.5.0)

     Plugin to run pystack after a timeout for a test suite.

  :pypi:`pytest-pytestrail`
     *last release*: Aug 27, 2020,
     *status*: 4 - Beta,
     *requires*: pytest (>=3.8.0)

     Pytest plugin for interaction with TestRail

  :pypi:`pytest-pythonpath`
     *last release*: Feb 10, 2022,
     *status*: 5 - Production/Stable,
     *requires*: pytest (<7,>=2.5.2)

     pytest plugin for adding to the PYTHONPATH from command line or configs.

  :pypi:`pytest-pytorch`
     *last release*: May 25, 2021,
     *status*: 4 - Beta,
     *requires*: pytest

     pytest plugin for a better developer experience when working with the PyTorch test suite

  :pypi:`pytest-pyvista`
     *last release*: Mar 19, 2023,
     *status*: 4 - Beta,
     *requires*: pytest>=3.5.0

     Pytest-pyvista package

  :pypi:`pytest-qaseio`
     *last release*: May 11, 2023,
     *status*: 4 - Beta,
     *requires*: pytest (>=7.2.2,<8.0.0)

     Pytest plugin for Qase.io integration

  :pypi:`pytest-qasync`
     *last release*: Jul 12, 2021,
     *status*: 4 - Beta,
     *requires*: pytest (>=5.4.0)

     Pytest support for qasync.

  :pypi:`pytest-qatouch`
     *last release*: Feb 14, 2023,
     *status*: 4 - Beta,
     *requires*: pytest (>=6.2.0)

     Pytest plugin for uploading test results to your QA Touch Testrun.

  :pypi:`pytest-qgis`
     *last release*: Jun 30, 2023,
     *status*: 5 - Production/Stable,
     *requires*: pytest (>=6.2.5)

     A pytest plugin for testing QGIS python plugins

  :pypi:`pytest-qml`
     *last release*: Dec 02, 2020,
     *status*: 4 - Beta,
     *requires*: pytest (>=6.0.0)

     Run QML Tests with pytest

  :pypi:`pytest-qr`
     *last release*: Nov 25, 2021,
     *status*: 4 - Beta,
     *requires*: N/A

     pytest plugin to generate test result QR codes

  :pypi:`pytest-qt`
     *last release*: Oct 25, 2022,
     *status*: 5 - Production/Stable,
     *requires*: pytest (>=3.0.0)

     pytest support for PyQt and PySide applications

  :pypi:`pytest-qt-app`
     *last release*: Dec 23, 2015,
     *status*: 5 - Production/Stable,
     *requires*: N/A

     QT app fixture for py.test

  :pypi:`pytest-quarantine`
     *last release*: Nov 24, 2019,
     *status*: 5 - Production/Stable,
     *requires*: pytest (>=4.6)

     A plugin for pytest to manage expected test failures

  :pypi:`pytest-quickcheck`
     *last release*: Nov 05, 2022,
     *status*: 4 - Beta,
     *requires*: pytest (>=4.0)

     pytest plugin to generate random data inspired by QuickCheck

  :pypi:`pytest-rabbitmq`
     *last release*: Jun 16, 2023,
     *status*: 5 - Production/Stable,
     *requires*: pytest (>=6.2)

     RabbitMQ process and client fixtures for pytest

  :pypi:`pytest-race`
     *last release*: Jun 07, 2022,
     *status*: 4 - Beta,
     *requires*: N/A

     Race conditions tester for pytest

  :pypi:`pytest-rage`
     *last release*: Oct 21, 2011,
     *status*: 3 - Alpha,
     *requires*: N/A

     pytest plugin to implement PEP712

  :pypi:`pytest-rail`
     *last release*: May 02, 2022,
     *status*: N/A,
     *requires*: pytest (>=3.6)

     pytest plugin for creating TestRail runs and adding results

  :pypi:`pytest-railflow-testrail-reporter`
     *last release*: Jun 29, 2022,
     *status*: 5 - Production/Stable,
     *requires*: pytest

     Generate json reports along with specified metadata defined in test markers.

  :pypi:`pytest-raises`
     *last release*: Apr 23, 2020,
     *status*: N/A,
     *requires*: pytest (>=3.2.2)

     An implementation of pytest.raises as a pytest.mark fixture

  :pypi:`pytest-raisesregexp`
     *last release*: Dec 18, 2015,
     *status*: N/A,
     *requires*: N/A

     Simple pytest plugin to look for regex in Exceptions

  :pypi:`pytest-raisin`
     *last release*: Feb 06, 2022,
     *status*: N/A,
     *requires*: pytest

     Plugin enabling the use of exception instances with pytest.raises

  :pypi:`pytest-random`
     *last release*: Apr 28, 2013,
     *status*: 3 - Alpha,
     *requires*: N/A

     py.test plugin to randomize tests

  :pypi:`pytest-randomly`
     *last release*: May 11, 2022,
     *status*: 5 - Production/Stable,
     *requires*: pytest

     Pytest plugin to randomly order tests and control random.seed.

  :pypi:`pytest-randomness`
     *last release*: May 30, 2019,
     *status*: 3 - Alpha,
     *requires*: N/A

     Pytest plugin about random seed management

  :pypi:`pytest-random-num`
     *last release*: Oct 19, 2020,
     *status*: 5 - Production/Stable,
     *requires*: N/A

     Randomise the order in which pytest tests are run with some control over the randomness

  :pypi:`pytest-random-order`
     *last release*: Dec 03, 2022,
     *status*: 5 - Production/Stable,
     *requires*: pytest (>=3.0.0)

     Randomise the order in which pytest tests are run with some control over the randomness

  :pypi:`pytest-readme`
     *last release*: Sep 02, 2022,
     *status*: 5 - Production/Stable,
     *requires*: N/A

     Test your README.md file

  :pypi:`pytest-reana`
     *last release*: Dec 13, 2022,
     *status*: 3 - Alpha,
     *requires*: N/A

     Pytest fixtures for REANA.

  :pypi:`pytest-recorder`
     *last release*: Mar 30, 2023,
     *status*: N/A,
     *requires*: N/A

     Pytest plugin, meant to facilitate unit tests writing for tools consumming Web APIs.

  :pypi:`pytest-recording`
     *last release*: Feb 16, 2023,
     *status*: 4 - Beta,
     *requires*: pytest (>=3.5.0)

     A pytest plugin that allows you recording of network interactions via VCR.py

  :pypi:`pytest-recordings`
     *last release*: Aug 13, 2020,
     *status*: N/A,
     *requires*: N/A

     Provides pytest plugins for reporting request/response traffic, screenshots, and more to ReportPortal

  :pypi:`pytest-redis`
     *last release*: Apr 19, 2023,
     *status*: 5 - Production/Stable,
     *requires*: pytest (>=6.2)

     Redis fixtures and fixture factories for Pytest.

  :pypi:`pytest-redislite`
     *last release*: Apr 05, 2022,
     *status*: 4 - Beta,
     *requires*: pytest

     Pytest plugin for testing code using Redis

  :pypi:`pytest-redmine`
     *last release*: Mar 19, 2018,
     *status*: 1 - Planning,
     *requires*: N/A

     Pytest plugin for redmine

  :pypi:`pytest-ref`
     *last release*: Nov 23, 2019,
     *status*: 4 - Beta,
     *requires*: pytest (>=3.5.0)

     A plugin to store reference files to ease regression testing

  :pypi:`pytest-reference-formatter`
     *last release*: Oct 01, 2019,
     *status*: 4 - Beta,
     *requires*: N/A

     Conveniently run pytest with a dot-formatted test reference.

  :pypi:`pytest-regex`
     *last release*: May 29, 2023,
     *status*: 4 - Beta,
     *requires*: pytest (>=3.5.0)

     Select pytest tests with regular expressions

  :pypi:`pytest-regex-dependency`
     *last release*: Jun 12, 2022,
     *status*: N/A,
     *requires*: pytest

     Management of Pytest dependencies via regex patterns

  :pypi:`pytest-regressions`
     *last release*: Jan 13, 2023,
     *status*: 5 - Production/Stable,
     *requires*: pytest (>=6.2.0)

     Easy to use fixtures to write regression tests.

  :pypi:`pytest-regtest`
     *last release*: Jul 08, 2022,
     *status*: N/A,
     *requires*: N/A

     pytest plugin for regression tests

  :pypi:`pytest-relative-order`
     *last release*: May 17, 2021,
     *status*: 4 - Beta,
     *requires*: N/A

     a pytest plugin that sorts tests using "before" and "after" markers

  :pypi:`pytest-relaxed`
     *last release*: May 23, 2023,
     *status*: 5 - Production/Stable,
     *requires*: pytest (>=7)

     Relaxed test discovery/organization for pytest

  :pypi:`pytest-remfiles`
     *last release*: Jul 01, 2019,
     *status*: 5 - Production/Stable,
     *requires*: N/A

     Pytest plugin to create a temporary directory with remote files

  :pypi:`pytest-remotedata`
     *last release*: Dec 12, 2022,
     *status*: 3 - Alpha,
     *requires*: pytest (>=4.6)

     Pytest plugin for controlling remote data access.

  :pypi:`pytest-remote-response`
     *last release*: Apr 26, 2023,
     *status*: 5 - Production/Stable,
     *requires*: pytest (>=4.6)

     Pytest plugin for capturing and mocking connection requests.

  :pypi:`pytest-remove-stale-bytecode`
     *last release*: Mar 04, 2020,
     *status*: 4 - Beta,
     *requires*: pytest

     py.test plugin to remove stale byte code files.

  :pypi:`pytest-reorder`
     *last release*: May 31, 2018,
     *status*: 4 - Beta,
     *requires*: pytest

     Reorder tests depending on their paths and names.

  :pypi:`pytest-repeat`
     *last release*: Oct 31, 2020,
     *status*: 5 - Production/Stable,
     *requires*: pytest (>=3.6)

     pytest plugin for repeating tests

  :pypi:`pytest-replay`
     *last release*: Jun 09, 2021,
     *status*: 4 - Beta,
     *requires*: pytest (>=3.0.0)

     Saves previous test runs and allow re-execute previous pytest runs to reproduce crashes or flaky tests

  :pypi:`pytest-repo-health`
     *last release*: Apr 17, 2023,
     *status*: 3 - Alpha,
     *requires*: pytest

     A pytest plugin to report on repository standards conformance

  :pypi:`pytest-report`
     *last release*: May 11, 2016,
     *status*: 4 - Beta,
     *requires*: N/A

     Creates json report that is compatible with atom.io's linter message format

  :pypi:`pytest-reporter`
     *last release*: Jul 22, 2021,
     *status*: 4 - Beta,
     *requires*: pytest

     Generate Pytest reports with templates

  :pypi:`pytest-reporter-html1`
     *last release*: Jun 05, 2023,
     *status*: 4 - Beta,
     *requires*: N/A

     A basic HTML report template for Pytest

  :pypi:`pytest-reporter-html-dots`
     *last release*: Jan 22, 2023,
     *status*: N/A,
     *requires*: N/A

     A basic HTML report for pytest using Jinja2 template engine.

  :pypi:`pytest-reportinfra`
     *last release*: Aug 11, 2019,
     *status*: 3 - Alpha,
     *requires*: N/A

     Pytest plugin for reportinfra

  :pypi:`pytest-reporting`
     *last release*: Oct 25, 2019,
     *status*: 4 - Beta,
     *requires*: pytest (>=3.5.0)

     A plugin to report summarized results in a table format

  :pypi:`pytest-reportlog`
     *last release*: May 22, 2023,
     *status*: 3 - Alpha,
     *requires*: pytest

     Replacement for the --resultlog option, focused in simplicity and extensibility

  :pypi:`pytest-report-me`
     *last release*: Dec 31, 2020,
     *status*: N/A,
     *requires*: pytest

     A pytest plugin to generate report.

  :pypi:`pytest-report-parameters`
     *last release*: Jun 18, 2020,
     *status*: 3 - Alpha,
     *requires*: pytest (>=2.4.2)

     pytest plugin for adding tests' parameters to junit report

  :pypi:`pytest-reportportal`
     *last release*: Jun 30, 2023,
     *status*: N/A,
     *requires*: pytest (>=3.8.0)

     Agent for Reporting results of tests to the Report Portal

  :pypi:`pytest-reports`
     *last release*: Jun 07, 2023,
     *status*: N/A,
     *requires*: N/A

     An interesting python package

  :pypi:`pytest-reqs`
     *last release*: May 12, 2019,
     *status*: N/A,
     *requires*: pytest (>=2.4.2)

     pytest plugin to check pinned requirements

  :pypi:`pytest-requests`
     *last release*: Jun 24, 2019,
     *status*: 4 - Beta,
     *requires*: pytest (>=3.5.0)

     A simple plugin to use with pytest

  :pypi:`pytest-requestselapsed`
     *last release*: Aug 14, 2022,
     *status*: N/A,
     *requires*: N/A

     collect and show http requests elapsed time

  :pypi:`pytest-requests-futures`
     *last release*: Jul 06, 2022,
     *status*: 5 - Production/Stable,
     *requires*: pytest

     Pytest Plugin to Mock Requests Futures

  :pypi:`pytest-requires`
     *last release*: Dec 21, 2021,
     *status*: 4 - Beta,
     *requires*: pytest (>=3.5.0)

     A pytest plugin to elegantly skip tests with optional requirements

  :pypi:`pytest-reraise`
     *last release*: Sep 20, 2022,
     *status*: 5 - Production/Stable,
     *requires*: pytest (>=4.6)

     Make multi-threaded pytest test cases fail when they should

  :pypi:`pytest-rerun`
     *last release*: Jul 08, 2019,
     *status*: N/A,
     *requires*: pytest (>=3.6)

     Re-run only changed files in specified branch

  :pypi:`pytest-rerunfailures`
     *last release*: Mar 09, 2023,
     *status*: 5 - Production/Stable,
     *requires*: pytest (>=5.3)

     pytest plugin to re-run tests to eliminate flaky failures

  :pypi:`pytest-rerunfailures-all-logs`
     *last release*: Mar 07, 2022,
     *status*: 5 - Production/Stable,
     *requires*: N/A

     pytest plugin to re-run tests to eliminate flaky failures

  :pypi:`pytest-reserial`
     *last release*: Apr 26, 2023,
     *status*: 4 - Beta,
     *requires*: pytest

     Pytest fixture for recording and replaying serial port traffic.

  :pypi:`pytest-resilient-circuits`
     *last release*: Jun 01, 2023,
     *status*: N/A,
     *requires*: pytest (~=4.6) ; python_version == "2.7"

     Resilient Circuits fixtures for PyTest

  :pypi:`pytest-resource`
     *last release*: Nov 14, 2018,
     *status*: 4 - Beta,
     *requires*: N/A

     Load resource fixture plugin to use with pytest

  :pypi:`pytest-resource-path`
     *last release*: May 01, 2021,
     *status*: 5 - Production/Stable,
     *requires*: pytest (>=3.5.0)

     Provides path for uniform access to test resources in isolated directory

  :pypi:`pytest-resource-usage`
     *last release*: Nov 06, 2022,
     *status*: 5 - Production/Stable,
     *requires*: pytest>=7.0.0

     Pytest plugin for reporting running time and peak memory usage

  :pypi:`pytest-responsemock`
     *last release*: Mar 10, 2022,
     *status*: 5 - Production/Stable,
     *requires*: N/A

     Simplified requests calls mocking for pytest

  :pypi:`pytest-responses`
     *last release*: Oct 11, 2022,
     *status*: N/A,
     *requires*: pytest (>=2.5)

     py.test integration for responses

  :pypi:`pytest-rest-api`
     *last release*: Aug 08, 2022,
     *status*: N/A,
     *requires*: pytest (>=7.1.2,<8.0.0)



  :pypi:`pytest-restrict`
     *last release*: Jun 16, 2023,
     *status*: 5 - Production/Stable,
     *requires*: pytest

     Pytest plugin to restrict the test types allowed

  :pypi:`pytest-result-log`
     *last release*: Apr 17, 2023,
     *status*: N/A,
     *requires*: pytest>=7.2.0

     Write the execution result of the case to the log

  :pypi:`pytest-result-sender`
     *last release*: Apr 20, 2023,
     *status*: N/A,
     *requires*: pytest>=7.3.1



  :pypi:`pytest-resume`
     *last release*: Apr 22, 2023,
     *status*: 4 - Beta,
     *requires*: pytest (>=7.0)

     A Pytest plugin to resuming from the last run test

  :pypi:`pytest-rethinkdb`
     *last release*: Jul 24, 2016,
     *status*: 4 - Beta,
     *requires*: N/A

     A RethinkDB plugin for pytest.

  :pypi:`pytest-retry`
     *last release*: Aug 16, 2022,
     *status*: N/A,
     *requires*: pytest (>=7.0.0)

     Adds the ability to retry flaky tests in CI environments

  :pypi:`pytest-retry-class`
     *last release*: Mar 25, 2023,
     *status*: N/A,
     *requires*: pytest (>=5.3)

     A pytest plugin to rerun entire class on failure

  :pypi:`pytest-reusable-testcases`
     *last release*: Apr 28, 2023,
     *status*: N/A,
     *requires*: N/A



  :pypi:`pytest-reverse`
     *last release*: Jun 16, 2023,
     *status*: 5 - Production/Stable,
     *requires*: pytest

     Pytest plugin to reverse test order.

  :pypi:`pytest-rich`
     *last release*: Mar 03, 2022,
     *status*: 4 - Beta,
     *requires*: pytest (>=7.0)

     Leverage rich for richer test session output

  :pypi:`pytest-rich-reporter`
     *last release*: Feb 17, 2022,
     *status*: 1 - Planning,
     *requires*: pytest (>=5.0.0)

     A pytest plugin using Rich for beautiful test result formatting.

  :pypi:`pytest-richtrace`
     *last release*: Jun 20, 2023,
     *status*: N/A,
     *requires*: N/A

     A pytest plugin that displays the names and information of the pytest hook functions as they are executed.

  :pypi:`pytest-ringo`
     *last release*: Sep 27, 2017,
     *status*: 3 - Alpha,
     *requires*: N/A

     pytest plugin to test webapplications using the Ringo webframework

  :pypi:`pytest-rmsis`
     *last release*: Aug 10, 2022,
     *status*: N/A,
     *requires*: pytest (>=5.3.5)

     Sycronise pytest results to Jira RMsis

  :pypi:`pytest-rng`
     *last release*: Aug 08, 2019,
     *status*: 5 - Production/Stable,
     *requires*: pytest

     Fixtures for seeding tests and making randomness reproducible

  :pypi:`pytest-roast`
     *last release*: Nov 09, 2022,
     *status*: 5 - Production/Stable,
     *requires*: pytest

     pytest plugin for ROAST configuration override and fixtures

  :pypi:`pytest-rocketchat`
     *last release*: Apr 18, 2021,
     *status*: 5 - Production/Stable,
     *requires*: N/A

     Pytest to Rocket.Chat reporting plugin

  :pypi:`pytest-rotest`
     *last release*: Sep 08, 2019,
     *status*: N/A,
     *requires*: pytest (>=3.5.0)

     Pytest integration with rotest

  :pypi:`pytest-rpc`
     *last release*: Feb 22, 2019,
     *status*: 4 - Beta,
     *requires*: pytest (~=3.6)

     Extend py.test for RPC OpenStack testing.

  :pypi:`pytest-rst`
     *last release*: Jan 26, 2023,
     *status*: N/A,
     *requires*: N/A

     Test code from RST documents with pytest

  :pypi:`pytest-rt`
     *last release*: May 05, 2022,
     *status*: N/A,
     *requires*: N/A

     pytest data collector plugin for Testgr

  :pypi:`pytest-rts`
     *last release*: May 17, 2021,
     *status*: N/A,
     *requires*: pytest

     Coverage-based regression test selection (RTS) plugin for pytest

  :pypi:`pytest-ruff`
     *last release*: Jun 08, 2023,
     *status*: 4 - Beta,
     *requires*: N/A

     pytest plugin to check ruff requirements.

  :pypi:`pytest-run-changed`
     *last release*: Apr 02, 2021,
     *status*: 3 - Alpha,
     *requires*: pytest

     Pytest plugin that runs changed tests only

  :pypi:`pytest-runfailed`
     *last release*: Mar 24, 2016,
     *status*: N/A,
     *requires*: N/A

     implement a --failed option for pytest

  :pypi:`pytest-runner`
     *last release*: Feb 25, 2022,
     *status*: 5 - Production/Stable,
     *requires*: pytest (>=6) ; extra == 'testing'

     Invoke py.test as distutils command with dependency resolution

  :pypi:`pytest-run-subprocess`
     *last release*: Nov 12, 2022,
     *status*: 5 - Production/Stable,
     *requires*: pytest

     Pytest Plugin for running and testing subprocesses.

  :pypi:`pytest-runtime-types`
     *last release*: Feb 09, 2023,
     *status*: N/A,
     *requires*: pytest

     Checks type annotations on runtime while running tests.

  :pypi:`pytest-runtime-xfail`
     *last release*: Aug 26, 2021,
     *status*: N/A,
     *requires*: pytest>=5.0.0

     Call runtime_xfail() to mark running test as xfail.

  :pypi:`pytest-runtime-yoyo`
     *last release*: Jun 12, 2023,
     *status*: N/A,
     *requires*: pytest (>=7.2.0)

     run case mark timeout

  :pypi:`pytest-ry-demo1`
     *last release*: Mar 26, 2023,
     *status*: N/A,
     *requires*: N/A

     测试

  :pypi:`pytest-saccharin`
     *last release*: Oct 31, 2022,
     *status*: 3 - Alpha,
     *requires*: N/A

     pytest-saccharin is a updated fork of pytest-sugar, a plugin for pytest that changes the default look and feel of pytest (e.g. progressbar, show tests that fail instantly).

  :pypi:`pytest-salt`
     *last release*: Jan 27, 2020,
     *status*: 4 - Beta,
     *requires*: N/A

     Pytest Salt Plugin

  :pypi:`pytest-salt-containers`
     *last release*: Nov 09, 2016,
     *status*: 4 - Beta,
     *requires*: N/A

     A Pytest plugin that builds and creates docker containers

  :pypi:`pytest-salt-factories`
     *last release*: Dec 15, 2022,
     *status*: 4 - Beta,
     *requires*: pytest (>=6.0.0)

     Pytest Salt Plugin

  :pypi:`pytest-salt-from-filenames`
     *last release*: Jan 29, 2019,
     *status*: 4 - Beta,
     *requires*: pytest (>=4.1)

     Simple PyTest Plugin For Salt's Test Suite Specifically

  :pypi:`pytest-salt-runtests-bridge`
     *last release*: Dec 05, 2019,
     *status*: 4 - Beta,
     *requires*: pytest (>=4.1)

     Simple PyTest Plugin For Salt's Test Suite Specifically

  :pypi:`pytest-sanic`
     *last release*: Oct 25, 2021,
     *status*: N/A,
     *requires*: pytest (>=5.2)

     a pytest plugin for Sanic

  :pypi:`pytest-sanity`
     *last release*: Dec 07, 2020,
     *status*: N/A,
     *requires*: N/A



  :pypi:`pytest-sa-pg`
     *last release*: May 14, 2019,
     *status*: N/A,
     *requires*: N/A



  :pypi:`pytest-sbase`
     *last release*: Jun 30, 2023,
     *status*: 5 - Production/Stable,
     *requires*: N/A

     A complete web automation framework for end-to-end testing.

  :pypi:`pytest-scenario`
     *last release*: Feb 06, 2017,
     *status*: 3 - Alpha,
     *requires*: N/A

     pytest plugin for test scenarios

  :pypi:`pytest-schedule`
     *last release*: Jan 07, 2023,
     *status*: 5 - Production/Stable,
     *requires*: N/A

     The job of test scheduling for humans.

  :pypi:`pytest-schema`
     *last release*: Mar 14, 2022,
     *status*: 5 - Production/Stable,
     *requires*: pytest (>=3.5.0)

     👍 Validate return values against a schema-like object in testing

  :pypi:`pytest-securestore`
     *last release*: Nov 08, 2021,
     *status*: 4 - Beta,
     *requires*: N/A

     An encrypted password store for use within pytest cases

  :pypi:`pytest-select`
     *last release*: Jan 18, 2019,
     *status*: 3 - Alpha,
     *requires*: pytest (>=3.0)

     A pytest plugin which allows to (de-)select tests from a file.

  :pypi:`pytest-selenium`
     *last release*: May 28, 2023,
     *status*: 5 - Production/Stable,
     *requires*: pytest>=6.0.0

     pytest plugin for Selenium

  :pypi:`pytest-seleniumbase`
     *last release*: Jun 30, 2023,
     *status*: 5 - Production/Stable,
     *requires*: N/A

     A complete web automation framework for end-to-end testing.

  :pypi:`pytest-selenium-enhancer`
     *last release*: Apr 29, 2022,
     *status*: 5 - Production/Stable,
     *requires*: N/A

     pytest plugin for Selenium

  :pypi:`pytest-selenium-pdiff`
     *last release*: Apr 06, 2017,
     *status*: 2 - Pre-Alpha,
     *requires*: N/A

     A pytest package implementing perceptualdiff for Selenium tests.

  :pypi:`pytest-send-email`
     *last release*: Dec 04, 2019,
     *status*: N/A,
     *requires*: N/A

     Send pytest execution result email

  :pypi:`pytest-sentry`
     *last release*: Jan 05, 2023,
     *status*: N/A,
     *requires*: N/A

     A pytest plugin to send testrun information to Sentry.io

  :pypi:`pytest-sequence-markers`
     *last release*: May 23, 2023,
     *status*: 5 - Production/Stable,
     *requires*: N/A

     Pytest plugin for sequencing markers for execution of tests

  :pypi:`pytest-server-fixtures`
     *last release*: May 28, 2019,
     *status*: 5 - Production/Stable,
     *requires*: pytest

     Extensible server fixures for py.test

  :pypi:`pytest-serverless`
     *last release*: May 09, 2022,
     *status*: 4 - Beta,
     *requires*: N/A

     Automatically mocks resources from serverless.yml in pytest using moto.

  :pypi:`pytest-servers`
     *last release*: Apr 15, 2023,
     *status*: 3 - Alpha,
     *requires*: pytest (>=6.2)

     pytest servers

  :pypi:`pytest-services`
     *last release*: Oct 30, 2020,
     *status*: 6 - Mature,
     *requires*: N/A

     Services plugin for pytest testing framework

  :pypi:`pytest-session2file`
     *last release*: Jan 26, 2021,
     *status*: 3 - Alpha,
     *requires*: pytest

     pytest-session2file (aka: pytest-session_to_file for v0.1.0 - v0.1.2) is a py.test plugin for capturing and saving to file the stdout of py.test.

  :pypi:`pytest-session-fixture-globalize`
     *last release*: May 15, 2018,
     *status*: 4 - Beta,
     *requires*: N/A

     py.test plugin to make session fixtures behave as if written in conftest, even if it is written in some modules

  :pypi:`pytest-session_to_file`
     *last release*: Oct 01, 2015,
     *status*: 3 - Alpha,
     *requires*: N/A

     pytest-session_to_file is a py.test plugin for capturing and saving to file the stdout of py.test.

  :pypi:`pytest-setupinfo`
     *last release*: Jan 23, 2023,
     *status*: N/A,
     *requires*: N/A

     Displaying setup info during pytest command run

  :pypi:`pytest-sftpserver`
     *last release*: Sep 16, 2019,
     *status*: 4 - Beta,
     *requires*: N/A

     py.test plugin to locally test sftp server connections.

  :pypi:`pytest-shard`
     *last release*: Dec 11, 2020,
     *status*: 4 - Beta,
     *requires*: pytest



  :pypi:`pytest-share-hdf`
     *last release*: Sep 21, 2022,
     *status*: 4 - Beta,
     *requires*: pytest (>=3.5.0)

     Plugin to save test data in HDF files and retrieve them for comparison

  :pypi:`pytest-sharkreport`
     *last release*: Jul 11, 2022,
     *status*: N/A,
     *requires*: pytest (>=3.5)

     this is pytest report plugin.

  :pypi:`pytest-shell`
     *last release*: Mar 27, 2022,
     *status*: N/A,
     *requires*: N/A

     A pytest plugin to help with testing shell scripts / black box commands

  :pypi:`pytest-shell-utilities`
     *last release*: Sep 23, 2022,
     *status*: 4 - Beta,
     *requires*: pytest (>=6.0.0)

     Pytest plugin to simplify running shell commands against the system

  :pypi:`pytest-sheraf`
     *last release*: Feb 11, 2020,
     *status*: N/A,
     *requires*: pytest

     Versatile ZODB abstraction layer - pytest fixtures

  :pypi:`pytest-sherlock`
     *last release*: Jan 16, 2023,
     *status*: 5 - Production/Stable,
     *requires*: pytest (>=3.5.1)

     pytest plugin help to find coupled tests

  :pypi:`pytest-shortcuts`
     *last release*: Oct 29, 2020,
     *status*: 4 - Beta,
     *requires*: pytest (>=3.5.0)

     Expand command-line shortcuts listed in pytest configuration

  :pypi:`pytest-shutil`
     *last release*: May 28, 2019,
     *status*: 5 - Production/Stable,
     *requires*: pytest

     A goodie-bag of unix shell and environment tools for py.test

  :pypi:`pytest-simplehttpserver`
     *last release*: Jun 24, 2021,
     *status*: 4 - Beta,
     *requires*: N/A

     Simple pytest fixture to spin up an HTTP server

  :pypi:`pytest-simple-plugin`
     *last release*: Nov 27, 2019,
     *status*: N/A,
     *requires*: N/A

     Simple pytest plugin

  :pypi:`pytest-simple-settings`
     *last release*: Nov 17, 2020,
     *status*: 4 - Beta,
     *requires*: pytest

     simple-settings plugin for pytest

  :pypi:`pytest-single-file-logging`
     *last release*: May 05, 2016,
     *status*: 4 - Beta,
     *requires*: pytest (>=2.8.1)

     Allow for multiple processes to log to a single file

  :pypi:`pytest-skip-markers`
     *last release*: Dec 20, 2022,
     *status*: 5 - Production/Stable,
     *requires*: pytest (>=7.1.0)

     Pytest Salt Plugin

  :pypi:`pytest-skipper`
     *last release*: Mar 26, 2017,
     *status*: 3 - Alpha,
     *requires*: pytest (>=3.0.6)

     A plugin that selects only tests with changes in execution path

  :pypi:`pytest-skippy`
     *last release*: Jan 27, 2018,
     *status*: 3 - Alpha,
     *requires*: pytest (>=2.3.4)

     Automatically skip tests that don't need to run!

  :pypi:`pytest-skip-slow`
     *last release*: Feb 09, 2023,
     *status*: N/A,
     *requires*: pytest>=6.2.0

     A pytest plugin to skip \`@pytest.mark.slow\` tests by default.

  :pypi:`pytest-slack`
     *last release*: Dec 15, 2020,
     *status*: 5 - Production/Stable,
     *requires*: N/A

     Pytest to Slack reporting plugin

  :pypi:`pytest-slow`
     *last release*: Sep 28, 2021,
     *status*: N/A,
     *requires*: N/A

     A pytest plugin to skip \`@pytest.mark.slow\` tests by default.

  :pypi:`pytest-slowest-first`
     *last release*: Dec 11, 2022,
     *status*: 4 - Beta,
     *requires*: N/A

     Sort tests by their last duration, slowest first

  :pypi:`pytest-slow-last`
     *last release*: Dec 10, 2022,
     *status*: 4 - Beta,
     *requires*: pytest (>=3.5.0)

     Run tests in order of execution time (faster tests first)

  :pypi:`pytest-smartcollect`
     *last release*: Oct 04, 2018,
     *status*: N/A,
     *requires*: pytest (>=3.5.0)

     A plugin for collecting tests that touch changed code

  :pypi:`pytest-smartcov`
     *last release*: Sep 30, 2017,
     *status*: 3 - Alpha,
     *requires*: N/A

     Smart coverage plugin for pytest.

  :pypi:`pytest-smell`
     *last release*: Jun 26, 2022,
     *status*: N/A,
     *requires*: N/A

     Automated bad smell detection tool for Pytest

  :pypi:`pytest-smtp`
     *last release*: Feb 20, 2021,
     *status*: N/A,
     *requires*: pytest

     Send email with pytest execution result

  :pypi:`pytest-smtp4dev`
     *last release*: Jun 27, 2023,
     *status*: 5 - Production/Stable,
     *requires*: N/A

     Plugin for smtp4dev API

  :pypi:`pytest-smtpd`
     *last release*: May 15, 2023,
     *status*: N/A,
     *requires*: pytest

     An SMTP server for testing built on aiosmtpd

  :pypi:`pytest-snail`
     *last release*: Nov 04, 2019,
     *status*: 3 - Alpha,
     *requires*: pytest (>=5.0.1)

     Plugin for adding a marker to slow running tests. 🐌

  :pypi:`pytest-snapci`
     *last release*: Nov 12, 2015,
     *status*: N/A,
     *requires*: N/A

     py.test plugin for Snap-CI

  :pypi:`pytest-snapshot`
     *last release*: Apr 23, 2022,
     *status*: 4 - Beta,
     *requires*: pytest (>=3.0.0)

     A plugin for snapshot testing with pytest.

  :pypi:`pytest-snmpserver`
     *last release*: May 12, 2021,
     *status*: N/A,
     *requires*: N/A



  :pypi:`pytest-snowflake-bdd`
     *last release*: Jan 05, 2022,
     *status*: 4 - Beta,
     *requires*: pytest (>=6.2.0)

     Setup test data and run tests on snowflake in BDD style!

  :pypi:`pytest-socket`
     *last release*: Feb 03, 2023,
     *status*: 4 - Beta,
     *requires*: pytest (>=3.6.3)

     Pytest Plugin to disable socket calls during tests

  :pypi:`pytest-sofaepione`
     *last release*: Aug 17, 2022,
     *status*: N/A,
     *requires*: N/A

     Test the installation of SOFA and the SofaEpione plugin.

  :pypi:`pytest-soft-assertions`
     *last release*: May 05, 2020,
     *status*: 3 - Alpha,
     *requires*: pytest



  :pypi:`pytest-solidity`
     *last release*: Jan 15, 2022,
     *status*: 1 - Planning,
     *requires*: pytest (<7,>=6.0.1) ; extra == 'tests'

     A PyTest library plugin for Solidity language.

  :pypi:`pytest-solr`
     *last release*: May 11, 2020,
     *status*: 3 - Alpha,
     *requires*: pytest (>=3.0.0)

     Solr process and client fixtures for py.test.

  :pypi:`pytest-sorter`
     *last release*: Apr 20, 2021,
     *status*: 4 - Beta,
     *requires*: pytest (>=3.1.1)

     A simple plugin to first execute tests that historically failed more

  :pypi:`pytest-sosu`
     *last release*: Feb 14, 2023,
     *status*: 2 - Pre-Alpha,
     *requires*: pytest

     Unofficial PyTest plugin for Sauce Labs

  :pypi:`pytest-sourceorder`
     *last release*: Sep 01, 2021,
     *status*: 4 - Beta,
     *requires*: pytest

     Test-ordering plugin for pytest

  :pypi:`pytest-spark`
     *last release*: Feb 23, 2020,
     *status*: 4 - Beta,
     *requires*: pytest

     pytest plugin to run the tests with support of pyspark.

  :pypi:`pytest-spawner`
     *last release*: Jul 31, 2015,
     *status*: 4 - Beta,
     *requires*: N/A

     py.test plugin to spawn process and communicate with them.

  :pypi:`pytest-spec`
     *last release*: May 04, 2021,
     *status*: N/A,
     *requires*: N/A

     Library pytest-spec is a pytest plugin to display test execution output like a SPECIFICATION.

  :pypi:`pytest-spec2md`
     *last release*: Jun 26, 2022,
     *status*: N/A,
     *requires*: pytest (>7.0)

     Library pytest-spec2md is a pytest plugin to create a markdown specification while running pytest.

  :pypi:`pytest-speed`
     *last release*: Jan 22, 2023,
     *status*: 3 - Alpha,
     *requires*: pytest>=7

     Modern benchmarking library for python with pytest integration.

  :pypi:`pytest-sphinx`
     *last release*: Sep 06, 2022,
     *status*: 4 - Beta,
     *requires*: pytest (>=7.0.0)

     Doctest plugin for pytest with support for Sphinx-specific doctest-directives

  :pypi:`pytest-spiratest`
     *last release*: Feb 08, 2022,
     *status*: N/A,
     *requires*: N/A

     Exports unit tests as test runs in SpiraTest/Team/Plan

  :pypi:`pytest-splinter`
     *last release*: Sep 09, 2022,
     *status*: 6 - Mature,
     *requires*: pytest (>=3.0.0)

     Splinter plugin for pytest testing framework

  :pypi:`pytest-splinter4`
     *last release*: Jun 11, 2022,
     *status*: 6 - Mature,
     *requires*: pytest (<8.0,>=7.1.2)

     Pytest plugin for the splinter automation library

  :pypi:`pytest-split`
     *last release*: Apr 12, 2023,
     *status*: 4 - Beta,
     *requires*: pytest (>=5,<8)

     Pytest plugin which splits the test suite to equally sized sub suites based on test execution time.

  :pypi:`pytest-splitio`
     *last release*: Sep 22, 2020,
     *status*: N/A,
     *requires*: pytest (<7,>=5.0)

     Split.io SDK integration for e2e tests

  :pypi:`pytest-split-tests`
     *last release*: Jul 30, 2021,
     *status*: 5 - Production/Stable,
     *requires*: pytest (>=2.5)

     A Pytest plugin for running a subset of your tests by splitting them in to equally sized groups. Forked from Mark Adams' original project pytest-test-groups.

  :pypi:`pytest-split-tests-tresorit`
     *last release*: Feb 22, 2021,
     *status*: 1 - Planning,
     *requires*: N/A



  :pypi:`pytest-splunk-addon`
     *last release*: Jun 30, 2023,
     *status*: N/A,
     *requires*: pytest (>5.4.0,<8)

     A Dynamic test tool for Splunk Apps and Add-ons

  :pypi:`pytest-splunk-addon-ui-smartx`
     *last release*: Mar 07, 2023,
     *status*: N/A,
     *requires*: N/A

     Library to support testing Splunk Add-on UX

  :pypi:`pytest-splunk-env`
     *last release*: Oct 22, 2020,
     *status*: N/A,
     *requires*: pytest (>=6.1.1,<7.0.0)

     pytest fixtures for interaction with Splunk Enterprise and Splunk Cloud

  :pypi:`pytest-sqitch`
     *last release*: Apr 06, 2020,
     *status*: 4 - Beta,
     *requires*: N/A

     sqitch for pytest

  :pypi:`pytest-sqlalchemy`
     *last release*: Mar 13, 2018,
     *status*: 3 - Alpha,
     *requires*: N/A

     pytest plugin with sqlalchemy related fixtures

  :pypi:`pytest-sqlalchemy-mock`
     *last release*: Mar 15, 2023,
     *status*: 3 - Alpha,
     *requires*: pytest (>=2.0)

     pytest sqlalchemy plugin for mock

  :pypi:`pytest-sqlalchemy-session`
     *last release*: May 19, 2023,
     *status*: 4 - Beta,
     *requires*: pytest (>=7.0)

     A pytest plugin for preserving test isolation that use SQLAlchemy.

  :pypi:`pytest-sql-bigquery`
     *last release*: Dec 19, 2019,
     *status*: N/A,
     *requires*: pytest

     Yet another SQL-testing framework for BigQuery provided by pytest plugin

  :pypi:`pytest-sqlfluff`
     *last release*: Dec 21, 2022,
     *status*: 4 - Beta,
     *requires*: pytest (>=3.5.0)

     A pytest plugin to use sqlfluff to enable format checking of sql files.

  :pypi:`pytest-squadcast`
     *last release*: Feb 22, 2022,
     *status*: 5 - Production/Stable,
     *requires*: pytest

     Pytest report plugin for Squadcast

  :pypi:`pytest-srcpaths`
     *last release*: Oct 15, 2021,
     *status*: N/A,
     *requires*: pytest>=6.2.0

     Add paths to sys.path

  :pypi:`pytest-ssh`
     *last release*: May 27, 2019,
     *status*: N/A,
     *requires*: pytest

     pytest plugin for ssh command run

  :pypi:`pytest-start-from`
     *last release*: Apr 11, 2016,
     *status*: N/A,
     *requires*: N/A

     Start pytest run from a given point

  :pypi:`pytest-star-track-issue`
     *last release*: Feb 10, 2023,
     *status*: N/A,
     *requires*: N/A

     A package to prevent Dependency Confusion attacks against Yandex.

  :pypi:`pytest-static`
     *last release*: May 07, 2023,
     *status*: 1 - Planning,
     *requires*: N/A

     pytest-static

  :pypi:`pytest-statsd`
     *last release*: Nov 30, 2018,
     *status*: 5 - Production/Stable,
     *requires*: pytest (>=3.0.0)

     pytest plugin for reporting to graphite

  :pypi:`pytest-stepfunctions`
     *last release*: May 08, 2021,
     *status*: 4 - Beta,
     *requires*: pytest

     A small description

  :pypi:`pytest-steps`
     *last release*: Sep 23, 2021,
     *status*: 5 - Production/Stable,
     *requires*: N/A

     Create step-wise / incremental tests in pytest.

  :pypi:`pytest-stepwise`
     *last release*: Dec 01, 2015,
     *status*: 4 - Beta,
     *requires*: N/A

     Run a test suite one failing test at a time.

  :pypi:`pytest-stf`
     *last release*: Dec 04, 2022,
     *status*: N/A,
     *requires*: pytest (>=5.0)

     pytest plugin for openSTF

  :pypi:`pytest-stoq`
     *last release*: Feb 09, 2021,
     *status*: 4 - Beta,
     *requires*: N/A

     A plugin to pytest stoq

  :pypi:`pytest-stress`
     *last release*: Dec 07, 2019,
     *status*: 4 - Beta,
     *requires*: pytest (>=3.6.0)

     A Pytest plugin that allows you to loop tests for a user defined amount of time.

  :pypi:`pytest-structlog`
     *last release*: Dec 18, 2022,
     *status*: N/A,
     *requires*: pytest

     Structured logging assertions

  :pypi:`pytest-structmpd`
     *last release*: Oct 17, 2018,
     *status*: N/A,
     *requires*: N/A

     provide structured temporary directory

  :pypi:`pytest-stub`
     *last release*: Apr 28, 2020,
     *status*: 5 - Production/Stable,
     *requires*: N/A

     Stub packages, modules and attributes.

  :pypi:`pytest-stubprocess`
     *last release*: Sep 17, 2018,
     *status*: 3 - Alpha,
     *requires*: pytest (>=3.5.0)

     Provide stub implementations for subprocesses in Python tests

  :pypi:`pytest-study`
     *last release*: Sep 26, 2017,
     *status*: 3 - Alpha,
     *requires*: pytest (>=2.0)

     A pytest plugin to organize long run tests (named studies) without interfering the regular tests

  :pypi:`pytest-subprocess`
     *last release*: Jan 28, 2023,
     *status*: 5 - Production/Stable,
     *requires*: pytest (>=4.0.0)

     A plugin to fake subprocess for pytest

  :pypi:`pytest-subtesthack`
     *last release*: Jul 16, 2022,
     *status*: N/A,
     *requires*: N/A

     A hack to explicitly set up and tear down fixtures.

  :pypi:`pytest-subtests`
     *last release*: May 15, 2023,
     *status*: 4 - Beta,
     *requires*: pytest (>=7.0)

     unittest subTest() support and subtests fixture

  :pypi:`pytest-subunit`
     *last release*: Aug 29, 2017,
     *status*: N/A,
     *requires*: N/A

     pytest-subunit is a plugin for py.test which outputs testsresult in subunit format.

  :pypi:`pytest-sugar`
     *last release*: Apr 10, 2023,
     *status*: 4 - Beta,
     *requires*: pytest (>=6.2.0)

     pytest-sugar is a plugin for pytest that changes the default look and feel of pytest (e.g. progressbar, show tests that fail instantly).

  :pypi:`pytest-suitemanager`
     *last release*: Apr 28, 2023,
     *status*: 4 - Beta,
     *requires*: N/A

     A simple plugin to use with pytest

  :pypi:`pytest-svn`
     *last release*: May 28, 2019,
     *status*: 5 - Production/Stable,
     *requires*: pytest

     SVN repository fixture for py.test

  :pypi:`pytest-symbols`
     *last release*: Nov 20, 2017,
     *status*: 3 - Alpha,
     *requires*: N/A

     pytest-symbols is a pytest plugin that adds support for passing test environment symbols into pytest tests.

  :pypi:`pytest-system-statistics`
     *last release*: Feb 16, 2022,
     *status*: 5 - Production/Stable,
     *requires*: pytest (>=6.0.0)

     Pytest plugin to track and report system usage statistics

  :pypi:`pytest-system-test-plugin`
     *last release*: Feb 03, 2022,
     *status*: N/A,
     *requires*: N/A

     Pyst - Pytest System-Test Plugin

  :pypi:`pytest-tagging`
     *last release*: Apr 01, 2023,
     *status*: N/A,
     *requires*: pytest (>=7.1.3,<8.0.0)

     a pytest plugin to tag tests

  :pypi:`pytest-takeltest`
     *last release*: Feb 15, 2023,
     *status*: N/A,
     *requires*: N/A

     Fixtures for ansible, testinfra and molecule

  :pypi:`pytest-talisker`
     *last release*: Nov 28, 2021,
     *status*: N/A,
     *requires*: N/A



  :pypi:`pytest-tally`
     *last release*: May 22, 2023,
     *status*: 4 - Beta,
     *requires*: pytest (>=6.2.5)

     A Pytest plugin to generate realtime summary stats, and display them in-console using a text-based dashboard.

  :pypi:`pytest-tap`
     *last release*: Oct 27, 2021,
     *status*: 5 - Production/Stable,
     *requires*: pytest (>=3.0)

     Test Anything Protocol (TAP) reporting plugin for pytest

  :pypi:`pytest-tape`
     *last release*: Mar 17, 2021,
     *status*: 4 - Beta,
     *requires*: N/A

     easy assertion with expected results saved to yaml files

  :pypi:`pytest-target`
     *last release*: Jan 21, 2021,
     *status*: 3 - Alpha,
     *requires*: pytest (>=6.1.2,<7.0.0)

     Pytest plugin for remote target orchestration.

  :pypi:`pytest-tblineinfo`
     *last release*: Dec 01, 2015,
     *status*: 3 - Alpha,
     *requires*: pytest (>=2.0)

     tblineinfo is a py.test plugin that insert the node id in the final py.test report when --tb=line option is used

  :pypi:`pytest-tcpclient`
     *last release*: Nov 16, 2022,
     *status*: N/A,
     *requires*: pytest (<8,>=7.1.3)

     A pytest plugin for testing TCP clients

  :pypi:`pytest-teamcity-logblock`
     *last release*: May 15, 2018,
     *status*: 4 - Beta,
     *requires*: N/A

     py.test plugin to introduce block structure in teamcity build log, if output is not captured

  :pypi:`pytest-telegram`
     *last release*: Dec 10, 2020,
     *status*: 5 - Production/Stable,
     *requires*: N/A

     Pytest to Telegram reporting plugin

  :pypi:`pytest-telegram-notifier`
     *last release*: Jun 27, 2023,
     *status*: 5 - Production/Stable,
     *requires*: N/A

     Telegram notification plugin for Pytest

  :pypi:`pytest-tempdir`
     *last release*: Oct 11, 2019,
     *status*: 4 - Beta,
     *requires*: pytest (>=2.8.1)

     Predictable and repeatable tempdir support.

  :pypi:`pytest-terra-fixt`
     *last release*: Sep 15, 2022,
     *status*: N/A,
     *requires*: pytest (==6.2.5)

     Terraform and Terragrunt fixtures for pytest

  :pypi:`pytest-terraform`
     *last release*: Jun 20, 2023,
     *status*: N/A,
     *requires*: pytest (>=6.0)

     A pytest plugin for using terraform fixtures

  :pypi:`pytest-terraform-fixture`
     *last release*: Nov 14, 2018,
     *status*: 4 - Beta,
     *requires*: N/A

     generate terraform resources to use with pytest

  :pypi:`pytest-testbook`
     *last release*: Dec 11, 2016,
     *status*: 3 - Alpha,
     *requires*: N/A

     A plugin to run tests written in Jupyter notebook

  :pypi:`pytest-testconfig`
     *last release*: Jan 11, 2020,
     *status*: 4 - Beta,
     *requires*: pytest (>=3.5.0)

     Test configuration plugin for pytest.

  :pypi:`pytest-testdirectory`
     *last release*: May 02, 2023,
     *status*: 5 - Production/Stable,
     *requires*: pytest

     A py.test plugin providing temporary directories in unit tests.

  :pypi:`pytest-testdox`
     *last release*: Apr 19, 2022,
     *status*: 5 - Production/Stable,
     *requires*: pytest (>=4.6.0)

     A testdox format reporter for pytest

  :pypi:`pytest-test-grouping`
     *last release*: Feb 01, 2023,
     *status*: 5 - Production/Stable,
     *requires*: pytest (>=2.5)

     A Pytest plugin for running a subset of your tests by splitting them in to equally sized groups.

  :pypi:`pytest-test-groups`
     *last release*: Oct 25, 2016,
     *status*: 5 - Production/Stable,
     *requires*: N/A

     A Pytest plugin for running a subset of your tests by splitting them in to equally sized groups.

  :pypi:`pytest-testinfra`
     *last release*: May 21, 2023,
     *status*: 5 - Production/Stable,
     *requires*: pytest (!=3.0.2)

     Test infrastructures

  :pypi:`pytest-testlink-adaptor`
     *last release*: Dec 20, 2018,
     *status*: 4 - Beta,
     *requires*: pytest (>=2.6)

     pytest reporting plugin for testlink

  :pypi:`pytest-testmon`
     *last release*: Jun 16, 2023,
     *status*: 4 - Beta,
     *requires*: N/A

     selects tests affected by changed files and methods

  :pypi:`pytest-testmon-dev`
     *last release*: Mar 30, 2023,
     *status*: 4 - Beta,
     *requires*: pytest (<8,>=5)

     selects tests affected by changed files and methods

  :pypi:`pytest-testmon-oc`
     *last release*: Jun 01, 2022,
     *status*: 4 - Beta,
     *requires*: pytest (<8,>=5)

     nOly selects tests affected by changed files and methods

  :pypi:`pytest-testmon-skip-libraries`
     *last release*: Mar 03, 2023,
     *status*: 4 - Beta,
     *requires*: pytest (<8,>=5)

     selects tests affected by changed files and methods

  :pypi:`pytest-testobject`
     *last release*: Sep 24, 2019,
     *status*: 4 - Beta,
     *requires*: pytest (>=3.1.1)

     Plugin to use TestObject Suites with Pytest

  :pypi:`pytest-testpluggy`
     *last release*: Jan 07, 2022,
     *status*: N/A,
     *requires*: pytest

     set your encoding

  :pypi:`pytest-testrail`
     *last release*: Aug 27, 2020,
     *status*: N/A,
     *requires*: pytest (>=3.6)

     pytest plugin for creating TestRail runs and adding results

  :pypi:`pytest-testrail2`
     *last release*: Feb 10, 2023,
     *status*: N/A,
     *requires*: pytest (<8.0,>=7.2.0)

     A pytest plugin to upload results to TestRail.

  :pypi:`pytest-testrail-api-client`
     *last release*: Dec 14, 2021,
     *status*: N/A,
     *requires*: pytest

     TestRail Api Python Client

  :pypi:`pytest-testrail-appetize`
     *last release*: Sep 29, 2021,
     *status*: N/A,
     *requires*: N/A

     pytest plugin for creating TestRail runs and adding results

  :pypi:`pytest-testrail-client`
     *last release*: Sep 29, 2020,
     *status*: 5 - Production/Stable,
     *requires*: N/A

     pytest plugin for Testrail

  :pypi:`pytest-testrail-e2e`
     *last release*: Oct 11, 2021,
     *status*: N/A,
     *requires*: pytest (>=3.6)

     pytest plugin for creating TestRail runs and adding results

  :pypi:`pytest-testrail-integrator`
     *last release*: Aug 01, 2022,
     *status*: N/A,
     *requires*: pytest (>=6.2.5)

     Pytest plugin for sending report to testrail system.

  :pypi:`pytest-testrail-ns`
     *last release*: Aug 12, 2022,
     *status*: N/A,
     *requires*: N/A

     pytest plugin for creating TestRail runs and adding results

  :pypi:`pytest-testrail-plugin`
     *last release*: Apr 21, 2020,
     *status*: 3 - Alpha,
     *requires*: pytest

     PyTest plugin for TestRail

  :pypi:`pytest-testrail-reporter`
     *last release*: Sep 10, 2018,
     *status*: N/A,
     *requires*: N/A



  :pypi:`pytest-testreport`
     *last release*: Dec 01, 2022,
     *status*: 4 - Beta,
     *requires*: pytest (>=3.5.0)



  :pypi:`pytest-testreport-new`
     *last release*: Aug 15, 2022,
     *status*: 4 - Beta,
     *requires*: pytest (>=3.5.0)



  :pypi:`pytest-testslide`
     *last release*: Jan 07, 2021,
     *status*: 5 - Production/Stable,
     *requires*: pytest (~=6.2)

     TestSlide fixture for pytest

  :pypi:`pytest-test-this`
     *last release*: Sep 15, 2019,
     *status*: 2 - Pre-Alpha,
     *requires*: pytest (>=2.3)

     Plugin for py.test to run relevant tests, based on naively checking if a test contains a reference to the symbol you supply

  :pypi:`pytest-test-utils`
     *last release*: Jul 14, 2022,
     *status*: N/A,
     *requires*: pytest (>=5)



  :pypi:`pytest-tesults`
     *last release*: Dec 23, 2022,
     *status*: 5 - Production/Stable,
     *requires*: pytest (>=3.5.0)

     Tesults plugin for pytest

  :pypi:`pytest-textual-snapshot`
     *last release*: Jun 27, 2023,
     *status*: 4 - Beta,
     *requires*: pytest (>=7.0.0)

     Snapshot testing for Textual apps

  :pypi:`pytest-tezos`
     *last release*: Jan 16, 2020,
     *status*: 4 - Beta,
     *requires*: N/A

     pytest-ligo

  :pypi:`pytest-th2-bdd`
     *last release*: May 13, 2022,
     *status*: N/A,
     *requires*: N/A

     pytest_th2_bdd

  :pypi:`pytest-thawgun`
     *last release*: May 26, 2020,
     *status*: 3 - Alpha,
     *requires*: N/A

     Pytest plugin for time travel

  :pypi:`pytest-threadleak`
     *last release*: Jul 03, 2022,
     *status*: 4 - Beta,
     *requires*: pytest (>=3.1.1)

     Detects thread leaks

  :pypi:`pytest-tick`
     *last release*: Aug 31, 2021,
     *status*: 5 - Production/Stable,
     *requires*: pytest (>=6.2.5,<7.0.0)

     Ticking on tests

  :pypi:`pytest-time`
     *last release*: Jun 24, 2023,
     *status*: 3 - Alpha,
     *requires*: pytest



  :pypi:`pytest-timeit`
     *last release*: Oct 13, 2016,
     *status*: 4 - Beta,
     *requires*: N/A

     A pytest plugin to time test function runs

  :pypi:`pytest-timeout`
     *last release*: Jan 18, 2022,
     *status*: 5 - Production/Stable,
     *requires*: pytest (>=5.0.0)

     pytest plugin to abort hanging tests

  :pypi:`pytest-timeouts`
     *last release*: Sep 21, 2019,
     *status*: 5 - Production/Stable,
     *requires*: N/A

     Linux-only Pytest plugin to control durations of various test case execution phases

  :pypi:`pytest-timer`
     *last release*: Jun 02, 2021,
     *status*: N/A,
     *requires*: N/A

     A timer plugin for pytest

  :pypi:`pytest-timestamper`
     *last release*: Jun 06, 2021,
     *status*: N/A,
     *requires*: N/A

     Pytest plugin to add a timestamp prefix to the pytest output

  :pypi:`pytest-timestamps`
     *last release*: Apr 01, 2023,
     *status*: N/A,
     *requires*: pytest (>=5.2)

     A simple plugin to view timestamps for each test

  :pypi:`pytest-tinybird`
     *last release*: Jun 26, 2023,
     *status*: 4 - Beta,
     *requires*: pytest (>=3.8.0)

     A pytest plugin to report test results to tinybird

  :pypi:`pytest-tipsi-django`
     *last release*: Nov 17, 2021,
     *status*: 4 - Beta,
     *requires*: pytest (>=6.0.0)



  :pypi:`pytest-tipsi-testing`
     *last release*: Nov 04, 2020,
     *status*: 4 - Beta,
     *requires*: pytest (>=3.3.0)

     Better fixtures management. Various helpers

  :pypi:`pytest-tldr`
     *last release*: Oct 26, 2022,
     *status*: 4 - Beta,
     *requires*: pytest (>=3.5.0)

     A pytest plugin that limits the output to just the things you need.

  :pypi:`pytest-tm4j-reporter`
     *last release*: Sep 01, 2020,
     *status*: N/A,
     *requires*: pytest

     Cloud Jira Test Management (TM4J) PyTest reporter plugin

  :pypi:`pytest-tmnet`
     *last release*: Mar 01, 2022,
     *status*: N/A,
     *requires*: N/A

     A small example package

  :pypi:`pytest-tmp-files`
     *last release*: Apr 03, 2022,
     *status*: N/A,
     *requires*: pytest

     Utilities to create temporary file hierarchies in pytest.

  :pypi:`pytest-tmpfs`
     *last release*: Aug 29, 2022,
     *status*: N/A,
     *requires*: pytest

     A pytest plugin that helps you on using a temporary filesystem for testing.

  :pypi:`pytest-tmreport`
     *last release*: Aug 12, 2022,
     *status*: N/A,
     *requires*: N/A

     this is a vue-element ui report for pytest

  :pypi:`pytest-tmux`
     *last release*: Apr 22, 2023,
     *status*: 4 - Beta,
     *requires*: N/A

     A pytest plugin that enables tmux driven tests

  :pypi:`pytest-todo`
     *last release*: May 23, 2019,
     *status*: 4 - Beta,
     *requires*: pytest

     A small plugin for the pytest testing framework, marking TODO comments as failure

  :pypi:`pytest-tomato`
     *last release*: Mar 01, 2019,
     *status*: 5 - Production/Stable,
     *requires*: N/A



  :pypi:`pytest-toolbelt`
     *last release*: Aug 12, 2019,
     *status*: 3 - Alpha,
     *requires*: N/A

     This is just a collection of utilities for pytest, but don't really belong in pytest proper.

  :pypi:`pytest-toolbox`
     *last release*: Apr 07, 2018,
     *status*: N/A,
     *requires*: pytest (>=3.5.0)

     Numerous useful plugins for pytest.

  :pypi:`pytest-tools`
     *last release*: Oct 21, 2022,
     *status*: 4 - Beta,
     *requires*: N/A

     Pytest tools

  :pypi:`pytest-tornado`
     *last release*: Jun 17, 2020,
     *status*: 5 - Production/Stable,
     *requires*: pytest (>=3.6)

     A py.test plugin providing fixtures and markers to simplify testing of asynchronous tornado applications.

  :pypi:`pytest-tornado5`
     *last release*: Nov 16, 2018,
     *status*: 5 - Production/Stable,
     *requires*: pytest (>=3.6)

     A py.test plugin providing fixtures and markers to simplify testing of asynchronous tornado applications.

  :pypi:`pytest-tornado-yen3`
     *last release*: Oct 15, 2018,
     *status*: 5 - Production/Stable,
     *requires*: N/A

     A py.test plugin providing fixtures and markers to simplify testing of asynchronous tornado applications.

  :pypi:`pytest-tornasync`
     *last release*: Jul 15, 2019,
     *status*: 3 - Alpha,
     *requires*: pytest (>=3.0)

     py.test plugin for testing Python 3.5+ Tornado code

  :pypi:`pytest-trace`
     *last release*: Jun 19, 2022,
     *status*: N/A,
     *requires*: pytest (>=4.6)

     Save OpenTelemetry spans generated during testing

  :pypi:`pytest-track`
     *last release*: Feb 26, 2021,
     *status*: 3 - Alpha,
     *requires*: pytest (>=3.0)



  :pypi:`pytest-translations`
     *last release*: Nov 05, 2021,
     *status*: 5 - Production/Stable,
     *requires*: N/A

     Test your translation files.

  :pypi:`pytest-travis-fold`
     *last release*: Nov 29, 2017,
     *status*: 4 - Beta,
     *requires*: pytest (>=2.6.0)

     Folds captured output sections in Travis CI build log

  :pypi:`pytest-trello`
     *last release*: Nov 20, 2015,
     *status*: 5 - Production/Stable,
     *requires*: N/A

     Plugin for py.test that integrates trello using markers

  :pypi:`pytest-trepan`
     *last release*: Jul 28, 2018,
     *status*: 5 - Production/Stable,
     *requires*: N/A

     Pytest plugin for trepan debugger.

  :pypi:`pytest-trialtemp`
     *last release*: Jun 08, 2015,
     *status*: N/A,
     *requires*: N/A

     py.test plugin for using the same _trial_temp working directory as trial

  :pypi:`pytest-trio`
     *last release*: Nov 01, 2022,
     *status*: N/A,
     *requires*: pytest (>=7.2.0)

     Pytest plugin for trio

  :pypi:`pytest-trytond`
     *last release*: Nov 04, 2022,
     *status*: 4 - Beta,
     *requires*: pytest (>=5)

     Pytest plugin for the Tryton server framework

  :pypi:`pytest-tspwplib`
     *last release*: Jan 08, 2021,
     *status*: 4 - Beta,
     *requires*: pytest (>=3.5.0)

     A simple plugin to use with tspwplib

  :pypi:`pytest-tst`
     *last release*: Apr 27, 2022,
     *status*: N/A,
     *requires*: pytest (>=5.0.0)

     Customize pytest options, output and exit code to make it compatible with tst

  :pypi:`pytest-tstcls`
     *last release*: Mar 23, 2020,
     *status*: 5 - Production/Stable,
     *requires*: N/A

     Test Class Base

  :pypi:`pytest-tui`
     *last release*: Jun 12, 2023,
     *status*: 4 - Beta,
     *requires*: N/A

     Text User Interface (TUI) and HTML report for Pytest test runs

  :pypi:`pytest-tutorials`
     *last release*: Mar 11, 2023,
     *status*: N/A,
     *requires*: N/A



  :pypi:`pytest-twilio-conversations-client-mock`
     *last release*: Aug 02, 2022,
     *status*: N/A,
     *requires*: N/A



  :pypi:`pytest-twisted`
     *last release*: Oct 16, 2022,
     *status*: 5 - Production/Stable,
     *requires*: pytest (>=2.3)

     A twisted plugin for pytest.

  :pypi:`pytest-typechecker`
     *last release*: Feb 04, 2022,
     *status*: N/A,
     *requires*: pytest (>=6.2.5,<7.0.0)

     Run type checkers on specified test files

  :pypi:`pytest-typhoon-config`
     *last release*: Apr 07, 2022,
     *status*: 5 - Production/Stable,
     *requires*: N/A

     A Typhoon HIL plugin that facilitates test parameter configuration at runtime

  :pypi:`pytest-typhoon-xray`
     *last release*: Jun 10, 2023,
     *status*: 4 - Beta,
     *requires*: N/A

     Typhoon HIL plugin for pytest

  :pypi:`pytest-tytest`
     *last release*: May 25, 2020,
     *status*: 4 - Beta,
     *requires*: pytest (>=5.4.2)

     Typhoon HIL plugin for pytest

  :pypi:`pytest-ubersmith`
     *last release*: Apr 13, 2015,
     *status*: N/A,
     *requires*: N/A

     Easily mock calls to ubersmith at the \`requests\` level.

  :pypi:`pytest-ui`
     *last release*: Jul 05, 2021,
     *status*: 4 - Beta,
     *requires*: pytest

     Text User Interface for running python tests

  :pypi:`pytest-ui-failed-screenshot`
     *last release*: Dec 06, 2022,
     *status*: N/A,
     *requires*: N/A

     UI自动测试失败时自动截图，并将截图加入到测试报告中

  :pypi:`pytest-ui-failed-screenshot-allure`
     *last release*: Dec 06, 2022,
     *status*: N/A,
     *requires*: N/A

     UI自动测试失败时自动截图，并将截图加入到Allure测试报告中

  :pypi:`pytest-unflakable`
     *last release*: Mar 24, 2023,
     *status*: 4 - Beta,
     *requires*: pytest (>=6.2.0)

     Unflakable plugin for PyTest

  :pypi:`pytest-unhandled-exception-exit-code`
     *last release*: Jun 22, 2020,
     *status*: 5 - Production/Stable,
     *requires*: pytest (>=2.3)

     Plugin for py.test set a different exit code on uncaught exceptions

  :pypi:`pytest-unittest-filter`
     *last release*: Jan 12, 2019,
     *status*: 4 - Beta,
     *requires*: pytest (>=3.1.0)

     A pytest plugin for filtering unittest-based test classes

  :pypi:`pytest-unmarked`
     *last release*: Aug 27, 2019,
     *status*: 5 - Production/Stable,
     *requires*: N/A

     Run only unmarked tests

  :pypi:`pytest-unordered`
     *last release*: Nov 28, 2022,
     *status*: 4 - Beta,
     *requires*: pytest (>=6.0.0)

     Test equality of unordered collections in pytest

  :pypi:`pytest-unstable`
     *last release*: Sep 27, 2022,
     *status*: 4 - Beta,
     *requires*: N/A

     Set a test as unstable to return 0 even if it failed

  :pypi:`pytest-unused-fixtures`
     *last release*: Jun 30, 2023,
     *status*: 4 - Beta,
     *requires*: pytest (>=7.3.2,<8.0.0)

     A pytest plugin to list unused fixtures after a test run.

  :pypi:`pytest-upload-report`
     *last release*: Jun 18, 2021,
     *status*: 5 - Production/Stable,
     *requires*: N/A

     pytest-upload-report is a plugin for pytest that upload your test report for test results.

  :pypi:`pytest-utils`
     *last release*: Feb 02, 2023,
     *status*: 4 - Beta,
     *requires*: pytest (>=7.0.0,<8.0.0)

     Some helpers for pytest.

  :pypi:`pytest-vagrant`
     *last release*: Sep 07, 2021,
     *status*: 5 - Production/Stable,
     *requires*: pytest

     A py.test plugin providing access to vagrant.

  :pypi:`pytest-valgrind`
     *last release*: May 19, 2021,
     *status*: N/A,
     *requires*: N/A



  :pypi:`pytest-variables`
     *last release*: May 27, 2023,
     *status*: 5 - Production/Stable,
     *requires*: pytest>=7.0.0

     pytest plugin for providing variables to tests/fixtures

  :pypi:`pytest-variant`
     *last release*: Jun 06, 2022,
     *status*: N/A,
     *requires*: N/A

     Variant support for Pytest

  :pypi:`pytest-vcr`
     *last release*: Apr 26, 2019,
     *status*: 5 - Production/Stable,
     *requires*: pytest (>=3.6.0)

     Plugin for managing VCR.py cassettes

  :pypi:`pytest-vcr-delete-on-fail`
     *last release*: Jun 20, 2022,
     *status*: 5 - Production/Stable,
     *requires*: pytest (>=6.2.2)

     A pytest plugin that automates vcrpy cassettes deletion on test failure.

  :pypi:`pytest-vcrpandas`
     *last release*: Jan 12, 2019,
     *status*: 4 - Beta,
     *requires*: pytest

     Test from HTTP interactions to dataframe processed.

  :pypi:`pytest-vcs`
     *last release*: Sep 22, 2022,
     *status*: 4 - Beta,
     *requires*: N/A



  :pypi:`pytest-venv`
     *last release*: Aug 04, 2020,
     *status*: 4 - Beta,
     *requires*: pytest

     py.test fixture for creating a virtual environment

  :pypi:`pytest-ver`
     *last release*: Mar 22, 2023,
     *status*: 4 - Beta,
     *requires*: N/A

     Pytest module with Verification Protocol, Verification Report and Trace Matrix

  :pypi:`pytest-verbose-parametrize`
     *last release*: May 28, 2019,
     *status*: 5 - Production/Stable,
     *requires*: pytest

     More descriptive output for parametrized py.test tests

  :pypi:`pytest-vimqf`
     *last release*: Feb 08, 2021,
     *status*: 4 - Beta,
     *requires*: pytest (>=6.2.2,<7.0.0)

     A simple pytest plugin that will shrink pytest output when specified, to fit vim quickfix window.

  :pypi:`pytest-virtualenv`
     *last release*: May 28, 2019,
     *status*: 5 - Production/Stable,
     *requires*: pytest

     Virtualenv fixture for py.test

  :pypi:`pytest-vnc`
     *last release*: Feb 25, 2023,
     *status*: N/A,
     *requires*: pytest

     VNC client for Pytest

  :pypi:`pytest-voluptuous`
     *last release*: Jun 09, 2020,
     *status*: N/A,
     *requires*: pytest

     Pytest plugin for asserting data against voluptuous schema.

  :pypi:`pytest-vscodedebug`
     *last release*: Dec 04, 2020,
     *status*: 4 - Beta,
     *requires*: N/A

     A pytest plugin to easily enable debugging tests within Visual Studio Code

  :pypi:`pytest-vscode-pycharm-cls`
     *last release*: Feb 01, 2023,
     *status*: N/A,
     *requires*: pytest

     A PyTest helper to enable start remote debugger on test start or failure or when pytest.set_trace is used.

  :pypi:`pytest-vts`
     *last release*: Jun 05, 2019,
     *status*: N/A,
     *requires*: pytest (>=2.3)

     pytest plugin for automatic recording of http stubbed tests

  :pypi:`pytest-vulture`
     *last release*: Jun 01, 2023,
     *status*: N/A,
     *requires*: pytest (>=7.0.0)

     A pytest plugin to checks dead code with vulture

  :pypi:`pytest-vw`
     *last release*: Oct 07, 2015,
     *status*: 4 - Beta,
     *requires*: N/A

     pytest-vw makes your failing test cases succeed under CI tools scrutiny

  :pypi:`pytest-vyper`
     *last release*: May 28, 2020,
     *status*: 2 - Pre-Alpha,
     *requires*: N/A

     Plugin for the vyper smart contract language.

  :pypi:`pytest-wa-e2e-plugin`
     *last release*: Feb 18, 2020,
     *status*: 4 - Beta,
     *requires*: pytest (>=3.5.0)

     Pytest plugin for testing whatsapp bots with end to end tests

  :pypi:`pytest-wake`
     *last release*: May 11, 2023,
     *status*: N/A,
     *requires*: pytest



  :pypi:`pytest-watch`
     *last release*: May 20, 2018,
     *status*: N/A,
     *requires*: N/A

     Local continuous test runner with pytest and watchdog.

  :pypi:`pytest-watcher`
     *last release*: Jun 24, 2023,
     *status*: 4 - Beta,
     *requires*: N/A

     Automatically rerun your tests on file modifications

  :pypi:`pytest-wdl`
     *last release*: Nov 17, 2020,
     *status*: 5 - Production/Stable,
     *requires*: N/A

     Pytest plugin for testing WDL workflows.

  :pypi:`pytest-web3-data`
     *last release*: Sep 15, 2022,
     *status*: 4 - Beta,
     *requires*: pytest



  :pypi:`pytest-webdriver`
     *last release*: May 28, 2019,
     *status*: 5 - Production/Stable,
     *requires*: pytest

     Selenium webdriver fixture for py.test

  :pypi:`pytest-wetest`
     *last release*: Nov 10, 2018,
     *status*: 4 - Beta,
     *requires*: N/A

     Welian API Automation test framework pytest plugin

  :pypi:`pytest-when`
     *last release*: Jun 05, 2023,
     *status*: N/A,
     *requires*: pytest>=7.3.1

     Utility which makes mocking more readable and controllable

  :pypi:`pytest-whirlwind`
     *last release*: Jun 12, 2020,
     *status*: N/A,
     *requires*: N/A

     Testing Tornado.

  :pypi:`pytest-wholenodeid`
     *last release*: Aug 26, 2015,
     *status*: 4 - Beta,
     *requires*: pytest (>=2.0)

     pytest addon for displaying the whole node id for failures

  :pypi:`pytest-win32consoletitle`
     *last release*: Aug 08, 2021,
     *status*: N/A,
     *requires*: N/A

     Pytest progress in console title (Win32 only)

  :pypi:`pytest-winnotify`
     *last release*: Apr 22, 2016,
     *status*: N/A,
     *requires*: N/A

     Windows tray notifications for py.test results.

  :pypi:`pytest-wiremock`
     *last release*: Mar 27, 2022,
     *status*: N/A,
     *requires*: pytest (>=7.1.1,<8.0.0)

     A pytest plugin for programmatically using wiremock in integration tests

  :pypi:`pytest-with-docker`
     *last release*: Nov 09, 2021,
     *status*: N/A,
     *requires*: pytest

     pytest with docker helpers.

  :pypi:`pytest-workflow`
     *last release*: Jan 13, 2023,
     *status*: 5 - Production/Stable,
     *requires*: pytest (>=7.0.0)

     A pytest plugin for configuring workflow/pipeline tests using YAML files

  :pypi:`pytest-xdist`
     *last release*: May 19, 2023,
     *status*: 5 - Production/Stable,
     *requires*: pytest (>=6.2.0)

     pytest xdist plugin for distributed testing, most importantly across multiple CPUs

  :pypi:`pytest-xdist-debug-for-graingert`
     *last release*: Jul 24, 2019,
     *status*: 5 - Production/Stable,
     *requires*: pytest (>=4.4.0)

     pytest xdist plugin for distributed testing and loop-on-failing modes

  :pypi:`pytest-xdist-forked`
     *last release*: Feb 10, 2020,
     *status*: 5 - Production/Stable,
     *requires*: pytest (>=4.4.0)

     forked from pytest-xdist

  :pypi:`pytest-xdist-tracker`
     *last release*: Nov 18, 2021,
     *status*: 3 - Alpha,
     *requires*: pytest (>=3.5.1)

     pytest plugin helps to reproduce failures for particular xdist node

  :pypi:`pytest-xdist-worker-stats`
     *last release*: Jun 19, 2023,
     *status*: 4 - Beta,
     *requires*: pytest (>=7.3.2,<8.0.0)

     A pytest plugin to list worker statistics after a xdist run.

  :pypi:`pytest-xfaillist`
     *last release*: Sep 17, 2021,
     *status*: N/A,
     *requires*: pytest (>=6.2.2,<7.0.0)

     Maintain a xfaillist in an additional file to avoid merge-conflicts.

  :pypi:`pytest-xfiles`
     *last release*: Feb 27, 2018,
     *status*: N/A,
     *requires*: N/A

     Pytest fixtures providing data read from function, module or package related (x)files.

  :pypi:`pytest-xlog`
     *last release*: May 31, 2020,
     *status*: 4 - Beta,
     *requires*: N/A

     Extended logging for test and decorators

  :pypi:`pytest-xlsx`
     *last release*: Mar 01, 2023,
     *status*: N/A,
     *requires*: pytest>=7.2.0

     pytest plugin for generating test cases by xlsx(excel)

  :pypi:`pytest-xpara`
     *last release*: Oct 30, 2017,
     *status*: 3 - Alpha,
     *requires*: pytest

     An extended parametrizing plugin of pytest.

  :pypi:`pytest-xprocess`
     *last release*: Jan 05, 2023,
     *status*: 4 - Beta,
     *requires*: pytest (>=2.8)

     A pytest plugin for managing processes across test runs.

  :pypi:`pytest-xray`
     *last release*: May 30, 2019,
     *status*: 3 - Alpha,
     *requires*: N/A



  :pypi:`pytest-xrayjira`
     *last release*: Mar 17, 2020,
     *status*: 3 - Alpha,
     *requires*: pytest (==4.3.1)



  :pypi:`pytest-xray-server`
     *last release*: May 03, 2022,
     *status*: 3 - Alpha,
     *requires*: pytest (>=5.3.1)



  :pypi:`pytest-xskynet`
     *last release*: Feb 10, 2023,
     *status*: N/A,
     *requires*: N/A

     A package to prevent Dependency Confusion attacks against Yandex.

  :pypi:`pytest-xvfb`
     *last release*: May 29, 2023,
     *status*: 4 - Beta,
     *requires*: pytest (>=2.8.1)

     A pytest plugin to run Xvfb (or Xephyr/Xvnc) for tests.

  :pypi:`pytest-xvirt`
     *last release*: Jun 18, 2023,
     *status*: 4 - Beta,
     *requires*: pytest (>=7.1.0)

     A pytest plugin to virtualize test. For example to transparently running them on a remote box.

  :pypi:`pytest-yaml`
     *last release*: Oct 05, 2018,
     *status*: N/A,
     *requires*: pytest

     This plugin is used to load yaml output to your test using pytest framework.

  :pypi:`pytest-yaml-sanmu`
     *last release*: May 28, 2023,
     *status*: N/A,
     *requires*: pytest>=7.2.0

     pytest plugin for generating test cases by yaml

  :pypi:`pytest-yamltree`
     *last release*: Mar 02, 2020,
     *status*: 4 - Beta,
     *requires*: pytest (>=3.1.1)

     Create or check file/directory trees described by YAML

  :pypi:`pytest-yamlwsgi`
     *last release*: May 11, 2010,
     *status*: N/A,
     *requires*: N/A

     Run tests against wsgi apps defined in yaml

  :pypi:`pytest-yaml-yoyo`
     *last release*: Jun 19, 2023,
     *status*: N/A,
     *requires*: pytest (>=7.2.0)

     http/https API run by yaml

  :pypi:`pytest-yapf`
     *last release*: Jul 06, 2017,
     *status*: 4 - Beta,
     *requires*: pytest (>=3.1.1)

     Run yapf

  :pypi:`pytest-yapf3`
     *last release*: Mar 29, 2023,
     *status*: 5 - Production/Stable,
     *requires*: pytest (>=7)

     Validate your Python file format with yapf

  :pypi:`pytest-yield`
     *last release*: Jan 23, 2019,
     *status*: N/A,
     *requires*: N/A

     PyTest plugin to run tests concurrently, each \`yield\` switch context to other one

  :pypi:`pytest-yls`
     *last release*: Jun 21, 2023,
     *status*: N/A,
     *requires*: pytest (>=7.2.2,<8.0.0)

     Pytest plugin to test the YLS as a whole.

  :pypi:`pytest-yuk`
     *last release*: Mar 26, 2021,
     *status*: N/A,
     *requires*: pytest>=5.0.0

     Display tests you are uneasy with, using 🤢/🤮 for pass/fail of tests marked with yuk.

  :pypi:`pytest-zafira`
     *last release*: Sep 18, 2019,
     *status*: 5 - Production/Stable,
     *requires*: pytest (==4.1.1)

     A Zafira plugin for pytest

  :pypi:`pytest-zap`
     *last release*: May 12, 2014,
     *status*: 4 - Beta,
     *requires*: N/A

     OWASP ZAP plugin for py.test.

  :pypi:`pytest-zebrunner`
     *last release*: Dec 12, 2022,
     *status*: 5 - Production/Stable,
     *requires*: pytest (>=4.5.0)

     Pytest connector for Zebrunner reporting

  :pypi:`pytest-zest`
     *last release*: Nov 17, 2022,
     *status*: N/A,
     *requires*: N/A

     Zesty additions to pytest.

  :pypi:`pytest-zigzag`
     *last release*: Feb 27, 2019,
     *status*: 4 - Beta,
     *requires*: pytest (~=3.6)

     Extend py.test for RPC OpenStack testing.

  :pypi:`pytest-zulip`
     *last release*: May 07, 2022,
     *status*: 5 - Production/Stable,
     *requires*: pytest

     Pytest report plugin for Zulip
