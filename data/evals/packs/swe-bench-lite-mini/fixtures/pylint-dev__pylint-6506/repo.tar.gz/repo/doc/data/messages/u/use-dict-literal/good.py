empty_dict = {}
